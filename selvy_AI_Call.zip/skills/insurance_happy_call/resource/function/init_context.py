# -*- coding: utf-8 -*-
from selvybot.function import Function

__author__ = "Glenn D. Lim"
__copyright__ = "Copyright 2019, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2019/07/16"


class InitContext(Function):
    """
    .. warning::
       없음

    .. seealso::
        없음

    Example:
        컨텍스트 초기화 하기 위해 사용
    """

    def run(self, context, text):
        """
        Context 초기화

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            bool, qset cycle 종료 여부 반환
        """
        context.glob.clear()
        context.local.clear()
        return ""
