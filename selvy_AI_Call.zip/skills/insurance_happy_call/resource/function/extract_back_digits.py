# -*- coding: utf-8-*-
import json
import re

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "Zoey Jeonga Han"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "zoey.j.han@selvas.com"
__date__ = "2020/10/28"

class ExtractBackDigits(Function):
    """__init__(self, param)
    시나리오의 챗봇 발화에 사용할수 있는 함수 정의
    프레임워크 하단에 정의된 함수는 시스템 함수,
    시나리오 폴더에 사용자가 정의한 함수는 유저 함수로 구분됨

    .. warning::
       없음

    Args:
        params (list of Str): optional 인자.

    .. seealso::
        없음

    """

    def run(self, context, text):
        phone_number = context.glob['phone_number']
        return phone_number[-4:]