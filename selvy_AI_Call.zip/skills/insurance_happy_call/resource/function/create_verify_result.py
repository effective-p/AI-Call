# -*- coding: utf-8-*-
from selvybot.function import Function

__author__ = "Andrew Jeonguk Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/08/24"


class CreateVerifyResult(Function):
    """
    Rest API Response 에 추가할 필드를 정의하는 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::create_verify_result(value)>

    """

    def build(self, type, value):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            value (str): field 값

        Returns:
            bool, 빌드 성공/실패 여부

        """
        output = {"verify_info": {"mode": type, "result": int(value)}}

        def core(context):
            return output
        self._core = core
        return True

    def run(self, context, text):
        """
        custom field 객체(dict)를 반환

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            dict, custom field 객체.

        """
        return self._core(context)
