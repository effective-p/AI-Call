# -*- coding: utf-8-*-
from svlog import logged

from selvybot.error.resource import ResourceGetFailedError
from selvybot.preprocess import PreProcess
from selvybot.util import SystemPath, requests_retry_session

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


@logged
class KoreanSegmentation(PreProcess):
    """__init__(self)

    띄어쓰기 모듈

    .. warning::
       없음

    Args:

    .. seealso::
        없음

    """

    def __init__(self, resource_path):
        self._url = resource_path.components_url + "/segmentation"
        self._session = requests_retry_session()

    def run(self, context, text):
        """
            입력 문장을 띄어 쓰기 한다.
            Args:
                context (Context):  context 객체.
                text (str): 챗봇 발화.

            Returns:
                result_text (str): 정제된 챗봇 발화
        """
        try:
            response = self._session.post(self._url, json={"text": text})
            if response.status_code != 200:
                raise ResourceGetFailedError(response.text)
            return response.text
        except Exception as e:
            self.__log.error(e)
            return text
