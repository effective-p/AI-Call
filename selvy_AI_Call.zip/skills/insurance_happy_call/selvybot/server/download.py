# -*- coding: utf-8-*-
import io

from flask import send_file
from flask_restful import Resource

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/09/27"


class ScenarioResource(Resource):
    def __init__(self, **kwargs):
        self._export_scenario = kwargs['export_scenario_func']

    def get(self):
        return send_file(io.BytesIO(self._export_scenario()), attachment_filename='scenario.zip', as_attachment=True)


class ScriptResource(Resource):
    def __init__(self, **kwargs):
        self._export_script = kwargs['export_script_func']

    def get(self):
        return send_file(io.BytesIO(self._export_script()), attachment_filename='script.xlsx', as_attachment=True)
