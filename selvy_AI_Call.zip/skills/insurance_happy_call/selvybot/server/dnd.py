# -*- coding: utf-8-*-
import json
from datetime import datetime

from flask import make_response
from flask_restful import Resource, reqparse

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/02"


class DndResource(Resource):
    def __init__(self, **kwargs):
        self._context_manager = kwargs['context_manager']

    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=str, required=True, location=['args'])
        parser.add_argument('timer', type=int, location=['args'])
        args = parser.parse_args(strict=True)

        result = True
        if 'timer' in args:
            context = self._context_manager._get_data(args.user_id)
            if 'last_access_time' in context['session']:
                seconds = (datetime.now() - datetime.strptime(context['session']['last_access_time'],
                                                              "%Y-%m-%d %H:%M:%S.%f")).total_seconds()
                result = args['timer'] < seconds

        # TODO jskim 방해금지 모드를 on / off 할수 있도록 기능을 추가하고 해당 설정값을 체크하도록 구현

        return make_response(json.dumps(result))
