from flask_restful import Resource

# -*- coding: utf-8-*-
__author__ = "Demian Haksik Yang"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "hsyang@selvas.com"
__date__ = "2018/10/01"


class MetaResource(Resource):
    def __init__(self, **kwargs):
        self.meta_data = kwargs['meta_data']

    def get(self):
        return self.meta_data
