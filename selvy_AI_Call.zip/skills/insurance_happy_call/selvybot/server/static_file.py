# -*- coding: utf-8-*-

import os

from flask import send_file, abort
from flask_restful import Resource

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/16"


class StaticFile(Resource):
    def __init__(self, **kwargs):
        self.static_path = kwargs['static_path']

    def get(self, path):
        mimetypes = {
            ".css": "text/css",
            ".html": "text/html",
            ".js": "application/javascript",
            ".jpg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
        }
        complete_path = os.path.join(self.static_path, path)
        ext = os.path.splitext(path)[1]
        mimetype = mimetypes.get(ext, None)
        if not os.path.isfile(complete_path):
            abort(404)
        return send_file(complete_path, mimetype=mimetype)
