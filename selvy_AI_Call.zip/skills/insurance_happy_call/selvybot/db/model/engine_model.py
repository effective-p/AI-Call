import os
import pickle

from sqlalchemy.sql import func
from svlog import logged, traced

from selvybot.db.database_driver import db

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/04/30"


class EngineModel(db.Model):
    __tablename__ = 'model'

    name = db.Column(db.String(40), primary_key=True)
    version = db.Column(db.String(10), primary_key=True)
    hash = db.Column(db.String(64), primary_key=True)
    language = db.Column(db.String(10), primary_key=True)
    value = db.Column(db.LargeBinary(length=(2 ** 32) - 1))
    created = db.Column(db.DateTime(timezone=True), server_default=func.now())
    updated = db.Column(db.DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __init__(self, name, version, hash, language, value):
        self.name = name
        self.version = version
        self.hash = hash
        self.language = language
        self.value = value

    def __repr__(self):
        return "<EngineModel({}, {}, {}, {}, {} ... {} , {}, {})>".format(self.name, self.version, self.hash,
                                                                          self.language, str(self.value)[:20],
                                                                          str(self.value)[20:], self.created,
                                                                          self.updated)


@traced('__init__', 'exist')
@logged
class EngineManager(object):
    def __init__(self, driver, model_store_to_db, model_store_to_local):
        db.create_all()
        driver.verify_model(EngineModel)
        self._driver = driver
        self._model_store_to_local = model_store_to_local
        self._model_store_to_db = model_store_to_db

    def save(self, name, version, hash, language, resource_path, data, force=False):
        if force or (
                self._model_store_to_local and not self._exist_in_local(name, version, hash, language, resource_path)):
            self._save_to_local(name, version, hash, language, resource_path, data)

        if force or (self._model_store_to_db and not self._exist_in_db(name, version, hash, language)):
            self._save_to_db(name, version, hash, language, data)

    def _save_to_local(self, name, version, hash, language, resource_path, data):
        try:
            binary_data = pickle.dumps(data)
            with open(self._model_path(name, version, hash, language, resource_path), "wb") as fp:
                fp.write(binary_data)
            return True
        except Exception as e:
            self.__log.error(e)
            return False

    def _save_to_db(self, name, version, hash, language, data):
        try:
            binary_data = pickle.dumps(data)
            engine_model = EngineModel(name=name, version=version, hash=hash, language=language, value=binary_data)
            self._driver.upsert(engine_model)
            return True
        except Exception as e:
            self.__log.error(e)
            return False

    def restore(self, name, version, hash, language, resource_path):
        if self._exist_in_local(name, version, hash, language, resource_path):
            return self._restore_from_local(name, version, hash, language, resource_path)
        elif self._exist_in_db(name, version, hash, language):
            return self._restore_from_db(name, version, hash, language)
        else:
            raise Exception("학습된 모델을 찾을수 없습니다")

    def _restore_from_local(self, name, version, hash, language, resource_path):
        with open(self._model_path(name, version, hash, language, resource_path), "rb") as fp:
            return pickle.loads(fp.read())

    def _restore_from_db(self, name, version, hash, language):
        selected_data = self._driver.select(EngineModel,
                                            [EngineModel.name == name, EngineModel.version == version,
                                             EngineModel.hash == hash, EngineModel.language == language])
        if len(selected_data) <= 0:
            raise FileNotFoundError("데이터베이스 내 모델 파일을 찾을 수 없습니다.(version:{}, hash:{})".format(version, hash))
        byte_data = selected_data[0].value
        return pickle.loads(byte_data)

    def exist(self, name, version, hash, language, resource_path):
        if self._exist_in_local(name, version, hash, language, resource_path):
            return True
        elif self._exist_in_db(name, version, hash, language):
            return True
        else:
            return False

    def _exist_in_local(self, name, version, hash, language, resource_path):
        return os.path.exists(self._model_path(name, version, hash, language, resource_path))

    def _exist_in_db(self, name, version, hash, language):
        try:
            selected_data = self._driver.select(EngineModel, [EngineModel.name == name, EngineModel.version == version,
                                                              EngineModel.hash == hash,
                                                              EngineModel.language == language])
            return len(selected_data) > 0
        except Exception as e:
            self.__log.error(e)
            return False

    def _model_path(self, name, version, hash, language, resource_path):
        return os.path.join(resource_path.model_path, "{}.{}.{}.{}".format(name, version, hash, language))
