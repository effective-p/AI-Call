# -*- coding: utf-8-*-

from selvybot.db import DatabaseDriver

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/12"


class MysqlDriver(DatabaseDriver):
    def __init__(self, host, port, user, password, db_name, dbapi=None):
        dialect = "mysql"
        if dbapi:
            dialect = "{}+{}".format(dialect, dbapi)

        address = '{}://{}:{}@{}:{}/{}?use_unicode=1&charset=utf8mb4'.format(dialect,
                                                                             user,
                                                                             password,
                                                                             host,
                                                                             port,
                                                                             db_name)
        self._config = dict()
        self._config['SQLALCHEMY_DATABASE_URI'] = address
        self._config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        self._config['SQLALCHEMY_POOL_SIZE'] = 5
        self._config['SQLALCHEMY_POOL_TIMEOUT'] = 20
        self._config['SQLALCHEMY_POOL_RECYCLE'] = 500
        self._config['SQLALCHEMY_MAX_OVERFLOW'] = 20
