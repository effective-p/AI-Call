docker build -t $TAG .
