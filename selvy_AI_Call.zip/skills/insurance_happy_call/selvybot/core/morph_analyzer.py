# -*- coding: utf-8-*-
from oktpy.twitter import Twitter
from svlog import logged

from selvybot.util import Singleton, white_space_remove, number_characterize

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/01"


@logged
class MorphAnalyzerRaw(Twitter):
    def __init__(self, entity_list):
        super().__init__()
        # TODO jskim 개체명인식기에서 쓰기 위한 작업
        self.addNouns([number_characterize(white_space_remove(e)) for v in entity_list.values() for e in v])
        # TODO jskim 형태소 분석기를 1번이상 사용하지 않고 multi thread(ex: uwsgi) 환경에서 사용할경우 segmentation fault발생
        self.pos("안녕하세요")


class MorphAnalyzer(MorphAnalyzerRaw, metaclass=Singleton):
    pass
