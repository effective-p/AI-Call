# -*- coding: utf-8-*-

from datetime import datetime

from selvybot.function import Function

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/05/31"


class Time(Function):
    """
    시간 정보를 얻기 위한 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::get_current_time(%Y-%m-%d)> # strf format 입력

    """

    def build(self, param):
        converted_param = param.encode('unicode-escape').decode()
        if converted_param == param:
            def core():
                return datetime.now().strftime(param)
        else:
            def core():
                return datetime.now().strftime(converted_param).encode().decode('unicode-escape')
        # param 문법이 정상적인지 테스트
        core()
        self._core = core
        return True

    def run(self, context, text):
        """
        시간 정보를 생성한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 시간 정보.

        """
        return self._core()
