# -*- coding: utf-8-*-
import os

from selvybot.function import Function

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/16"


class File(Function):
    """
    static file을 http link 형태로 출력하는 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::file(파일 이름)>

    """

    def build(self, file_path):
        """
        파일 경로가 정상적인지 확인

        Args:
            file_path (str): 파일 경로
        Returns:
            bool, 빌드 성공/실패 여부

        """

        abs_path = os.path.join(self._resource_path.static_path, file_path)

        if not os.path.isfile(abs_path):
            raise Exception("파일 경로가 잘못되었습니다. : {}".format(file_path))
        self._output = self.generate(self._resource_path.domain_url, file_path)
        return True

    @staticmethod
    def generate(domain_url, file_path):
        return "{}/resource/{}".format(domain_url, file_path)

    def run(self, context, text):
        """
        static file의 도메인 주소가 반영된 http link를 반환한다

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, http  link.

        """
        return self._output
