# -*- coding: utf-8-*-
import re

from py_expression_eval import Parser

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/06/01"


class Compute(Function):
    PARSER = Parser()
    """
    연산 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::compute(1+3)> # 수식 연산식을 넣는다
            - <function::compute(2*3+1)>

    """

    def build(self, expression, utter=''):
        if VariableReplacer().check(expression):
            def dynamic_result(context):
                replaced_expression = VariableReplacer().run(context, expression)
                return str(Compute.PARSER.parse(replaced_expression).evaluate({}))
        else:
            r = str(Compute.PARSER.parse(expression).evaluate({}))

            def dynamic_result(context):
                return r

        if not utter:
            self._formatting = lambda context: dynamic_result(context)
        else:
            dynamic_utter = VariableReplacer().dynamic(utter)
            self._formatting = lambda context: re.sub(r'%s', dynamic_result(context), dynamic_utter(context))

        return True

    def run(self, context, text):
        """
        수식 연산 결과를 생성한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 수식 연산 결과.

        """
        return self._formatting(context)
