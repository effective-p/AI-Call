# -*- coding: utf-8-*-
import re

from svlog import logged

from selvybot.error.resource import ResourceGetFailedError
from selvybot.function import Function
from selvybot.util import requests_retry_session

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/06/05"


@logged
class GetTmrwForecast(Function):
    """
    내일 일기예보 정보를 얻기 위한 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::get_tmrw_forecast(50.3, 123.3)>

    """

    def build(self, wherex, wherey, format_str):
        self._url = self._resource_path.components_url + "/weather"

        def get_tmrw_forecast(context):
            try:
                resp = requests_retry_session().post(self._url,
                                                     json={'wherex': wherex, 'wherey': wherey, 'whenday': 1,
                                                           'starttime': 0,
                                                           'endtime': 24})
                if resp.status_code != 200 and resp:
                    raise ResourceGetFailedError("weather", resp.text)
                res_data = resp.json()
                if res_data['success'] != "TRUE":
                    raise Exception('날씨 정보를 얻어오는데 실패함')

                utter = format_str
                for key, value in sorted(res_data.items(), reverse=True):
                    utter = re.sub(r'%' + key, str(value), utter)
                output = utter

            except:
                output = "제가 이해하기 어려운 내용입니다."

            return output

        self._core = get_tmrw_forecast
        return True

    def run(self, context, text):
        """
        내일 일기예보 정보를 생성한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 날씨 정보.

        """

        return self._core(context)
