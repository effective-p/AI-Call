# -*- coding: utf-8-*-

from selvybot.function import Function

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/07/09"


class Separator(Function):
    """
    메신저 플랫폼에서 챗봇의 연속 발화를 위한 구분자 출력 함수.

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::separator()>

    """

    def run(self, context, text):
        """
        메신저에서 챗봇 연속 발화를 위한 separator 출력

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 연속 발화 구분자.

        """
        return ""
