# -*- coding: utf-8-*-

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function
from selvybot.function.file import File

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/07/09"


class Image(Function):
    """
    메신저 플랫폼의 이미지 출력을 위한 함수
    카카오톡, 텔레그램의 'photo' 타입

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::image(test.jpg, 300, 250)> # 출력할 이미지 주소와 크기를 인자로 넘겨줌

    """

    def build(self, url, width, height):
        self._dynamic_url = VariableReplacer().dynamic(url)
        self._dynamic_width = VariableReplacer().dynamic(width)
        self._dynamic_height = VariableReplacer().dynamic(height)
        return True

    def run(self, context, text):
        """
        메신저의 이미지 출력 포맷으로 변환한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            dict, 이미지 출력 포맷.

        """
        format_body_dict = dict()
        url = self._dynamic_url(context)
        if not url.startswith("http"):
            url = File.generate(self._resource_path.domain_url, url)
        format_body_dict['url'] = url
        format_body_dict['width'] = int(self._dynamic_width(context))
        format_body_dict['height'] = int(self._dynamic_height(context))
        return {'image': format_body_dict}
