# -*- coding: utf-8-*-
import json
import os
import re

from selvybot.function import Function
from selvybot.function.file import File
from selvybot.schema.type import PATTERN_STR_FUNCTION

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/10/26"


class Payload(Function):
    """
    메신저 플랫폼별 특수한 UI를 사용하기 위한 함수
    각 메신저에서 정의하는 UI를 출력하기 위한 메시지 json 데이터를 utf-8 파일로 작성하고 resource/static 폴더에 위치한다.

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::payload(payload_fb.json, "facebook")> # 2번쨰 인자를 명시할 경우 특정 플랫폼에만 대응
            - <function::payload(payload_kakao.json, "kakaotalk")>
            - <function::payload(payload.json)> # 2번쨰 인자를 명시하지 않을 경우 특정 플랫폼에만 대응

    """
    def build(self, file_path, platform=""):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            file_path (str): payload 파일경로
            platform (str): 플랫폼 명

        Returns:
            bool, 빌드 성공/실패 여부

        """
        abs_path = os.path.join(self._resource_path.static_path, file_path)
        if not os.path.isfile(abs_path):
            raise Exception("파일 경로가 잘못되었습니다. : {}".format(file_path))

        self._platform = platform
        with open(abs_path, "r", encoding='utf-8') as fp:
            self._data = json.load(fp)

        def convert_to_url(elem):
            if isinstance(elem, dict):
                for k, v in elem.items():
                    elem[k] = convert_to_url(v)
                return elem
            elif isinstance(elem, list):
                for idx, v in enumerate(elem):
                    elem[idx] = convert_to_url(v)
                return elem
            elif isinstance(elem, str):
                text = re.sub(PATTERN_STR_FUNCTION, lambda x: File.generate(self._resource_path.domain_url, x.group(2)), elem)
                return text
            else:
                return elem

        convert_to_url(self._data)

        return True

    def run(self, context, text):
        """
        플랫폼별 메시지 payload형태로 데이터를 반환, 플랫폼이 다를 경우 생략됨

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 버튼 출력 래핑.

        """
        if self._platform and '$platform' in context.local and self._platform == context.local['$platform']:
            return self._data
        else:
            return None
