# -*- coding: utf-8-*-
from abc import ABCMeta, abstractmethod

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


class PostProcess(metaclass=ABCMeta):
    """
    후처리
    """

    @abstractmethod
    def run(self, context, text):
        """
        챗봇 발화 문장을 정제한다.
        Args:
            context (Context):  context 객체.
            text (str): 챗봇 발화.

        Returns:
            str, 정제된 챗봇 발화

        """
        pass
