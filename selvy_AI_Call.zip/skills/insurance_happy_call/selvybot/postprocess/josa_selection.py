# -*- coding: utf-8-*-
from svlog import getLogger

from selvybot.util import SingletonFactory
from selvybot.postprocess import PostProcess
from selvybot.postprocess.korean.korean_josa_selection import KoreanJosaSelection

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


class DummyJosaSelection(PostProcess):
    def run(self, context, text):
        return text


class JosaSelection(metaclass=SingletonFactory):
    @staticmethod
    def factory(language, *args, **kwargs):
        if language == "korean":
            return KoreanJosaSelection(*args, **kwargs)
        else:
            getLogger().warn("{}, 해당언어를 지원하지 않습니다.")
            return DummyJosaSelection()
