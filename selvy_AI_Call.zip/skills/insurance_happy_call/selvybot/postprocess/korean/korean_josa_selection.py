# -*- coding: utf-8-*-
import re

from selvybot.postprocess import PostProcess

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/04/20"

HANGUL = '[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]'
CHARACTER = '[a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힣]'
JOSA_REGEX = re.compile('%s(<와>과|<을>를|<은>는|<아>야|<으>로|<이>%s)' % (CHARACTER, HANGUL))


def repl(var):
    left = var.group(1)[1]
    right = var.group(1)[3]
    prev = var.group()[0]

    char_code = ord(prev)
    # 한글 코드 영역(가 ~ 힣) 아닌 경우
    if char_code < 0xac00 or char_code > 0xD7A3:
        return prev + right

    local_code = char_code - 0xac00  # '가' 이후 로컬 코드
    jong_code = local_code % 28

    # 종성이 없는 경우
    if jong_code == 0:
        return prev + right

    if left == '으':  # <으>로
        if jong_code == 8:  # ㄹ 종성인 경우
            return prev + right
        else:
            return prev + left + right
    elif left == '이':
        # 만약 prev가 사람이름이 아니면 prev + left 만 출력 해야함
        # if is_human_name(prev) == false:
        #    return prev + left
        return prev + left + right
    else:
        return prev + left


class KoreanJosaSelection(PostProcess):
    def __init__(self, resource_path):
        pass
    
    def run(self, context, text):
        result_text = re.sub(JOSA_REGEX, repl, text)
        return result_text
