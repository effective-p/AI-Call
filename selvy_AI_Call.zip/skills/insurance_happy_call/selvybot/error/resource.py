__author__ = "Glenn D. Lim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2018/05/24"


class ResourceLoadFailedError(Exception):
    def __init__(self, resource_name, error_data=None, note=None):
        self._resource_name = resource_name
        self._error_data = error_data
        self._note = note if note != '' else " 리소스 로드에 실패하였습니다."

    def __str__(self):
        return "{}::{} {}".format(self._resource_name, self._error_data, self._note)


class ResourceGetFailedError(Exception):
    def __init__(self, resource_name, error_data=None, note=None):
        self._resource_name = resource_name
        self._error_data = error_data
        self._note = note if note != '' else " 리소스에 접근 실패하였습니다."

    def __str__(self):
        return "{}::{} {}".format(self._resource_name, self._error_data, self._note)


class ResourceSavedFailedError(Exception):
    def __init__(self, resource_name, error_data=None, note=None):
        self._resource_name = resource_name
        self._error_data = error_data
        self._note = note if note != '' else " 리소스 저장에 실패하였습니다."

    def __str__(self):
        return "{}::{} {}".format(self._resource_name, self._error_data, self._note)
