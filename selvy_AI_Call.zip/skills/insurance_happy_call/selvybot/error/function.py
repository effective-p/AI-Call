import os

__author__ = "Glenn D. Lim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2018/05/24"


class FunctionError(Exception):
    def __init__(self, file_path, node_name, section_name, error_data=None, note=None):
        self._file_path = os.path.realpath(file_path)
        self._node_name = node_name
        self._section_name = section_name
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}::{}::{} {}".format(self._file_path, self._node_name, self._section_name, self._error_data, self._note)
