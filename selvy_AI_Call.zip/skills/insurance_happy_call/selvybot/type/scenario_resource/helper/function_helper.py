# -*- coding: utf-8-*-

from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/02"


class FunctionHelper(Helper):
    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'function' in attrib

    def __init__(self, parser, section_name, attrib):
        resource_path = parser._resource_path
        function_list = parser._function_list
        file_path = parser._file_path
        node_name = parser._node_name
        function_name = attrib['function']
        params = attrib['params']

        f = function_list[function_name](file_path, node_name, section_name, attrib, resource_path)
        if not f.build(*params):
            raise Exception('함수 빌드 실패')
        self._func = f

    def run(self, assemble_utterance_func, context, responses, text):
        assemble_utterance_func(context, responses, [self._func], text)
