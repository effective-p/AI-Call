# -*- coding: utf-8-*-
from datetime import datetime, timedelta

from svlog import logged

from selvybot.core.scheduler import Scheduler
from selvybot.core.variable_replacer import VariableReplacer
from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/01"


@logged
class DelayHelper(Helper):
    PARAM_KEYS = set(['seconds'])

    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'delay' in attrib

    def __init__(self, parser, section_name, attrib):
        name = attrib['delay']
        messages = [parser.run(section_name, t) for t in attrib['then']]
        params = dict(attrib['params'])
        if 'dnd_timer' in params:
            dnd_timer = int(params['dnd_timer'])
            params.pop('dnd_timer', None)
        else:
            dnd_timer = 0

        if 'context_reset' in params:
            context_reset = True if params['context_reset'] == 'True' else False
            params.pop('context_reset', None)
        else:
            context_reset = False


        if not set(params.keys()).issubset(DelayHelper.PARAM_KEYS):
            raise Exception('delay: parameter가 잘못 입력되었습니다.')

        dynamic_params = dict()
        for k, v in params.items():
            dynamic_params[k] = VariableReplacer().dynamic(v)

        self._scheduler = Scheduler()
        self._dnd_timer = dnd_timer
        self._job_id = name
        self._dynamic_params = dynamic_params
        self._scheduler_params = {'trigger': 'date'}
        self._messages = messages
        self._context_reset = context_reset

    def run(self, assemble_utterance_func, context, responses, text):
        if not context.local['$reply_url']:
            return

        alarm_responses = [{"text": ""}]
        for result in self._messages:
            assemble_utterance_func(context, alarm_responses, result, text)

        datetime_params = dict()
        for k, v in self._dynamic_params.items():
            datetime_params[k] = int(v(context))

        time = datetime.now() + timedelta(**datetime_params)
        params = dict(self._scheduler_params)
        params['run_date'] = time.strftime("%Y-%m-%d %H:%M:%S")

        self._scheduler.post(user_id=context.system['user'],
                             job_id=self._job_id,
                             reply_url=context.local['$reply_url'],
                             utterances=alarm_responses,
                             params=params,
                             dnd_timer=self._dnd_timer,
                             context_reset=self._context_reset)
