# -*- coding: utf-8 -*-

import os

from svlog import logged

from selvybot.schema.type import PATTERN_VAR
from selvybot.type.scenario_resource.helper import Helper


__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/11/28"


@logged
class EnvHelper(Helper):
    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'env' in attrib

    def __init__(self, parser, section_name, attrib):
        target = attrib['env']
        values = [parser.run(section_name, v) for v in attrib['values']]
        default = [parser.run(section_name, v) for v in attrib['default']]

        match_result = PATTERN_VAR.match(target)
        if not bool(match_result):
            raise SyntaxError('assign 함수의 첫번째 인자는 variable 형태를 취해야 합니다.')
        self._loc, self._var_name = match_result.groups()
        if self._loc == '~':
            self.__log.warn('system \"{}\"변수를 수정하고 있습니다.'.format(self._var_name))

        if default:
            self._values = [os.environ[v] if v in os.environ else default[0] for v in values]
        else:
            self._values = [os.environ[v] if v in os.environ else None for v in values]

    def run(self, assemble_utterance_func, context, responses, text):
        # TODO jskim assign 함수는 text만 assign 가능
        temp_responses = [{"text": ""}]
        for v in self._values:
            if not v:
                continue
            assemble_utterance_func(context, temp_responses, v, text)
        value = "".join([resp['text'] for resp in temp_responses])

        if self._loc == '$$':
            storage = context.local
        elif self._loc == '$':
            storage = context.glob
        else:
            storage = context.system
        storage[self._var_name] = value
