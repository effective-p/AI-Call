# -*- coding: utf-8-*-
from abc import ABCMeta, abstractmethod

from svlog import logged

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/02"


@logged
class Helper(metaclass=ABCMeta):
    """
    시나리오 문법의 해석 및 실행을 도와주는 Helper 객체
    """

    @staticmethod
    def check(attrib):
        """입력된 attribute가 현재 Helper객체가 해석할수 있는 형태인가?

        Args:
            attrib(object): 시나리오 섹션의 값(str, list, dict, function, ...)

        Returns:
            bool, 해석 가능 여부

        """
        return False

    @abstractmethod
    def run(self, assemble_utterance_func, context, responses, text):
        """학습된 모델을 메모리에 적재한다.

        Args:
            assemble_utterance_func (function): 챗봇발화를 조립할수 있는 함수, Searcher에서 넘겨받는다.
            context (Context):  context 객체.
            responses(list of dict): 챗봇 발화 목록
            text(str): 사용자가 입력한 메시지

        Returns:
            None
        """
        pass
