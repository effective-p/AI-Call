# -*- coding: utf-8-*-

from selvybot.core.condition_checker import ConditionChecker
from selvybot.type.scenario_resource.helper import Helper
from selvybot.type.scenario_resource.helper.cron_helper import CronHelper
from selvybot.type.scenario_resource.helper.delay_helper import DelayHelper
from selvybot.type.scenario_resource.helper.unschedule_helper import UnscheduleHelper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/12"


class IFStatementHelper(Helper):
    # 허용하는 하위 객체의 Helper들을 작성
    ALLOW_SUB_OBJECT = [CronHelper, DelayHelper, UnscheduleHelper]

    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'if' in attrib

    def _search_helper_for_sub_object(self, object):
        target_helper = None
        for current_helper in self.ALLOW_SUB_OBJECT:
            if current_helper.check(object):
                target_helper = current_helper
                break
        return target_helper

    def _parse_state(self, target_attr, section_name, parser):
        result_list = []
        for attr in target_attr:
            if isinstance(attr, dict) == False:
                result_list.append(parser.run(section_name, attr))
                continue
            else:
                target_helper = self._search_helper_for_sub_object(attr)
                if target_helper is not None:
                    result_list.append(target_helper(parser, 'chatbot', attr))
        return result_list

    def __init__(self, parser, section_name, attrib):
        self._condition = parser.run(section_name, attrib['if'])
        self._true_result = self._parse_state(attrib['then'], section_name, parser)
        self._false_result = self._parse_state(attrib['else'], section_name, parser)

    def run(self, assemble_utterance_func, context, responses, text):
        result_list = self._true_result if ConditionChecker().run(context, self._condition,
                                                                  text) else self._false_result
        for result in result_list:
            if isinstance(result, Helper):
                result.run(assemble_utterance_func, context, responses, text)
                continue
            assemble_utterance_func(context, responses, result, text)
