# -*- coding: utf-8-*-
import json
import os
import io
import re

from svlog import getLogger

from selvybot.util import yml
from selvybot.variable import FRAMEWORK_ROOT

__author__ = "Demian Haksik Yang"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "demian.h.yang@selvas.com"
__date__ = "2018/10/01"

SCHEMA_PATH = FRAMEWORK_ROOT + "/schema/meta_schema.json"
SCHEMA = json.load(open(SCHEMA_PATH, 'r', encoding='utf-8'))
META_FILE = "meta.yml"

DEFAULT_META = {'name': 'selvybot',
                'version': '1.0.0',
                'release_date': '1900-01-01',
                'history': ['release'],
                'comment': '',
                'project': {
                    'name': 'selvybot',
                    'organization': 'SelvasAI',
                    'start_date': '1900-01-01',
                    'comment': ''}
                }

logger = getLogger()


class Meta(dict):
    def __init__(self, data):
        self.update(data)


def load(file_path):
    file_path = os.path.join(file_path, META_FILE)
    try:
        meta_data = yml.load(file_path, SCHEMA)
    except Exception as e:
        logger.warn("메타 데이터 로드에 실패했습니다.")
        logger.warn(e)
        meta_data = DEFAULT_META

    return Meta(meta_data)

def patch_update(file_path):
    file_path = os.path.join(file_path, META_FILE)
    try:
        meta_data = yml.load(file_path, SCHEMA)

        version_regex = '(\d+)\.(\d+)\.(\d+)'
        regex_result = re.search(version_regex, meta_data['version'])
        if len(regex_result.groups()) == 3:
            patch_version = str(int(regex_result.groups()[2]) + 1)
            meta_data['version'] = re.sub(version_regex, r'\1.\2.', meta_data['version']) + patch_version
        with open(file_path, "w", encoding='utf-8') as f:
            f.write(yml.dump(meta_data) + "\n")

    except Exception as e:
        logger.warn("메타 데이터 패치 버전 업데이트에 실패했습니다.")
        logger.warn(e)
        meta_data = DEFAULT_META

    return Meta(meta_data)

def dump_json(meta):
    memory_file = io.StringIO()
    memory_file.writelines(json.dumps(meta))
    memory_file.seek(0)
    return memory_file.read()