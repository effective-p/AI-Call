# -*- coding: utf-8-*-
import copy
import glob
import io
import json
from collections import namedtuple, OrderedDict

import xlrd
import xlsxwriter
from svlog import logged, traced

from selvybot.core.parameter_splitter import ParameterSplitter
from selvybot.error.scenario import *
from selvybot.schema.type import PATTERN_FUNCTION
from selvybot.type.scenario_resource.helper.assign_helper import AssignHelper
from selvybot.type.scenario_resource.helper.cron_helper import CronHelper
from selvybot.type.scenario_resource.helper.delay_helper import DelayHelper
from selvybot.type.scenario_resource.helper.env_helper import EnvHelper
from selvybot.type.scenario_resource.helper.function_helper import FunctionHelper
from selvybot.type.scenario_resource.helper.if_statement_helper import IFStatementHelper
from selvybot.type.scenario_resource.helper.switch_statement_helper import SwitchStatementHelper
from selvybot.type.scenario_resource.helper.unassign_helper import UnAssignHelper
from selvybot.type.scenario_resource.helper.unschedule_helper import UnscheduleHelper
from selvybot.type.scenario_resource.section import check_section, FunctionError
from selvybot.util import yml, is_reachable, first_key, convert_to_list
from selvybot.variable import FRAMEWORK_ROOT

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/12"

SCHEMA_PATH = FRAMEWORK_ROOT + "/schema/scenario.schema.json"
SCHEMA = json.load(open(SCHEMA_PATH, 'r', encoding='utf-8'))

NODE_VALUE = namedtuple("NODE_VALUE",
                        "cond user chatbot jump next")

JUMP_VALUE = namedtuple("JUMP_VALUE",
                        "node cond")
NEXT_VALUE = namedtuple("NEXT_VALUE",
                        "node cond")


class MessageParser(object):

    def __init__(self, resource_path, function_list, file_path, node_name):
        self._resource_path = resource_path
        self._function_list = function_list
        self._file_path = file_path
        self._node_name = node_name

    def run(self, section_name, value):
        if isinstance(value, list):
            return self._parse_list(section_name, value)
        else:
            return self._parse(section_name, value)

    def _parse_list(self, section_name, values):
        return [self._parse(section_name, value) for value in values]

    def _parse(self, section_name, value):
        matched = PATTERN_FUNCTION.match(value)
        if bool(matched):
            try:
                func = self._function_list[matched.group(1)](self._file_path, self._node_name, section_name, value,
                                                             self._resource_path)
                if not func.build(*ParameterSplitter().run(matched.group(2))):
                    raise Exception('False를 반환')
                return func
            except Exception as e:
                raise FunctionError(self._file_path, self._node_name, section_name, value, "빌드 실패: {}".format(str(e)))
        else:
            return value


@logged
class Scenario(OrderedDict):
    def __init__(self, nodes, intent_list, function_list, resource_path):
        self.resource_path = resource_path
        # 데이터 정제
        for name, attrib in nodes.items():
            nodes[name] = self._refine_attrib(name, attrib)

        # 섹션의 값이 다른 노드를 가리키고 있는 경우 해당노드의 값을 가져와서 채운다.
        for name, attrib in nodes.items():
            if name == "root":
                continue
            if not isinstance(attrib['chatbot'], list):
                attrib['chatbot'] = self._get_value(nodes, attrib['chatbot'], 'chatbot')
            if not isinstance(attrib['user'], list):
                attrib['user'] = self._get_value(nodes, attrib['user'], 'user')
            nodes[name] = attrib

        # 검증
        if not self._validation_check(nodes, intent_list, function_list):
            raise Exception()
        self._generate_scenario(nodes, function_list, resource_path)
        self._serialize_obj = {'nodes': [], 'edges': [], 'dashed_edges': []}
        for node, value in self.items():
            self._serialize_obj['nodes'].append(node)
            for next in value.next:
                self._serialize_obj['edges'].append((node, next.node))
            if value.jump:
                for jump in value.jump:
                    self._serialize_obj['dashed_edges'].append((node, jump.node))

    def serialize(self):
        return self._serialize_obj

    def export_script(self):
        memory_file = io.BytesIO()
        book = xlsxwriter.Workbook(memory_file)
        locked_format = book.add_format({"text_wrap": True, 'locked': 1})
        text_format = book.add_format({'text_wrap': True})
        title_format = book.add_format({'bold': True})
        ws = book.add_worksheet("script")
        ws.set_column(0, 0, 20)
        ws.set_column(2, 2, 200)
        ws.write_row("A1", ("NODE", "IDX", "SCRIPT"), title_format)
        ws.freeze_panes(1, 0)
        index = 1
        for node, section in self.items():
            if not isinstance(section.chatbot, list):
                continue
            for eid, elements in enumerate(section.chatbot):
                if not isinstance(elements, list) or any(not isinstance(e, str) for e in elements):
                    continue
                begin_index = index
                for e in elements:
                    ws.write(index, 0, node, locked_format)
                    ws.write(index, 1, eid, locked_format)
                    ws.write(index, 2, e, text_format)
                    index += 1
                if len(elements) > 1:
                    ws.merge_range(begin_index, 0, index - 1, 0, node, text_format)
                    ws.merge_range(begin_index, 1, index - 1, 1, eid, text_format)
        book.close()
        memory_file.seek(0)
        return memory_file.read()

    def import_script(self, script):
        # TODO jskim dict error message 친절하게 raise

        book = xlrd.open_workbook(script)
        ws = book.sheet_by_name("script")

        script_data = {}
        for index in range(1, ws.nrows):
            row = ws.row_values(index)
            if row[0] != '':
                node = row[0]
            if row[1] != '':
                eid = int(row[1])
            script = row[2]
            assert script
            if node not in script_data:
                script_data[node] = OrderedDict()

            if eid in script_data[node]:
                script_data[node][eid].append(script)
            else:
                script_data[node][eid] = [script]

        new_one = copy.deepcopy(OrderedDict(self))
        for node, d in script_data.items():
            for eid, element in d.items():
                if any(not isinstance(e, str) for e in new_one[node].chatbot[eid]):
                    raise Exception()
                new_one[node].chatbot[eid] = element

        file_paths = list(glob.glob(self.resource_path.scenario_path + "/*.yml"))

        if len(file_paths) == 0:
            raise Exception("시나리오 경로를 찾을수 없습니다.")

        # TODO jskim yml node 순서가 바뀌는 문제 수정
        for file_path in file_paths:
            yml_data = yml.load(file_path, SCHEMA)

            for node in yml_data.keys():
                if node not in script_data:
                    continue
                for eid, element in script_data[node].items():
                    yml_data[node]['chatbot'][eid] = element
            with open(file_path, "w", encoding='utf-8') as f:
                f.write(yml.dump(yml_data) + "\n")

        # TODO jskim dict 값만 깔끔하게 swap하는 방법 찾아서 적용
        self.clear()
        self.update(new_one)

    def _get_value(self, nodes, name, key):
        if not isinstance(nodes[name][key], list):
            return self._get_value(nodes, nodes[name][key], key)
        else:
            return nodes[name][key]

    def _generate_scenario(self, nodes, function_list, resource_path):
        helper_list = [AssignHelper, EnvHelper, CronHelper, DelayHelper, FunctionHelper, IFStatementHelper, SwitchStatementHelper,
                       UnAssignHelper, UnscheduleHelper]
        for node_name, sections in sorted(nodes.items()):
            parser = MessageParser(resource_path, function_list, sections['$path'], node_name)

            next_section = []
            for attrib in sections['next']:
                cond = parser.run('next', attrib.cond) if attrib.cond else None
                next_section.append(NEXT_VALUE(attrib.node, cond))

            if node_name == 'root':
                node_value = NODE_VALUE(None, None, None, None, next_section)
            else:
                # cond
                cond_section = []
                if 'cond' in sections:
                    for attrib in sections['cond']:
                        attrib = parser.run('cond', attrib)
                        cond_section.append(attrib)

                # user
                user_section = sections['user']

                # chatbot
                chatbot_section = []
                for attrib in sections['chatbot']:
                    processed = False
                    for helper in helper_list:
                        if helper.check(attrib):
                            processed = True
                            element = helper(parser, 'chatbot', attrib)
                            break
                    if not processed:
                        element = parser.run('chatbot', attrib)
                    chatbot_section.append(element)
                # jump
                jump_section = []
                for attrib in sections['jump']:
                    cond = parser.run('jump', attrib.cond) if attrib.cond else None
                    jump_section.append(JUMP_VALUE(attrib.node, cond))

                node_value = NODE_VALUE(cond_section, user_section, chatbot_section, jump_section, next_section)

            self[node_name] = node_value

    def _refine_attrib(self, name, attrib):
        # 파싱하기 편한 구조로 변경
        if 'next' in attrib:
            if isinstance(attrib['next'], str):
                attrib['next'] = [NEXT_VALUE(attrib['next'], None)]
            elif isinstance(attrib['next'], list):
                next = []
                for n in attrib['next']:
                    if isinstance(n, dict):
                        node = first_key(n)
                        cond = str(n[node])
                        next.append(NEXT_VALUE(node, cond))
                    else:
                        next.append(NEXT_VALUE(n, None))
                attrib['next'] = next
        else:
            attrib['next'] = []
        if name == 'root':
            return attrib

        # 파싱하기 편한 구조로 변경
        if 'jump' in attrib:
            if isinstance(attrib['jump'], str):
                attrib['jump'] = [JUMP_VALUE(attrib['jump'], None)]
            elif isinstance(attrib['jump'], list):
                jump = []
                for n in attrib['jump']:
                    if isinstance(n, dict):
                        node = first_key(n)
                        cond = str(n[node])
                        jump.append(JUMP_VALUE(node, cond))
                    else:
                        jump.append(JUMP_VALUE(n, None))
                attrib['jump'] = jump
        else:
            attrib['jump'] = []
        # 생략 가능한 인자, list가 아닐수 있는 인자들을 빈 list나 list로 변경하는 작업
        if isinstance(attrib['chatbot'], list):
            for idx, value in enumerate(attrib['chatbot']):
                if isinstance(value, dict):
                    if 'if' in value:
                        value['then'] = convert_to_list(value['then'])
                        value['else'] = value['else'] if 'else' in value else []
                        value['else'] = convert_to_list(value['else'])
                    elif 'switch' in value:
                        for elem in value['switch']:
                            elem['then'] = convert_to_list(elem['then'])
                    elif 'function' in value:
                        value['params'] = value['params'] if 'params' in value else []
                        value['params'] = convert_to_list(value['params'])
                    elif 'env' in value:
                        value['values'] = convert_to_list(value['values'])
                        value['default'] = value['default'] if 'default' in value else []
                        value['default'] = convert_to_list(value['default'])
                    elif 'assign' in value:
                        value['values'] = convert_to_list(value['values'])
                    elif 'unassign' in value:
                        value['unassign'] = convert_to_list(value['unassign'])
                    elif 'unschedule' in value:
                        value['unschedule'] = convert_to_list(value['unschedule'])
                    elif 'cron' in value:
                        value['then'] = convert_to_list(value['then'])
                    elif 'delay' in value:
                        value['then'] = convert_to_list(value['then'])
                    attrib['chatbot'][idx] = value
                elif not isinstance(value, list):
                    attrib['chatbot'][idx] = [value]

        def convert_to_str(elem):
            if isinstance(elem, dict):
                for k, v in elem.items():
                    elem[k] = convert_to_str(v)
                return elem
            elif isinstance(elem, list):
                for idx, v in enumerate(elem):
                    elem[idx] = convert_to_str(v)
                return elem
            else:
                return str(elem)

        # 일부 입력의 경우 str이 아닌 형태(ex: number, boolean)로 넘어와서 이를 str형태로 교정해주는 작업
        attrib['chatbot'] = convert_to_str(attrib['chatbot'])

        return attrib

    def _validation_check(self, nodes, intent_list, function_list):
        node_names = nodes.keys()
        error_list = []
        no_path = [node for node in node_names if not is_reachable(nodes, 'root', node)]
        if len(no_path) != 0:
            error_list.append(Exception("root 노드에서 ({}) 노드들로 연결되는 Path가 없습니다.".format(", ".join(no_path))))
        for node_name, value in nodes.items():
            try:
                check_section(node_name, value, intent_list, function_list, node_names)
            except Exception as e:
                error_list.append(e)

        if error_list:
            print("=== scenario validation failed ===")
            print("\n".join([str(e) for e in error_list]))
            return False
        else:
            return True


@traced
def load(dir_path, intent_list, function_list, resource_path):
    file_paths = list(glob.glob(dir_path + "/*.yml"))
    error_list = []
    nodes = {}

    if len(file_paths) == 0:
        error_list.append(ScenarioNotFoundError(dir_path))

    for file_path in file_paths:
        try:
            data = yml.load(file_path, SCHEMA)
            for _, value in data.items():
                value['$path'] = os.path.basename(file_path)

            for k in data.keys():
                if k in nodes:
                    error_list.append(ScenarioDuplicatedNameError(file_path, k, ''))
            nodes.update(data)
        except Exception as e:
            error_list.append(ScenarioError(file_path, "", "", "", "\n" + str(e)))

    if len(error_list) > 0:
        print(' === scenario load errors === ')
        print('\n'.join([str(e) for e in error_list]))
        exit(1)

    return Scenario(nodes, intent_list, function_list, resource_path)
