# -*- coding: utf-8-*-

import glob

from selvybot.error.warn import *
from selvybot.util import white_space_remove, number_normalize

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


def load(dir_path):
    print(' === entity load === ')
    file_paths = list(glob.glob(dir_path + "/*.txt"))
    entity_list = {}
    synonym_list = {}

    if len(file_paths) == 0:
        ResourceNotFoundWarnings("Entity 파일이 없습니다.", dir_path)

    for file_path in file_paths:
        entity_name = os.path.basename(file_path).split(".")[0]
        entity_list[entity_name] = []
        with open(file_path, "r", encoding='utf-8') as f:
            for num, line in enumerate(f, 1):
                line = number_normalize(line.strip("\n "))
                if line == '':
                    FileSyntaxWarnings('Entity 파일 내 공백을 확인해주세요.', file_path, num)
                    continue
                tokens = line.strip("\n ").split("\t")
                synonym_list.update({white_space_remove(token): tokens[0] for token in tokens})
                entity_list[entity_name].extend([token for token in tokens])

    return entity_list, synonym_list
