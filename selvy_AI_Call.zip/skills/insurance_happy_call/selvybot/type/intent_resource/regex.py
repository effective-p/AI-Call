# -*- coding: utf-8-*-
import re

from selvybot.error.intent import RegexError

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/06/20"


class Regex(object):
    @staticmethod
    def validate(element, slot_name_list, file_path, index):
        if isinstance(element, dict):
            text = element['text']
            slot_tags = element.get('slot_tags', [])
        elif isinstance(element, str):
            text = element
            slot_tags = []
        else:
            raise RegexError(file_path, index, element, 'regex 속성 값의 형태로 적절하지 않습니다.')
        error_list = []
        try:
            re.compile(text)
        except re.error:
            error_list.append(RegexError(file_path, index, text, '정규식이 올바르지 않습니다'))
        for tag in slot_tags:
            if tag not in slot_name_list:
                error_list.append(RegexError(file_path, index, tag, '슬롯이 정의되어 있지 않습니다.'))

        if error_list:
            raise Exception('\n'.join([str(e) for e in error_list]))


def check_regex(node, slot_name_list, file_path):
    error_list = []
    for index, element in enumerate(node):
        try:
            Regex.validate(element, slot_name_list, file_path, index)
        except Exception as e:
            error_list.append(e)
    if error_list:
        raise Exception('\n'.join([str(e) for e in error_list]))
