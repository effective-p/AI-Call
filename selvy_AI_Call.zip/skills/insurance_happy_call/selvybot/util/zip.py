# -*- coding: utf-8-*-
import io
import os
import re
import zipfile

import chardet

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/09/14"


def zip_dir(path, except_list=[]):
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(path):
            for folder_name in dirs + files:
                absolute_path = os.path.join(root, folder_name)
                relative_path = os.path.relpath(absolute_path, path)
                if relative_path in except_list:
                    continue
                z.write(absolute_path, relative_path)

    memory_file.seek(0)
    return memory_file.read()


def zip_byte_array_list(byte_array_list):
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in byte_array_list:
            z.writestr(name, data)

    memory_file.seek(0)
    return memory_file.read()


ZIP_FILENAME_UTF8_FLAG = 0x800
NON_FILE_CHARACTER = re.compile(r'[^[\w\sㄱ-힣[\`\'\˜\=\+\#\ˆ\@\$\&\-\_\.\(\)\{\}\;\[\]]')


def unzip_dir(src_path, dst_path):
    with zipfile.ZipFile(src_path, 'r') as zf:
        for info in zf.infolist():
            if info.flag_bits & ZIP_FILENAME_UTF8_FLAG == 0:
                filename_bytes = info.filename.encode('437')
                guessed_encoding = chardet.detect(filename_bytes)['encoding'] or 'euc-kr'
                filename = filename_bytes.decode(guessed_encoding, 'replace')
                if NON_FILE_CHARACTER.search(filename):
                    filename = filename_bytes.decode('euc-kr', 'replace')
                info.filename = filename

            zf.extract(info, dst_path)
