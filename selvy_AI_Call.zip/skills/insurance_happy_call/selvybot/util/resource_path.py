# -*- coding: utf-8 -*-
import os
import tempfile
import zipfile

from selvybot.util import download_file, silent_remove
from selvybot.util.zip import unzip_dir

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/17"


class ResourcePath(object):
    def __init__(self, components_url, domain_url, resource_root):
        self.domain_url = domain_url
        self.components_url = components_url
        try:
            if resource_root.startswith("http://") or resource_root.startswith("https://"):
                temp_file_name = tempfile.mktemp(suffix='.zip')
                if not download_file(resource_root, temp_file_name):
                    raise Exception("리소스 주소가 잘못되었습니다. => {}".format(resource_root))
                resource_root = temp_file_name

            file_ext = os.path.splitext(resource_root)
            if len(file_ext) == 2 and file_ext[1] == ".zip":
                tmp_dir = tempfile.mkdtemp()
                unzip_dir(resource_root, tmp_dir)
                self.root = os.path.abspath(tmp_dir)
            else:
                self.root = os.path.abspath(resource_root)

            if not os.path.exists(self.scenario_path) and not os.path.exists(self.intent_path):
                raise FileNotFoundError("\n".join(
                    [
                        "리소스 폴더들을 확인해 주세요\n",
                        "scenario path : {}".format(os.path.realpath(self.scenario_path)),
                        "intent path : {}".format(os.path.realpath(self.intent_path)),
                    ]
                ))
            os.makedirs(self.model_path, exist_ok=True)
        finally:
            if 'temp_file_name' in locals():
                silent_remove(temp_file_name)

    @property
    def root_path(self):
        return self.root

    @property
    def scenario_path(self):
        return os.path.join(self.root, "scenario")

    @property
    def intent_path(self):
        return os.path.join(self.root, "intent")

    @property
    def entity_path(self):
        return os.path.join(self.root, "entity")

    @property
    def function_path(self):
        return os.path.join(self.root, "function")

    @property
    def static_path(self):
        return os.path.join(self.root, "static")

    @property
    def model_path(self):
        return os.path.join(self.root, "model")
