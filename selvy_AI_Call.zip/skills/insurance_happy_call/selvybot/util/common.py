# -*- coding: utf-8-*-
import glob
import gzip
import hashlib
import inspect
import os
import re
from io import BytesIO

import requests
import stringcase
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/02"


def class_name(obj):
    if inspect.isclass(obj):
        return stringcase.snakecase(obj.__name__)
    else:
        return stringcase.snakecase(type(obj).__name__)


def convert_to_list(elem):
    return elem if isinstance(elem, list) else [elem]


def white_space_remove(text):
    return text.replace(" ", "")


def number_normalize(text):
    return re.sub('\d+', '0', text)


def number_characterize(text):
    return re.sub('\d+', '영', text)


def last_element(dictionary):
    return dictionary[next(reversed(dictionary))]


def first_element(dictionary):
    return dictionary[next(iter(dictionary))]


def first_key(dictionary):
    return next(iter(dictionary))


def last_key(dictionary):
    return next(reversed(dictionary))


def generate_hash(paths, ext):
    hash_md5 = hashlib.md5()
    for path in paths:
        for filename in sorted(glob.iglob(path + '/**/*' + ext, recursive=True)):
            with open(filename, 'rb') as fp:
                hash_md5.update(fp.read())
    return hash_md5.hexdigest()


def silent_remove(file_path):
    try:
        os.remove(file_path)
    except OSError:
        pass


def compress(byte_data):
    buffer = BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb') as gfile:
        gfile.write(byte_data)
    return buffer.getvalue()


def decompress(zipped_byte_data):
    buffer = BytesIO()
    buffer.write(zipped_byte_data)
    buffer.seek(0)
    with gzip.GzipFile(fileobj=buffer, mode='rb') as gfile:
        byte_data = gfile.read()
    return byte_data


def requests_retry_session(retries=3, backoff_factor=0.3, status_forcelist=(500, 502, 504), session=None):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


def is_reachable(nodes, start, end):
    return len(find_all_paths(nodes, start, end, [], set())) > 0


def get_all_leaf_values(elem):
    if isinstance(elem, dict):
        for k, v in elem.items():
            yield from get_all_leaf_values(v)
    elif isinstance(elem, list):
        for v in elem:
            yield from get_all_leaf_values(v)
    else:
        yield str(elem)


def find_all_paths(nodes, start, end, path, ignore_nodes):
    path = path + [start]
    if start == end:
        return [path]
    if start not in nodes:
        return []
    paths = []
    next_list = []
    if 'next' in nodes[start]:
        next_list.extend([e.node for e in nodes[start]['next']])
    if 'jump' in nodes[start]:
        next_list.extend([e.node for e in nodes[start]['jump']])

    ignore_nodes.add(start)
    for next_node in set(next_list):
        if next_node in ignore_nodes:
            continue
        if next_node not in path:
            new_paths = find_all_paths(nodes, next_node, end, path, ignore_nodes)
            paths.extend(new_paths)
    return paths


def str2bool(v):
    if v.lower() in ("yes", "true", "t", "1"):
        return True
    else:
        return False


def download_file(url, target_path):
    resp = requests.get(url, stream=True)
    if resp.status_code != 200:
        return False
    with open(target_path, 'wb') as fp:
        for c in resp.iter_content(1024):
            fp.write(c)
    return True
