# -*- coding: utf-8-*-
import base64
import json
import os
import re
import socket
import struct
import uuid
import subprocess
import psutil
from datetime import datetime
from random import choice
from string import ascii_uppercase, ascii_lowercase
from threading import Timer

from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from flask_limiter import Limiter
from svlog import getLogger

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/08/06"

logger = getLogger()

BS = AES.block_size
PAD = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS)
UNPAD = lambda s: s[0:-s[-1]]


def encrypt(data):
    padded = PAD(data)
    iv = ''.join(choice(ascii_uppercase + ascii_lowercase) for _ in range(AES.block_size))
    cipher = AES.new((lambda: SHA256.new("SelvasAI".encode('utf-8')).digest())(), AES.MODE_CBC, iv)
    aes = iv.encode('utf-8') + cipher.encrypt(padded)
    encrypted = base64.b64encode(aes).decode('utf-8')
    shuffled = encrypted[int(len(encrypted) / 2):] + encrypted[:int(len(encrypted) / 2)]
    return shuffled


def decrypt(encrypted_data):
    shuffled = encrypted_data[int((len(encrypted_data) + 1) / 2):] + encrypted_data[:int((len(encrypted_data) + 1) / 2)]
    aes = base64.b64decode(shuffled.encode('utf-8'))
    iv = aes[:AES.block_size].decode('utf-8')
    cipher = AES.new((lambda: SHA256.new("SelvasAI".encode('utf-8')).digest())(), AES.MODE_CBC, iv)
    return UNPAD(cipher.decrypt(aes[AES.block_size:])).decode('utf-8')


def get_time(addr='time.nist.gov'):
    TIME1970 = 2208988800
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    data = '\x1b' + 47 * '\0'
    client.sendto(data.encode('ascii'), (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
        t = struct.unpack('!12I', data)[10]
        t -= TIME1970
        return datetime.fromtimestamp(t)
    else:
        datetime.now()


def get_mac():
    return ':'.join(re.findall('..', '%012x' % uuid.getnode()))


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('8.8.8.8', 1))
        ip = s.getsockname()[0]
    except:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


def terminate():
    is_running_by_supervisord = False
    for process in psutil.process_iter():
        if 'supervisord' in process.name():
            is_running_by_supervisord = True

    if is_running_by_supervisord == True:
        cmd = 'supervisorctl stop all'
        subprocess.run(cmd.split())
    else:
        os._exit(1)

def check(key, app):
    try:
        assert key
        data = json.loads(decrypt(key))
    except:
        timer = Timer(60 * 60 * 24, lambda: terminate())
        timer.daemon = True
        timer.start()
        Limiter(
            app,
            key_func=lambda: "always",
            default_limits=["300 per hour"]
        )
        return

    if 'limit_run_time' in data:
        timer = Timer(int(data['limit_run_time']), lambda: terminate())
        timer.daemon = True
        timer.start()
    if 'due_date' in data:
        from datetime import datetime
        expiration_date = datetime.strptime(data['due_date'], "%Y-%m-%d")
        if expiration_date < get_time():
            logger.error("기간이 만료되었습니다.")
            terminate()
    if 'api_limit' in data:
        limit_list = data['api_limit'] if isinstance(data['api_limit'], list) else [data['api_limit']]
        Limiter(
            app,
            key_func=lambda: "always",
            default_limits=limit_list
        )
    if 'mac_address' in data:
        possible_list = data['mac_address'] if isinstance(data['mac_address'], list) else [data['mac_address']]
        possible_list = [p.lower() for p in possible_list]
        if get_mac() not in possible_list:
            logger.error("사용할수 없는 서버입니다")
            terminate()
    if 'ip_address' in data:
        possible_list = data['ip_address'] if isinstance(data['ip_address'], list) else [data['ip_address']]
        if get_ip() not in possible_list:
            logger.error("사용할수 없는 서버입니다")
            terminate()
