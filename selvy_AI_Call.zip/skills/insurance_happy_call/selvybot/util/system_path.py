# -*- coding: utf-8-*-
import os

from selvybot.util.singleton import Singleton
from selvybot.variable import FRAMEWORK_ROOT

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/03"


class SystemPathRaw(object):
    def __init__(self):
        self.root = FRAMEWORK_ROOT
        self.function_path = os.path.join(FRAMEWORK_ROOT, "function")
        self.resource_path = os.path.join(FRAMEWORK_ROOT, "resource")
        self.intent_path = os.path.join(FRAMEWORK_ROOT, "resource/intent")
        self.entity_path = os.path.join(FRAMEWORK_ROOT, "resource/entity")
        self.static_path = os.path.join(FRAMEWORK_ROOT, "resource/static")
        self.template_path = os.path.join(FRAMEWORK_ROOT, "resource/templates")


class SystemPath(SystemPathRaw, metaclass=Singleton):
    pass
