# -*- coding: utf-8-*-

from abc import ABCMeta, abstractmethod

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


class Feature(metaclass=ABCMeta):
    """
    특징 학습 및 추출 객체

    학습 과 모델 로딩만 추상화하고 사용하는 함수는 자체 정의
    """

    @abstractmethod
    def train(self, intent_list, entity_list):
        """학습을 진행한다.

        Args:
            intent_list(dict of intent): 전처리된 학습 데이터
            entity_list(dict of entity): 사용자 정의 entity 사전

        Returns:
            bin, 학습된 모델

        """
        pass

    @abstractmethod
    def load(self, model):
        """학습된 모델을 메모리에 적재한다.

        Args:
            model(bin): 학습된 모델

        Returns:
            bool, 적재 성공/실패 여부

        """
        pass

    def set_entity_list(self, entity_list):
        self._entity_list = entity_list
