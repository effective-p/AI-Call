# -*- coding: utf-8 -*-
import re

from selvybot.core.morph_analyzer import MorphAnalyzer

from selvybot.util import number_characterize


def make_dt_ti_ptn(text):
    ptn = re.sub(r'\s+', '', text)  # remove spaces
    return re.sub(r'\d', '0', ptn)  # replace all numbers with zero


def make_text(morps, begin, end):
    # 공백정보 살려서 넣는게 좋을듯
    return ''.join(morps[begin:end])


def _find_right_bound(morps, begin, max_key_len):
    len_sum = len(morps[begin])
    for idx in range(begin + 1, len(morps)):
        len_sum += len(morps[idx])
        if len_sum > max_key_len:
            return idx
    return len(morps)


def tag_nes(dic, max_key_len, morps):
    nes = []
    for _ in range(len(morps)):
        nes.append(set())
    for begin in range(len(morps)):
        right_bound = _find_right_bound(morps, begin, max_key_len)
        # find pattern and key, longest first
        for end in range(right_bound, begin, -1):  # end is exclusive
            text = make_text(morps, begin, end)
            categories = []
            ptn = make_dt_ti_ptn(text)
            if ptn in dic:
                categories = dic[ptn]
            else:
                key = re.sub(r'\s+', '', text).lower()
                if key in dic:
                    categories = dic[key]
            if categories:
                for idx in range(begin, end):
                    nes[idx].update(categories)
    return nes


def pos_tokenize(sentence):
    pos_list = MorphAnalyzer().pos(sentence)
    pos_list = [pos for pos in pos_list if pos.pos != 'Space']
    begin = 0
    for idx, pos in enumerate(pos_list):
        while True:
            if not sentence[begin:].startswith(pos.text):
                begin += 1
            break
        end = begin + len(pos.text)
        if end == len(sentence) or sentence[end] == ' ':
            sp = 1
        else:
            sp = 0
        pos_list[idx] = (pos.text, pos.pos, sp, begin, end)
        begin = end
    return pos_list


def example2dataset(examples):
    output_sentences = []
    for example, preset_result, dict_result in examples:
        output_sentence = example['ExampleText']
        if len(output_sentence) == 0:
            continue
        pos_list = pos_tokenize(number_characterize(output_sentence))

        tags = tag_data(example['EntityLabels'], pos_list)
        pre_tags = tag_data(preset_result, pos_list)
        dict_tags = tag_data(dict_result, pos_list)

        output_sentence = []
        for pos, pre, dt, tag in zip(pos_list, pre_tags, dict_tags, tags):
            output_sentence.append(
                [pos[0], pos[1], pos[2], pre, dt, pos[3], pos[4], tag])
        output_sentences.append(output_sentence)
    return output_sentences


def tag_data(entity_labels, pos_list):
    tags = ['O'] * len(pos_list)
    for et in entity_labels:
        x = range(et['StartToken'], et['EndToken'])
        first = True
        for idx, pos in enumerate(pos_list):
            y = range(pos[3], pos[4])
            if max(x[0], y[0]) < min(x[-1], y[-1]) + 1:
                # 의학 도메인의 tag가 이미 들어가있는 경우, assert 발생
                # 이미 들어가 있는 경우 패스하도록 함
                if tags[idx] == 'O':
                    if first:
                        tags[idx] = 'B-' + et['EntityType']
                        first = False
                    else:
                        tags[idx] = 'I-' + et['EntityType']
    return tags
