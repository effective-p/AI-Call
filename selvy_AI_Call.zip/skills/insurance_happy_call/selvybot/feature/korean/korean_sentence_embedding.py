# -*- coding: utf-8-*-
import concurrent.futures
import math

from svlog import logged
from tqdm import tqdm

from selvybot.error.resource import ResourceLoadFailedError, ResourceGetFailedError
from selvybot.feature import Feature
from selvybot.util.common import requests_retry_session

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


@logged
class KoreanSentenceEmbedding(Feature):
    SIZE_PER_REQUEST = 100
    """__init__(self)
    텍스트를 외부의 RESTful 서버로 전달하여 Setence Embedding 결과를 받는 클래스
    RESTful 서버 주소 : SystemPath().components_url + '/sentence_embedding'

    .. warning::
       없음

    Args:
        없음

    .. seealso::
        없음

    """

    def __init__(self, resource_path):
        self._url = resource_path.components_url + "/sentence_embedding/list"
        self._session = requests_retry_session()

    def run(self, text_list, preprocess=True):
        submit_list = []
        worker_size = min(10, int(math.ceil(len(text_list) / self.SIZE_PER_REQUEST)))
        if worker_size == 1:
            return self.request(text_list)
        with concurrent.futures.ThreadPoolExecutor(max_workers=worker_size) as executor:
            for begin in range(0, len(text_list), self.SIZE_PER_REQUEST):
                sub_text_list = text_list[begin: min(begin + self.SIZE_PER_REQUEST, len(text_list))]
                submit_list.append(executor.submit(self.request, sub_text_list))
            embedding_list = []
            for submit in tqdm(submit_list, desc='Sentence Embedding'):
                embedding_list.extend(submit.result())
        return embedding_list

    def request(self, text_list, preprocess=True):
        try:
            response = self._session.post(self._url, json={"text": text_list, "preprocess": preprocess})
            if response.status_code != 200:
                raise ResourceGetFailedError("sentence_embedding", response.text)
            res_data = response.json()
            if res_data['status'] != "success":
                raise ResourceLoadFailedError("sentence_embedding")
            return res_data['vector']
        except Exception as e:
            self.__log.error(e)
            return []

    def train(self, intent_list, entity_list, preprocess=True):
        response = self._session.post(self._url, json={"text": ['초기화 테스트'], "preprocess": preprocess})
        if response.status_code != 200:
            raise ResourceGetFailedError("sentence_embedding", response.text)
        return bin(0)

    def load(self, model):
        return True
