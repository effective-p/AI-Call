# -*- coding: utf-8 -*-
import re
import tempfile

from svlog import logged, traced
from tqdm import tqdm

from selvybot.error.resource import ResourceGetFailedError
from selvybot.feature import Feature
from selvybot.feature.gazetteer_searcher import GazetteerSearcher
from selvybot.feature.korean.korean_ner_classification_resource.crf import dataset, predict as crfpredict, \
    train as crftrain
from selvybot.type import entity
from selvybot.type.intent import SLOT_TAG_VALUE
from selvybot.util.common import silent_remove, requests_retry_session

__author__ = "Glenn Dukkyu Lim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2018/05/02"


@traced('run')
@logged
class KoreanNerClassification(Feature):
    """__init__(self)

    한국어 개체명 분류기

    .. warning::
       없음

    Args:
        없음

    .. seealso::
        없음

    """

    def __init__(self, resource_path):
        self._tagger = dict()
        self._url = resource_path.components_url + "/ner/preset"
        self._session = requests_retry_session()

    def _preset_ner_classification(self, text):
        try:
            response = self._session.post(self._url, json={"ExampleText": text})
            if response.status_code != 200:
                raise ResourceGetFailedError("ner_classification", response.text)
            res_data = response.json()
            return res_data['EntityLabels']
        except Exception as e:
            self.__log.error(e)
            return []

    def run(self, intent, text):
        """특징을 추출한다.

        Args:
            intent (str):  인식하고자 하는 intent 이름.
            text (str): 전처리된 사용자 발화.

        Returns:
            SLOT_TAG_VALUE, slot tag value list

        """
        try:
            original = text
            if not self._tagger[intent]:
                return []
            text, replace_info_list, dict_result = self._replace_represent_word_for_test(text, self._entity_list)
            example = self._convert_to_target(text)
            preset_reuslt = self._preset_ner_classification(text)
            sentence = dataset.example2dataset([(example, preset_reuslt, dict_result)])[0]
            _, y = crfpredict.predict(sentence, self._tagger[intent])

            if 'EntityLabels' not in example:
                example['EntityLabels'] = []

            results = [SLOT_TAG_VALUE(*value) for value in self._extract_entity(sentence, y, text)]

            text, results = self._restore_text(text, results, replace_info_list)
            assert original == text
            return results
        except Exception as e:
            self.__log.error(e)
            return []

    def train(self, intent_list, entity_list):
        """학습을 진행한다.

        Args:
            intent_list(dict of intent): 전처리된 학습 데이터
            entity_list(dict of entity): 사용자 정의 entity 사전

        Returns:
            bin, 학습된 모델

        """
        if len(self._preset_ner_classification("서울시")) == 0:
            raise Exception("component의 preset 개체명 인식기와 연결할수 없습니다.")

        # intent별로 개체명 인식기를 분리, 분리한게 성능이 더 잘나옴
        model_list = dict()
        for intent_name, intent in intent_list.items():
            # slot이 없는 intent는 모델을 학습할 필요가 없음
            if not intent.slots:
                model_list[intent_name] = None
                continue
            train_data = []
            text_list = set()
            remove_count = 0

            # slot에 대응되는 entity를 검색하기 용이하게 dict를 생성
            slot_to_entity = {s.name: s.entity for s in intent.slots if s.entity}
            for utterance in tqdm(intent.utterances, desc=intent_name):
                # 문제의 패턴을 단순화 시켜서 학습의 난이도를 낮추기 위해서,
                # 입력문장에서 태깅된 정보를 기준으로 entity 사전의 대표 단어로 교체하고, 태깅정보를 수정
                text, values, _ = self._replace_represent_word_for_train(utterance.text, utterance.values, entity_list,
                                                                         slot_to_entity)

                # 입력문장을 entity사전의 대표단어로 치환할 경우 동일한 문장이 나타날 가능성이 생김,
                # 동일한 문장이 학습에 들어가면 crfsuite에서 에러 발생해서, 동일한 문장 제거
                if text in text_list:
                    remove_count += 1
                    continue
                text_list.add(text)

                # 입력문장, 태깅 데이터, preset 개체명 인식기 결과, 사전 검색 결과
                train_data.append((self._convert_to_target(text, values),
                                   self._preset_ner_classification(text),
                                   GazetteerSearcher().prefix_search(text)))
            print("")
            print("duplicate pattern removed : {}".format(remove_count))
            sentences = dataset.example2dataset(train_data)

            temp_file_name = tempfile.mktemp()
            try:
                # 학습 과정
                # 학습 알고리즘 비교 : http://www.chokkan.org/software/crfsuite/benchmark.html#idp8849132016
                crftrain.train('pa', sentences, temp_file_name)
                self._tagger[intent_name] = crfpredict.get_tagger(temp_file_name)
                crf_bin = open(temp_file_name, mode='rb').read()
            finally:
                silent_remove(temp_file_name)
            model_list[intent_name] = crf_bin

        return model_list

    def load(self, model_list):
        """학습된 모델을 메모리에 적재한다.

        Args:
            model(bin): 학습된 모델

        Returns:
            bool, 적재 성공/실패 여부

        """
        for intent_name, crf_bin in model_list.items():
            if crf_bin is None:
                self._tagger[intent_name] = None
                continue
            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                temp_file.write(crf_bin)
            try:
                self._tagger[intent_name] = crfpredict.get_tagger(temp_file.name)
            finally:
                silent_remove(temp_file.name)
        return True

    @staticmethod
    def _normalize_number_with_info(text, values):
        replace_info_list = []
        margin = [0]

        def repl(var):
            nums = var.group(0)
            begin = var.start() + margin[0]
            end = var.end() + margin[0]
            diff = len(nums) - 1
            for idx, value in enumerate(values):
                rstart = value.start - diff if end <= value.start else value.start
                rend = value.end - diff if end <= value.end else value.end

                values[idx] = SLOT_TAG_VALUE(rstart, rend, value.value, value.slot)
            replace_info_list.append({'start': begin,
                                      'end': begin + 1,
                                      'text': nums
                                      })
            margin[0] -= diff
            return '0'

        text = re.sub(r'\d+', lambda x: repl(x), text)
        return text, values, replace_info_list

    def _replace_represent_word_for_test(self, text, entity_list):
        # 숫자 치환 및 복원을 위한 치환 정보 기록
        text, _, replace_info_list = self._normalize_number_with_info(text, [])

        # 주의!!
        # gazetter 사전내 단어는 숫자가 0으로 치환되어 있으므로 검색전 입력 문장의 숫자를 0으로 치환할것
        search_result = GazetteerSearcher().prefix_search(text)

        # entity 사전 대표 단어로 치환
        margin = 0
        for idx, result in enumerate(search_result):
            start = result['StartToken']
            end = result['EndToken']
            entity_type = result['EntityType']
            rep_word = entity_list[entity_type][0]

            coverted_start = start + margin
            coverted_end = start + margin + len(rep_word)

            # 복원을 위한 치환 정보 기록
            replace_info_list.append({'start': coverted_start,
                                      'end': coverted_end,
                                      'text': text[start + margin:end + margin]
                                      })
            search_result[idx]['StartToken'] = coverted_start
            search_result[idx]['EndToken'] = coverted_end

            text = text[:start + margin] + rep_word + text[end + margin:]
            margin += len(rep_word) - (end - start)

        return text, replace_info_list, search_result

    def _replace_represent_word_for_train(self, text, values, entity_list, slot_to_entity):
        # 숫자 치환 및 복원을 위한 치환 정보 기록
        text, values, replace_info_list = self._normalize_number_with_info(text, values)

        # 태깅정보를 기반으로 태깅된 단어가 entity 사전에 존잴할 경우 대표단어로 치환,
        margin = 0
        for idx, value in enumerate(values):
            if value.slot not in slot_to_entity:
                continue
            entity_type = slot_to_entity[value.slot]
            if entity_type is None:
                continue

            start = value.start
            end = value.end

            # 태깅된 어절이 entity 사전에 존재하지 않는가?
            if text[start + margin:end + margin] not in entity_list[entity_type]:
                coverted_start = value.start + margin
                coverted_end = value.end + margin
                # 앞에서 밀린 위치(margin)만큼 업데이트
                values[idx] = SLOT_TAG_VALUE(coverted_start, coverted_end, text[coverted_start:coverted_end],
                                             value.slot)

            # 태깅된 어절이 entity 사전에 존재하는가?
            else:
                # 대표 단어로 치환, 치환된 단어의 길이차이 + 앞에서 밀린 위치(margin) 만큼 업데이트
                rep_word = entity_list[entity_type][0]
                coverted_start = value.start + margin
                coverted_end = value.start + margin + len(rep_word)
                # 복원을 위한 치환 정보 기록, 학습 데이터는 복원을 하지 않지만 디버깅용으로 남겨둠
                replace_info_list.append({'start': coverted_start,
                                          'end': coverted_end,
                                          'text': text[start + margin:end + margin]
                                          })
                values[idx] = SLOT_TAG_VALUE(coverted_start, coverted_end, rep_word, value.slot)
                text = text[:start + margin] + rep_word + text[end + margin:]
                margin += len(rep_word) - (value.end - value.start)
        return text, values, replace_info_list

    @staticmethod
    def _convert_to_target(text, values=None):
        dic = {}
        if values is None:
            dic['ExampleText'] = text
            dic['EntityLabels'] = []
        else:
            dic['ExampleText'] = text
            dic['EntityLabels'] = []
            for element in values:
                temp_entity = {}
                temp_entity['StartToken'] = element.start
                temp_entity['EndToken'] = element.end
                temp_entity['EntityType'] = element.slot
                temp_entity['EntityValue'] = element.value
                dic['EntityLabels'].append(temp_entity)
        return dic

    @staticmethod
    def _extract_entity(x, y, text):
        bucket = []
        last_tag = ''
        for token, tag in zip(x, y):
            if tag == 'O' or tag[2:] != last_tag:
                if bucket:
                    yield bucket[0][-3], bucket[-1][-2], text[bucket[0][-3]:bucket[-1][-2]], last_tag
                    bucket.clear()
                if tag != 'O':
                    bucket.append(token)
                    last_tag = tag[2:]
            else:
                bucket.append(token)
        if bucket:
            yield bucket[0][-3], bucket[-1][-2], text[bucket[0][-3]:bucket[-1][-2]], last_tag

    @staticmethod
    def _restore_text(text, results, replace_info_list):
        for info in reversed(replace_info_list):
            # 복원 정보
            rstart = info['start']
            rend = info['end']
            word = text[rstart:rend]
            rword = info['text']

            # 복원 단어와 원래단어의 길이 차이 계산
            diff = len(rword) - len(word)
            rtext = text[:rstart] + rword + text[rend:]
            for idx, value in enumerate(results):
                start = value.start
                end = value.end
                # 복원되는 위치와 추출된 개체의 위치과 겹치는가?
                if max(start, rstart) < min(end, rend) + 1:

                    # 겹치는 부분을 계산해서 복원 대상 단어와 개체 추출 단어를 조합 해서 새로운 단어를 생성
                    head = text[start:max(start, rstart)]
                    body = rword[max(0, start - rstart): max(len(rword), end - rstart)]
                    tail = text[min(end, rend):end]

                    nstart = start + diff if rend <= start else start
                    nend = end + diff
                    assert rtext[nstart:nend] == head + body + tail
                    results[idx] = SLOT_TAG_VALUE(nstart, nend, head + body + tail, value.slot)

                # 복원되는 위치 보다 추출 개체가 뒤에서 나타나는가?
                elif rend <= start:
                    # 개체 위치를 diff 만큼 업데이트
                    results[idx] = SLOT_TAG_VALUE(value.start + diff, value.end + diff, value.value, value.slot)
            text = rtext

        return text, results
