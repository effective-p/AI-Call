# -*- coding: utf-8-*-

import pickle
from collections import OrderedDict

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from svlog import traced

from selvybot.feature import Feature
from selvybot.feature.sentence_embedding import SentenceEmbedding
from selvybot.util.common import number_normalize

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


@traced('run')
class KoreanIntentClassification(Feature):

    def __init__(self, resource_path, threshold):
        self._sentence_embedding = SentenceEmbedding()
        self._utterance_matrix = None
        self._utterance_intent_list = None
        self._threshold = float(threshold)

    def run(self, text, target_intent_list):
        """의도를 예측한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.
            target_intent_list (str of list): 인식할 의도 목록

        Returns:
            dict, 예측 의도와 점수

        """
        if len(self._utterance_matrix) == 0:
            return {}
        pre_processed_text = self._preprocess(text)
        utter_vector = self._sentence_embedding.run([pre_processed_text])[0]
        user = np.array(utter_vector).reshape(1, -1)

        target_index_list = [idx for idx, intent_name in enumerate(self._utterance_intent_list) if
                             intent_name in target_intent_list]
        if not target_index_list:
            return {}
        score_matrix = cosine_similarity(user, self._utterance_matrix[target_index_list])[0]
        sorted_list = np.argsort(-score_matrix)

        outputs = OrderedDict()
        for idx in sorted_list:
            score = score_matrix[idx]
            if score < self._threshold:
                break
            intent_name = self._utterance_intent_list[target_index_list[idx]]
            if intent_name not in outputs:
                outputs[intent_name] = score
        return outputs

    def train(self, intent_list, entity_list):
        """학습을 진행한다.

        Args:
            intent_list(dict of intent): 전처리된 학습 데이터
            entity_list(dict of entity): 사용자 정의 entity 사전

        Returns:
            bin, 학습된 모델

        """
        self._utterance_matrix, self._utterance_intent_list = self._load_utterances(intent_list)
        if self._utterance_matrix.shape[1] == 0:
            raise Exception("sentence embedding 에서 user matrix 값을 생성하지 못했습니다.")
        return pickle.dumps((self._utterance_matrix, self._utterance_intent_list))

    def load(self, model):
        """학습된 모델을 메모리에 적재한다.

        Args:
            model(bin): 학습된 모델

        Returns:
            bool, 적재 성공/실패 여부

        """
        self._utterance_matrix, self._utterance_intent_list = pickle.loads(model)
        return True

    def _load_utterances(self, intent_list):
        utterance_intent_list = []
        utterance_list = []
        for intent_name, intent in intent_list.items():
            for utterance in intent.utterances:
                pre_processed_text = self._preprocess(utterance.text)
                utterance_list.append(pre_processed_text)
                utterance_intent_list.append(intent_name)

        utterance_vector_list = self._sentence_embedding.run(utterance_list)
        return np.matrix(utterance_vector_list), utterance_intent_list

    def _preprocess(self, text):
        return number_normalize(text)
