# -*- coding: utf-8-*-
from svlog import getLogger

from selvybot.feature import Feature
from selvybot.util import SingletonFactory
from selvybot.feature.korean.korean_ner_classification import KoreanNerClassification

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


class DummyNerClassification(Feature):
    def run(self, text):
        return []

    def train(self, intent, text):
        return bin(0)

    def load(self, model):
        return True


class NerClassification(metaclass=SingletonFactory):
    @staticmethod
    def factory(language, *args, **kwargs):
        if language == "korean":
            return KoreanNerClassification(*args, **kwargs)
        else:
            getLogger().warn("{}, 해당언어를 지원하지 않습니다.")
            return DummyNerClassification()
