# -*- coding: utf-8-*-

from selvybot.app import create_bot_from_config

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/08/10"

bot = create_bot_from_config('/resource/config.ini')
app = bot.flask_app()
