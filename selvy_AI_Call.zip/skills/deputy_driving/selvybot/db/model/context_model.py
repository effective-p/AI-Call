# -*- coding: utf-8-*-
import datetime
import json
from base64 import b64encode
from collections import namedtuple

from sqlalchemy import func
from svlog import logged

from selvybot.db.database_driver import db

__author__ = "John Junseok Kim, Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/12"

Context = namedtuple("Context", "user_id session glob system local")


class ContextModel(db.Model):
    __tablename__ = 'user_context'

    user_id = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.TEXT())
    created = db.Column(db.DateTime(timezone=True), server_default=func.now())
    updated = db.Column(db.DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __init__(self, user_id, value):
        self.user_id = user_id
        self.value = value

    def __repr__(self):
        return "<ContextModel({}, {}, {}, {})>".format(self.user_id, self.value, self.created, self.updated)


@logged
class ContextManager(object):
    def __init__(self, driver, maintain_time=600):
        db.create_all()
        driver.verify_model(ContextModel)
        self._driver = driver
        self._maintain_time = maintain_time

    def get(self, user_id, ignore_time=False, clear=False):
        raw_context = self._get_data(user_id)
        new_user_created = True if 'id' not in raw_context['session'] else False

        session_changed, raw_context['session'] = self._validate_session(user_id, raw_context['session'], ignore_time)
        if session_changed or clear:
            raw_context['glob'] = {}
            raw_context['system'].pop('cursor', None)
            raw_context['system'].pop('slot', None)
            raw_context['system'].pop('intent', None)
            raw_context['system'].pop('next_list', None)

        context = Context(user_id=user_id, session=raw_context['session'], glob=raw_context['glob'],
                          system=raw_context['system'],
                          local={})
        return context, new_user_created

    def _validate_session(self, user_id, session, ignore_time=False):
        now = datetime.datetime.now()
        if 'id' not in session or 'last_access_time' not in session or ignore_time is False and \
                                0 < self._maintain_time < \
                        (now - datetime.datetime.strptime(session['last_access_time'],
                                                          "%Y-%m-%d %H:%M:%S.%f")).total_seconds():
            session_changed = True
            session['id'] = b64encode((user_id + now.__str__()).encode('utf-8')).decode('utf-8')
            session['last_access_time'] = str(now)
        else:
            session_changed = False
            session['last_access_time'] = str(now)

        return session_changed, session

    def _get_data(self, user_id):
        selected_data = self._driver.select(ContextModel, [ContextModel.user_id == user_id])
        raw_context = {}
        if len(selected_data) == 1:
            try:
                raw_context = json.loads(selected_data[0].value)
            except Exception as e:
                self.__log.error(e)
        if 'glob' not in raw_context:
            raw_context['glob'] = {}
        if 'system' not in raw_context:
            raw_context['system'] = {}
        if 'session' not in raw_context:
            raw_context['session'] = {}
        return raw_context

    def set(self, context):
        try:
            value = json.dumps(context._asdict(), ensure_ascii=False)
        except:
            self.__log.error('context에 저장할수 없는 데이터 형태 입니다.')
            return

        self._driver.upsert(ContextModel(context.user_id, value))

    def clear(self, user_id):
        self._driver.clear(ContextModel, [ContextModel.user_id == user_id])
