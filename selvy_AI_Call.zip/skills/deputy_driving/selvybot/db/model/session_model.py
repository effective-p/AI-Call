from sqlalchemy.sql import func

from selvybot.db.database_driver import db

__author__ = "Demian H. Yang"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "demian.h.yang@selvas.com"
__date__ = "2020/06/03"

class SessionModel(db.Model):
    __tablename__ = 'user_session_map'

    user_id = db.Column(db.String(40), primary_key=True)
    session_id = db.Column(db.String(40), primary_key=False)
    created = db.Column(db.DateTime(timezone=True), server_default=func.now())
    updated = db.Column(db.DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __init__(self, user_id, session_id):
        self.user_id = user_id
        self.session_id = session_id

    def __repr__(self):
        return "<SessionModel({}, {}, {}, {})>".format(self.user_id, self.session_id,
                                                                           self.created, self.updated)

class SessionManager(object):
    def __init__(self, driver, maintain_time=600):
        db.create_all()
        driver.verify_model(SessionModel)
        self._driver = driver
        self._maintain_time = maintain_time

    def get_id(self, session_id, ignore_time=False, clear=False):
        selected_data = self._driver.select(SessionModel, [SessionModel.session_id == session_id])
        if len(selected_data) == 0:
            return None

        return selected_data[0].user_id

    def is_exist_id(self, user_id, ignore_time=False, clear=False):
        selected_data = self._driver.select(SessionModel, [SessionModel.user_id == user_id])
        if len(selected_data) == 0:
            return False

        return True

    def set_session(self, user_id, session_id):
        self._driver.upsert(SessionModel(user_id, session_id))
