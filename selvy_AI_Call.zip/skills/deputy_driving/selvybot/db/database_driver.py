# -*- coding: utf-8 -*-
import os

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect
from sqlalchemy.ext.declarative.clsregistry import _ModuleMarker
from sqlalchemy.orm import RelationshipProperty
from sqlalchemy.sql import sqltypes
from svlog import logged

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/07/16"

db = SQLAlchemy()

if os.name != 'nt':
    try:
        from uwsgidecorators import postfork


        @postfork
        def reset_db_connections():
            db.session.close_all()
            db.engine.dispose()
            db.create_scoped_session()
    except:
        pass


@logged
class DatabaseDriver(object):
    def lazy_init(self, app):
        app.config.update(self._config)
        with app.app_context():
            db.init_app(app)
        db.app = app
        self._db_session = db.session

    def session_remove(self):
        self._db_session.remove()

    def commit(self):
        self._db_session.commit()

    def select(self, model, filter_list=[]):
        try:
            query = self._query(model, filter_list)
            data_list = query.all()
        except Exception as e:
            self.__log.error(e)
            data_list = None
        return data_list

    def bulk_insert(self, data_list):
        try:
            self._db_session.bulk_save_objects(data_list)
            self._db_session.commit()
            return True
        except Exception as e:
            self.__log.error(e)
            self._db_session.rollback()
            return False

    def upsert(self, data):
        try:
            self._db_session.merge(data)
            self._db_session.commit()
            return True
        except Exception as e:
            self.__log.error(e)
            self._db_session.rollback()
            return False

    def delete(self, data):
        try:
            self._db_session.delete(data)
            self._db_session.commit()
            return True
        except Exception as e:
            self.__log.error(e)
            self._db_session.rollback()
            return False

    def clear(self, model, filter_list):
        try:
            status = self._query(model, filter_list).delete()
            if status > 0:
                self._db_session.commit()
        except Exception as e:
            self.__log.error(e)
            status = 0
        return status

    def _query(self, model, filter_list):
        query = self._db_session.query(model)
        for f in filter_list:
            query = query.filter(f)
        return query

    def verify_model(self, Base):
        engine = self._db_session.get_bind()
        iengine = inspect(engine)

        errors = []

        tables = iengine.get_table_names()

        for name, klass in Base._decl_class_registry.items():

            if isinstance(klass, _ModuleMarker):
                # Not a model
                continue

            table = klass.__tablename__
            if table not in tables:
                errors.append("Model %s declares table %s which does not exist in database %s", klass, table, engine)
                errors = True
                continue

            columns = iengine.get_columns(table)
            mapper = inspect(klass)

            for column_prop in mapper.attrs:
                if isinstance(column_prop, RelationshipProperty):
                    # TODO: Add sanity checks for relations
                    continue

                for column in column_prop.columns:
                    conn_data = next(item for item in columns if item['name'] == column.key)

                    if not conn_data:
                        errors.append("Model %s declares column %s which does not exist in database %s", klass,
                                      column.key, engine)
                        errors = True
                        continue

                    conn_type = conn_data['type']
                    metadata_type = column_prop.columns[0].type

                    from sqlalchemy.dialects import mysql
                    dialect = mysql.dialect()
                    metadata_impl = metadata_type.dialect_impl(dialect)
                    if isinstance(metadata_impl, sqltypes.Variant):
                        metadata_impl = metadata_impl.impl.dialect_impl(dialect)

                    if not conn_type._compare_type_affinity(metadata_impl):
                        comparator = _type_comparators.get(conn_type._type_affinity, None)
                        if not (comparator and comparator(metadata_impl, conn_type)):
                            errors.append("{}은 {}와 {}로 타입이 일치하지 않습니다.".format(column.key, conn_type, metadata_type))

        if errors:
            raise Exception("\n".join(errors))


def _string_compare(t1, t2):
    return t1.length is not None and t1.length == t2.length


def _numeric_compare(t1, t2):
    return (
                   t1.precision is not None and
                   t1.precision == t2.precision
           ) or (
                   t1.precision is not None and
                   t1.scale is not None and
                   t1.scale == t2.scale
           )


def _integer_compare(t1, t2):
    t1_small_or_big = (
        'S' if isinstance(t1, sqltypes.SmallInteger)
        else 'B' if isinstance(t1, sqltypes.BigInteger) else 'I'
    )
    t2_small_or_big = (
        'S' if isinstance(t2, sqltypes.SmallInteger)
        else 'B' if isinstance(t2, sqltypes.BigInteger) else 'I'
    )
    return t1_small_or_big == t2_small_or_big


def _datetime_compare(t1, t2):
    return (
            t1.timezone == t2.timezone
    )


_type_comparators = {
    sqltypes.String: _string_compare,
    sqltypes.Numeric: _numeric_compare,
    sqltypes.Integer: _integer_compare,
    sqltypes.DateTime: _datetime_compare,
}
