# -*- coding: utf-8 -*-

from selvybot.db import DatabaseDriver

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/07/17"


class SqliteDriver(DatabaseDriver):
    def __init__(self, path):
        '''
            # memory based
            engine = create_engine('sqlite://')

            # relative path
            # sqlite://<nohostname>/<path>
            # where <path> is relative:
            engine = create_engine('sqlite:///foo.db')

            # absolute path
            #Unix/Mac - 4 initial slashes in total
            engine = create_engine('sqlite:////absolute/path/to/foo.db')
            #Windows
            engine = create_engine('sqlite:///C:\\path\\to\\foo.db')
            #Windows alternative using raw string
            engine = create_engine(r'sqlite:///C:\path\to\foo.db')
        '''
        address = 'sqlite:///{}'.format(path)
        self._config = dict()
        self._config['SQLALCHEMY_DATABASE_URI'] = address
        self._config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
