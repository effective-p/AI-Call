import sys
import traceback
import uuid
import enum

from flask import jsonify, request
from flask_restful import Resource, reqparse, abort
from svlog import logged
from selvybot.db.model.session_model import SessionManager

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


@logged
class MessageResource(Resource):
    def __init__(self, **kwargs):
        self.message_func = kwargs['message_func']
        self.upsert_user_id_func = kwargs['upsert_user_id_func']
        self.get_user_id_func = kwargs['get_user_id_func']
        self.check_user_id_func =  kwargs['check_user_id_func']
        self._meta = kwargs['meta_data']

    def _add_value_to_target(self, src_json, dst_json, key, default = 'None', required = False):
        if key in src_json:
            dst_json[key] = src_json[key]
            return

        if required is True:
            dst_json[key] = default

    def _make_args_from_request(self, src_json):
        args = dict()
        self._add_value_to_target(src_json, args, 'session_id')
        self._add_value_to_target(src_json, args, 'user_id')
        self._add_value_to_target(src_json, args, 'user_response')
        self._add_value_to_target(src_json, args, 'for_call')
        self._add_value_to_target(src_json, args, 'license_key')
        self._add_value_to_target(src_json, args, 'platform', 'None', True)
        self._add_value_to_target(src_json, args, 'reply_url', 'None', True)
        self._add_value_to_target(src_json, args, 'msg_id', uuid.uuid1().hex, True)
        self._add_value_to_target(src_json, args, 'timezone')
        self._add_value_to_target(src_json, args, 'gps')
        self._add_value_to_target(src_json, args, 'debugger')

        return args

    def _get_additional_info(self, target_json):
        sub_jsons = list(filter(lambda x: isinstance(x, dict), target_json.values()))
        additional_info = (lambda x: x[0] if len(x) > 0 else None)(sub_jsons)

        return additional_info

    class RUN_TYPE(enum.Enum):
        NORMAL_RESPONSE = 0
        ONBORDING_RESPONSE = 1
        EMPTY_RESPONSE = 2

    def check_response_type(self, args):
        is_for_call = (lambda x: x['for_call'] if 'for_call' in x else False)(args)
        is_with_user_id = (lambda x: True if 'user_id' in x else False)(args)
        is_debug_mode = (lambda x: True if 'debugger' in x else False)(args)
        is_first = False

        if is_debug_mode == True:
            return self.RUN_TYPE.NORMAL_RESPONSE

        session_id = args['session_id']
        if is_with_user_id == True and session_id.find('telegram_demo') != -1:
            return self.RUN_TYPE.NORMAL_RESPONSE

        if is_with_user_id == True and not self.check_user_id_func(args['user_id']):
            is_first = True

        if is_first == True:
            return self.RUN_TYPE.ONBORDING_RESPONSE
        elif is_for_call == True and is_with_user_id == True:
            return self.RUN_TYPE.ONBORDING_RESPONSE
        elif is_with_user_id == True:
            return self.RUN_TYPE.EMPTY_RESPONSE

        return self.RUN_TYPE.NORMAL_RESPONSE

    def post(self):
        src_json = request.get_json()
        args = self._make_args_from_request(src_json)
        additional_info = self._get_additional_info(src_json)
        session_id = args['session_id']
        response_type = self.check_response_type(args)

        if 'user_id' in args:
            user_id = args['user_id']
            self.upsert_user_id_func(user_id, session_id)
        else:
            user_id = self.get_user_id_func(session_id)
            args['user_id'] = user_id

        try:
            if response_type == self.RUN_TYPE.EMPTY_RESPONSE:
                output = {'session_id': session_id, 'result_text': '', 'tts_string': '', 'analysis_result': '',
                          'stt_model': 0, 'result_type': 0}
            else:
                if not args['user_response']:
                    return abort(400)
                
                if response_type == self.RUN_TYPE.ONBORDING_RESPONSE:
                    user_msg = '시작'
                else:
                    user_msg = (lambda x: x['user_response'][0] if len(x['user_response']) > 0 else '')(args)

                if user_msg.strip() == '':
                    user_msg = '</empty>'
                    # return jsonify({'session_id': session_id, 'result_text': "죄송하지만, 다시 한 번 말씀해주세요.",
                    #                 'tts_string': "죄송하지만, 다시 한 번 말씀해주세요.", 'analysis_result': '',
                    #                 'stt_model': 14, 'result_type': 2})

                utterances, debugging_info = self.message_func(user_id, user_msg, additional_info=additional_info,
                                                               platform=args['platform'], reply_url=args['reply_url'])

                raw_text = "".join([utter['text'] for utter in utterances])
                stt_model = 0
                result_type = 2
                tts_infos = list()
                verify_info = None
                for index, utter in enumerate(utterances):
                    if "stt_model" in utter:
                        stt_model = int(utter["stt_model"])
                    utterances[index].pop("stt_model", None)
                    if "result_type" in utter:
                        result_type = int(utter["result_type"])
                    utterances[index].pop("result_type", None)
                    if "tts_string" in utter:
                        tts_infos.append(utter["tts_string"])
                    utterances[index].pop("tts_string", None)

                    if "verify_info" in utter:
                        verify_info = utter["verify_info"]
                    utterances[index].pop("verify_info", None)

                if len(tts_infos) == 0:
                    tts_string = raw_text
                else:
                    tts_string = "".join(tts_infos)

                if user_msg == '</empty>':
                    user_msg = ''

                output = {'session_id': session_id, 'result_text': raw_text, 'tts_string': tts_string,
                          'analysis_result': user_msg, 'chatbot_info': utterances,
                          'stt_model': stt_model, 'result_type': result_type}
                if verify_info is not None:
                    output["verify_info"] = verify_info
                if 'debugger' in args and args['debugger'] == 'on':
                    output.update(debugging_info)

                # 'tts_string'
                self._conversation_log(raw_text, args, debugging_info)

            return jsonify(output)

        except Exception as e:
            utterances = [{"text": "시스템에서 에러가 발생했습니다. 관리자에게 문의해주세요."}]
            output = {'msg_id': args['msg_id'], 'chatbot_info': utterances}
            user_msg = args['user_response']
            self._error_log(e, user_id, args['msg_id'], self._meta['name'], args['platform'],
                            self._meta['version'],user_msg, utterances[0]['text'], {})
        return jsonify(output)

    def _conversation_log(self, response, args, debugging_info):
        is_child_node = False if 'root' in debugging_info['context']['system']['path'] else True
        if debugging_info['context']['system']['lastnode'] == debugging_info['context']['system']['cursor']:
            is_child_node = False
        is_slot_filled = debugging_info['context']['system']['lastnode'] == debugging_info['context']['system'][
            'cursor']

        root_index = next((i for i, x in enumerate(debugging_info['context']['system']['history']) if x == 'root'), -1)
        prev_node = 'root' if 'root' in debugging_info['context']['system']['path'] else \
            debugging_info['context']['system']['lastnode']
        history = debugging_info['context']['system']['history'][:root_index + 1] if root_index > 0 else \
            debugging_info['context']['system']['history']
        data = {
            "log_type": "conversation",
            "session_id": debugging_info['context']['session']['id'],
            "user_id": args['user_id'],
            "msg_id": args['msg_id'],
            "platform": args['platform'],
            "botname": self._meta['name'],
            "version": self._meta['version'],
            "user_utterences": args['user_response'][0],
            "chatbot_utterences": response,
            "is_child_node": is_child_node,
            "is_slot_filled": is_slot_filled,
            "current_node": debugging_info['context']['system']['cursor'],
            "last_node": debugging_info['context']['system']['lastnode'],
            "prev_node": prev_node,
            "history": history,
            "intent": debugging_info['context']['system']['match_intent']
        }

        self.__log.info(data)

    def _error_log(self, error, user_id, msg_id, bot_name, platform, version, request, response, context):
        error_msg = {}
        if isinstance(error, Exception):
            error_msg['error'] = error.__class__.__name__
            error_msg['cause'] = error.args[0]
            for i, msg in enumerate(traceback.format_tb(error.__traceback__)):
                error_msg['line' + str(i + 1)] = msg
        else:
            error_msg['error'] = error_msg.__str__()

        data = {
            'log_type': 'conversation_error',
            'user_id': user_id,
            'msg_id': msg_id,
            'botname': bot_name,
            'platform': platform,
            'version': version,
            'error_request': request,
            'error_response': response,
            'error': error_msg,
            'context': context
        }
        traceback.print_exception(*sys.exc_info())
        self.__log.error(data)
