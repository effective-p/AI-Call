# -*- coding: utf-8-*-
import io
import os
import shutil
import tempfile

import werkzeug
from flask import send_file, make_response
from flask_restful import Resource, reqparse

from selvybot.util.zip import zip_byte_array_list

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/09/14"


class ConvertResource(Resource):
    def __init__(self, **kwargs):
        self._convert_func = kwargs['convert_func']

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('resource', type=werkzeug.FileStorage, required=True, location='files')
        args = parser.parse_args(strict=True)

        tmp_dir = tempfile.mkdtemp()
        try:
            filename = os.path.join(tmp_dir, args.resource.filename)
            args.resource.save(filename)
            meta, scenario, script = self._convert_func(filename)
            data = zip_byte_array_list([('meta.json', meta), ('scenario.zip', scenario), ('script.xlsx', script)])

            return send_file(io.BytesIO(data), attachment_filename='archive.zip', as_attachment=True)
        except Exception as e:
            return make_response(str(e), 400)

        finally:
            shutil.rmtree(tmp_dir)
