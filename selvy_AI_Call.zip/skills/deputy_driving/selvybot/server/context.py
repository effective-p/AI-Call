# -*- coding: utf-8-*-
import io
import pickle
import pickletools

import werkzeug
from flask import send_file
from flask_restful import Resource, reqparse, abort

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/16"


class ContextResource(Resource):
    def __init__(self, **kwargs):
        self._context_manager = kwargs['context_manager']
        self._access_token = kwargs['access_token']

    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=str, required=True, location=['json', 'args'])
        parser.add_argument('access_token', type=str, required=True, location=['json', 'args'])
        args = parser.parse_args(strict=True)

        if args['access_token'] != self._access_token:
            abort(404)

        context, _ = self._context_manager.get(args.user_id)
        binary_data = pickletools.optimize(pickle.dumps(context))
        return send_file(
            io.BytesIO(binary_data),
            attachment_filename='context.bin',
            mimetype='application/octet-stream'
        )

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=str, required=True, location=['json', 'args', 'form'])
        parser.add_argument('context', type=werkzeug.FileStorage, location='files')
        parser.add_argument('access_token', type=str, required=True, location=['json', 'args'])
        args = parser.parse_args(strict=True)

        if args['access_token'] != self._access_token:
            abort(404)

        if args.context is None:
            self._context_manager.clear(args.user_id)
        else:
            context = pickle.loads(args.context.stream.read())
            self._context_manager.set(context)
        return ""

    def put(self):
        self.delete()

    def delete(self):
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=str, required=True, location=['json', 'args', 'form'])
        parser.add_argument('access_token', type=str, required=True, location=['json', 'args'])
        args = parser.parse_args(strict=True)

        if args['access_token'] != self._access_token:
            abort(404)

        context, _ = self._context_manager.get(args.user_id, clear=True)
        self._context_manager.set(context)
        return ""