# -*- coding: utf-8-*-
from svlog import logged

from selvybot.util import Singleton, requests_retry_session

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/10/26"


@logged
class SchedulerRaw:
    def __init__(self, botname, resource_path, access_token):
        self._botname = botname
        self._url = resource_path.components_url + "/scheduler"
        self._dnd_url = resource_path.domain_url + "/dnd"
        self._context_url = resource_path.domain_url + "/context"
        self._access_token = access_token

    def get(self, user_id='', job_id=''):
        try:
            data = {
                'botname': self._botname,
                'user_id': user_id,
                'job_id': job_id
            }
            resp = requests_retry_session().get(self._url, json=data)
            if resp.status_code != 200:
                raise Exception("스케쥴러 서버와 연결할수 없습니다. > {}".format(resp.text))
            return resp.json()
        except Exception as e:
            self.__log.error(e)
            return []

    def post(self, user_id, job_id, reply_url, utterances, params, dnd_timer=0, context_reset=False, noti_title='', noti_body=''):
        try:
            data = {
                'botname': self._botname,
                'user_id': user_id,
                'job_id': job_id,
                'reply_url': reply_url,
                'utterances': utterances,
                'params': params
            }
            if dnd_timer > 0:
                data['dnd_url'] = self._dnd_url + "?user_id={}&timer={}".format(user_id, dnd_timer)

            if context_reset == True:
                data['context_reset_url'] = self._context_url + "?user_id={}&access_token={}".format(user_id, self._access_token)

            if noti_title and noti_body:
                data['notification_title'] = noti_title
                data['notification_body'] = noti_body

            resp = requests_retry_session().post(self._url, json=data)
            if resp.status_code != 200:
                raise Exception("스케쥴러 서버와 연결할수 없습니다. > {}".format(resp.text))
            return True
        except Exception as e:
            self.__log.error(e)
            return False

    def delete(self, user_id='', job_id=''):
        try:
            data = {
                'botname': self._botname,
                'user_id': user_id,
                'job_id': job_id
            }
            resp = requests_retry_session().delete(self._url, json=data)
            if resp.status_code != 200:
                raise Exception("스케쥴러 서버와 연결할수 없습니다. > {}".format(resp.text))
            return resp.json()
        except Exception as e:
            self.__log.error(e)
            return []


class Scheduler(SchedulerRaw, metaclass=Singleton):
    pass
