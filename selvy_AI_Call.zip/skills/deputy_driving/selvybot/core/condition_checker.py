# -*- coding: utf-8-*-
from simpleeval import simple_eval
from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.core.condition_variable_replacer import ConditionVariableReplacer
from selvybot.util.singleton import Singleton

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/18"


@logged
class ConditionCheckerRaw(object):
    def __init__(self):
        pass

    def _preprocess_cond_str(self, str):
        preprocessed_str = str.replace('\n', '')
        return preprocessed_str

    def run(self, context, statement, text):
        if isinstance(statement, str):
            cond_str, cond_value = ConditionVariableReplacer().run(context, statement)
            cond_str = self._preprocess_cond_str(cond_str)
            for key in cond_value:
                cond_value[key] = self._preprocess_cond_str(cond_value[key])
            try:
                result = simple_eval(cond_str, names=cond_value)
                if isinstance(result, bool) and isinstance(result, float):
                    raise TypeError("")
                else:
                    return result
            except:
                self.__log.warn("<{}> 컨디션 문자열이 잘못되었습니다.".format(statement))
                return False
        else:
            return statement.run(context, text)


class ConditionChecker(ConditionCheckerRaw, metaclass=Singleton):
    pass
