# -*- coding: utf-8-*-
import re

from svlog import logged

from selvybot.util.singleton import Singleton

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/10"


@logged
class ParameterSplitterRaw(object):
    def __init__(self):
        self.split_regex = re.compile(r'''((?:[^\,\"\']|\"[^\"]*\"|\'[^\']*\')+)+''')
        pass

    def run(self, raw_text):
        if not raw_text:
            return []
        tokens = self.split_regex.split(raw_text)[1::2]
        tokens = [token.strip(" ") for token in tokens]
        for idx, token in enumerate(tokens):
            if len(token) > 1 and token[0] == token[-1]:
                if token[0] == '\'':
                    tokens[idx] = token.strip('\'')
                elif token[0] == '\"':
                    tokens[idx] = token.strip('\"')
        return tokens


class ParameterSplitter(ParameterSplitterRaw, metaclass=Singleton):
    pass
