# -*- coding: utf-8-*-
import re

from svlog import logged

from selvybot.schema.type import PATTERN_STR_VAR
from selvybot.util.singleton import Singleton

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/18"


@logged
class VariableReplacerRaw(object):
    def __init__(self):
        pass

    @staticmethod
    def check(text):
        return re.search(PATTERN_STR_VAR, text)

    def run(self, context, text, brace=""):
        return re.sub(PATTERN_STR_VAR, lambda x: self._context_variable(context, brace, x), text)

    def dynamic(self, param):
        if self.check(param):
            def func(context):
                return VariableReplacer().run(context, param)
        else:
            def func(context):
                return param
        return func

    @staticmethod
    def _context_variable(context, brace, match_result):
        loc, var_name = match_result.groups()
        if loc == '$$':
            source = context.local
        elif loc == '$':
            source = context.glob
        else:
            source = context.system

        if var_name in source:
            return brace + str(source[var_name]) + brace
        else:
            # TODO jskim 매칭되는 변수가 없으면 변수 호출 형태 그대로 출력, 문제시 변경, chatscript는 공백을 내보냄
            # return match_result.group()
            # TODO jskim 공백을 내보내는 형태로 다시 수정
            return brace + brace


class VariableReplacer(VariableReplacerRaw, metaclass=Singleton):
    pass
