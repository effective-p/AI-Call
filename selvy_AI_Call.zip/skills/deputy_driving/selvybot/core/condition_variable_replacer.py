# -*- coding: utf-8-*-
import re

from svlog import logged

from selvybot.schema.type import PATTERN_STR_VAR
from selvybot.util.singleton import Singleton

__author__ = "Glenn Dukkyu Lim"
__copyright__ = "Copyright 2019, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2019/08/23"


@logged
class ConditionVariableReplacerRaw(object):
    def __init__(self):
        pass

    @staticmethod
    def check(text):
        return re.search(PATTERN_STR_VAR, text)

    def run(self, context, text):
        replaced_text = re.sub(PATTERN_STR_VAR, lambda x: self._context_variable(context, x, return_value=False), text)
        value = {self._context_variable(context, r, return_value=False):self._context_variable(context, r)
                    for r in re.finditer(PATTERN_STR_VAR, text)}
        return replaced_text, value

    def dynamic(self, param):
        if self.check(param):
            def func(context):
                return ConditionVariableReplacer().run(context, param)
        else:
            def func(context):
                return param
        return func

    @staticmethod
    def _context_variable(context, match_result, return_value=True):
        loc, var_name = match_result.groups()
        loc_prefix=''
        if loc == '$$':
            source = context.local
            loc_prefix = 'local_'
        elif loc == '$':
            source = context.glob
            loc_prefix = 'glob_'
        else:
            source = context.system
            loc_prefix = 'system_'

        if return_value:
            return str(source.get(var_name, ''))
        else:
            new_var_name = loc_prefix + ''.join(c for c in var_name if c.isalpha())
            return new_var_name

class ConditionVariableReplacer(ConditionVariableReplacerRaw, metaclass=Singleton):
    pass
