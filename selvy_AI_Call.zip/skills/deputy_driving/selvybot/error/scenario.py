import os

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/08"


class ScenarioError(Exception):
    def __init__(self, file_path, node_name, section_name, error_data=None, note=None):
        self._file_path = os.path.realpath(file_path)
        self._node_name = node_name
        self._section_name = section_name
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}::{}::{} {}".format(self._file_path, self._node_name, self._section_name, self._error_data,
                                           self._note)


class ScenarioNotFoundError(ScenarioError):
    def __init__(self, file_path):
        self._file_path = os.path.realpath(file_path)

    def __str__(self):
        return "[] scenario not found"


class ScenarioDuplicatedNameError(ScenarioError):
    pass
