__author__ = "Glenn D. Lim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2018/05/24"