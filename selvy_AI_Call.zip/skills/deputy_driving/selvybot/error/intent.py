import os

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/14"


class IntentError(Exception):
    def __init__(self, file_path, error_data, note):
        self.id = 'intent'
        self._file_path = os.path.realpath(file_path)
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}::'{}' {}".format(self._file_path, self.id, self._error_data, self._note)


class SlotError(IntentError):
    def __init__(self, file_path, index, section, error_data, note):
        self.id = 'slots'
        self._file_path = os.path.realpath(file_path)
        self._section = section
        self._index = index
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}[{}]::{}::'{}' {}".format(self._file_path, self.id, self._index, self._section, self._error_data,
                                                 self._note)


class UtteranceError(IntentError):
    def __init__(self, file_path, index, error_data, note):
        self.id = 'utterances'
        self._file_path = os.path.realpath(file_path)
        self._index = index
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}[{}]::'{}' {}".format(self._file_path, self.id, self._index, self._error_data, self._note)


class RegexError(IntentError):
    def __init__(self, file_path, index, error_data, note):
        self.id = 'regex'
        self._file_path = os.path.realpath(file_path)
        self._index = index
        self._error_data = error_data
        self._note = note

    def __str__(self):
        return "[{}] {}[{}]::'{}' {}".format(self._file_path, self.id, self._index, self._error_data, self._note)
