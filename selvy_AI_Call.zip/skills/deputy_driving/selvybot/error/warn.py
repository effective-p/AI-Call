import os
import warnings

__author__ = "Glenn D. Lim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "dklim@selvas.com"
__date__ = "2018/05/24"


def ResourceNotFoundWarnings(message, path):
    warnings.warn_explicit(message, ResourceWarning, filename=os.path.realpath(path), lineno=0)


def FileSyntaxWarnings(message, path, lineno):
    warnings.warn_explicit(message, SyntaxWarning, filename=os.path.realpath(path), lineno=lineno)
