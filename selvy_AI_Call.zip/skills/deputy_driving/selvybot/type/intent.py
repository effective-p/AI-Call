# -*- coding: utf-8-*-
import concurrent.futures
import glob
import json
import re
from collections import namedtuple

from svlog import traced
from tqdm import tqdm

from selvybot.error.intent import IntentError
from selvybot.error.warn import ResourceNotFoundWarnings
from selvybot.type.intent_resource.regex import check_regex
from selvybot.type.intent_resource.slots import check_slots
from selvybot.type.intent_resource.utterances import check_utterances
from selvybot.util import yml, SystemPath, white_space_remove, string_dtw
from selvybot.variable import FRAMEWORK_ROOT

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/12"

SCHEMA_PATH = FRAMEWORK_ROOT + "/schema/intent.schema.json"
SCHEMA = json.load(open(SCHEMA_PATH, 'r', encoding='utf-8'))

SLOT_VALUE = namedtuple("SLOT_VALUE",
                        "name entity prompts default context is_list")

SLOT_TAG_VALUE = namedtuple("SLOT_TAG_VALUE",
                            "start end value slot")

UTTERANCE_VALUE = namedtuple("UTTERANCE_VALUE",
                             "text values")
REGEX_VALUE = namedtuple("REGEX_VALUE",
                         "text values")


class Intent(object):
    SLOT_TAG_PATTERN = re.compile(r'<([^:]+):([a-zA-Z\d가-힣\-_]+)>')

    def __init__(self, data, entity_list, file_path, pre_process_list):
        self.name = data['intent']
        self._validation_check(data, entity_list, file_path)

        self.slots = []
        self.utterances = []
        self.regex = []

        if 'slots' in data:
            for slot in data['slots']:
                default = slot.get('default', None)
                prompts = slot.get('prompts', None)
                context = slot.get('context', False)
                entity = slot.get('entity', None)
                self.slots.append(SLOT_VALUE(slot['name'], entity, prompts, default, context, slot['is_list']))

        slot_name_list = [slot.name for slot in self.slots]

        if 'utterances' in data:
            submit_list = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                for utterance in data['utterances']:
                    if isinstance(utterance, str):
                        slot_tags = []
                        param = {'margin': 0}
                        text = re.sub(Intent.SLOT_TAG_PATTERN,
                                      lambda x: self._extract_slot_tag(x, slot_name_list, self.name, param, slot_tags),
                                      utterance)
                    else:
                        slot_tags = []
                        if "slot_tags" in utterance:
                            for slot_tag in utterance['slot_tags']:
                                slot_tags.append(
                                    SLOT_TAG_VALUE(slot_tag['start'], slot_tag['end'], slot_tag['value'],
                                                   slot_tag['slot']))
                        text = utterance['text']
                    submit_list.append(executor.submit(self._pre_process, pre_process_list, text, slot_tags))
                for submit in tqdm(submit_list, desc=self.name):
                    submit_result = submit.result()
                    if submit_result[0] is True:
                        self.utterances.append(UTTERANCE_VALUE(submit_result[1], submit_result[2]))
                    else:
                        print("error")

        if 'regex' in data:
            for regex in data['regex']:
                if isinstance(regex, str):
                    self.regex.append(REGEX_VALUE(re.compile(regex), []))
                else:
                    values = regex.get('slot_tags', [])
                    self.regex.append(REGEX_VALUE(re.compile(regex['text']), values))

    def _pre_process(self, pre_process_list, text, slot_tags):
        try:
            processed_text = text
            for pre in pre_process_list:
                processed_text = pre.run(None, processed_text)

            if not slot_tags:
                return True, processed_text, slot_tags

            if white_space_remove(processed_text) != white_space_remove(text):
                return True, text, slot_tags

            match_result, _ = string_dtw.get_match_result(text, processed_text)
            for idx, slot_tag in enumerate(slot_tags):
                slot_tags[idx] = SLOT_TAG_VALUE(match_result[slot_tag.start][1], match_result[slot_tag.end - 1][1] + 1,
                                                slot_tag.value, slot_tag.slot)
            return True, processed_text, slot_tags
        except Exception as e:
            return False, e, None

    def _validation_check(self, data, entity_list, file_path):
        error_list = []
        slot_name_list = [slot['name'] for slot in data['slots']] if 'slots' in data else []

        if 'utterances' not in data and 'regex' not in data:
            raise IntentError(file_path, data['intent'], "utterance, regex 중 최소 하나 이상의 데이터가 필요합니다.")

        for node_name, node in data.items():
            try:
                if node_name == 'intent':
                    continue
                elif node_name == 'slots':
                    check_slots(node, entity_list, file_path)
                elif node_name == 'utterances':
                    check_utterances(node, slot_name_list, Intent.SLOT_TAG_PATTERN, file_path)
                elif node_name == 'regex':
                    check_regex(node, slot_name_list, file_path)
            except Exception as e:
                error_list.append(e)
        if error_list:
            raise Exception('\n'.join([str(e) for e in error_list]))

    @staticmethod
    def _extract_slot_tag(match_result, slot_name_list, intent_name, param, slot_tags):
        value, slot = match_result.groups()
        if slot not in slot_name_list:
            return match_result.group()

        start = match_result.start() + param['margin']
        end = start + len(value)
        param['margin'] += len(value) - len(match_result.group())
        slot_tags.append(SLOT_TAG_VALUE(start, end, value, slot))
        return value


@traced
def load(dir_path, entity_list, pre_process_list):
    print(' === intent load === ')
    file_paths = list(glob.glob(dir_path + "/*.yml"))
    file_paths.extend(list(glob.glob(SystemPath().intent_path + "/*.yml")))
    intent_list = {}
    error_list = []

    if len(file_paths) == 0:
        ResourceNotFoundWarnings("Intent 파일이 없습니다.", dir_path)

    for file_path in file_paths:
        try:
            data = yml.load(file_path, SCHEMA)
            name = data['intent']
            if name in intent_list.keys():
                error_list.append(IntentError(file_path, name, 'intent 이름이 중복되었습니다.'))
                continue

            intent_list[name] = None
            intent_list[name] = Intent(data, entity_list, file_path, pre_process_list)
        except Exception as e:
            error_list.append(IntentError(file_path, "", "\n" + str(e)))

    if error_list:
        print(' === intent load errors === ')
        print('\n'.join([str(e) for e in error_list]))
        raise Exception()
    return intent_list
