__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/08"

from svlog import getLogger

from selvybot.type.scenario_resource.statement import *

logger = getLogger()


def check_section(node_name, node_value, intent_list, function_list, node_names):
    file_path = node_value.get('$path', '')
    error_list = []
    for section, value in node_value.items():
        try:
            if section == 'cond':
                ConditionSection(file_path, node_name).check(value, intent_list, function_list, node_names)
            elif section == 'user':
                UserSection(file_path, node_name).check(value, intent_list, function_list, node_names)
            elif section == 'chatbot':
                ChatbotSection(file_path, node_name).check(value, intent_list, function_list, node_names)
            elif section == 'jump':
                JumpSection(file_path, node_name).check(value, intent_list, function_list, node_names)
            elif section == 'next':
                NextSection(file_path, node_name).check(value, intent_list, function_list, node_names)
            elif section == '$path':
                continue
            else:
                raise ScenarioError(file_path, node_name, section, "", "이/가 적절하지 않습니다.")
        except Exception as e:
            error_list.append(e)
    if error_list:
        raise Exception("\n".join([str(e) for e in error_list]))


class Section(object):
    def __init__(self, file_path, node_name, statement_list):
        self._file_path = file_path
        self._node_name = node_name
        self._statement_list = [st(file_path, node_name, self.__class__.__name__) for st in statement_list]

    def check(self, value, intent_list, function_list, node_names):
        for element in value:
            checked = False
            for statement in self._statement_list:
                if statement.check(element):
                    statement.validate(element, intent_list, function_list, node_names, self.check)
                    checked = True
                    break
            if not checked:
                raise ScenarioError(self._file_path, self._node_name, self.__class__.__name__, element, "가 적절하지 않습니다.")

    def __repr__(self):
        return "{} {}".format(self.__class__.__name__,
                              [statement.__class__.__name__ for statement in self._statement_list])


class UserSection(Section):
    def __init__(self, file_path, node_name):
        statement_list = [IntentStatement]
        super().__init__(file_path, node_name, statement_list)


class ChatbotSection(Section):
    def __init__(self, file_path, node_name):
        statement_list = [IFStatement, EnvStatement, SwitchStatement, AssignStatement, UnAssignStatement,
                          CronStatement, DelayStatement, UnscheduleStatement,
                          ChatbotListStatement, FunctionStatement, StringStatement]
        super().__init__(file_path, node_name, statement_list)


class JumpSection(Section):
    def __init__(self, file_path, node_name):
        statement_list = [JumpNodeStatement]
        super().__init__(file_path, node_name, statement_list)


class ConditionSection(Section):
    def __init__(self, file_path, node_name):
        statement_list = [FunctionStatement, ConditionStatement]
        super().__init__(file_path, node_name, statement_list)


class NextSection(Section):
    def __init__(self, file_path, node_name):
        statement_list = [NextNodeStatement]
        super().__init__(file_path, node_name, statement_list)
