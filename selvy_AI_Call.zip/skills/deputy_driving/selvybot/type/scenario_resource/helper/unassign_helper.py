# -*- coding: utf-8-*-
from svlog import logged

from selvybot.schema.type import PATTERN_VAR
from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/29"


@logged
class UnAssignHelper(Helper):
    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'unassign' in attrib

    def __init__(self, parser, section_name, attrib):

        entity_list = []
        for token in attrib['unassign']:
            match_result = PATTERN_VAR.match(token)
            l, t = match_result.groups()
            entity_list.append((l, t))

        def delete_variable(context):
            for loc, target_name in entity_list:
                if loc == '$$':
                    target = context.local
                elif loc == '$':
                    target = context.glob
                else:
                    self.__log.warn("system 변수를 수정하려고 함")
                    continue
                target.pop(target_name, None)
            return ""

        self._core = delete_variable

    def run(self, assemble_utterance_func, context, responses, text):
        self._core(context)
