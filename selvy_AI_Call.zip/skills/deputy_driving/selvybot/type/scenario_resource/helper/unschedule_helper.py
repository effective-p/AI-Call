# -*- coding: utf-8-*-

from svlog import logged

from selvybot.core.scheduler import Scheduler
from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/11/01"


@logged
class UnscheduleHelper(Helper):
    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'unschedule' in attrib

    def __init__(self, parser, section_name, attrib):
        self._scheduler = Scheduler()
        self._jobs = attrib['unschedule']

    def run(self, assemble_utterance_func, context, responses, text):
        for job in self._jobs:
            self._scheduler.delete(user_id=context.system['user'], job_id=job)
