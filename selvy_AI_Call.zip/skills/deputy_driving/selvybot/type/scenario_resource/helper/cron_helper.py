# -*- coding: utf-8-*-

from svlog import logged

from selvybot.core.scheduler import Scheduler
from selvybot.core.variable_replacer import VariableReplacer
from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/10/31"


@logged
class CronHelper(Helper):
    PARAM_KEYS = set(['year', 'month', 'day', 'week', 'day_of_week', 'hour', 'minute', 'second', 'start_date',
                      'end_date', 'timezone'])

    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'cron' in attrib

    def __init__(self, parser, section_name, attrib):
        name = attrib['cron']
        params = attrib['params']
        messages = [parser.run(section_name, t) for t in attrib['then']]
        params = dict(params)
        if 'dnd_timer' in params:
            dnd_timer = int(params['dnd_timer'])
            params.pop('dnd_timer', None)
        else:
            dnd_timer = 0

        if 'context_reset' in params:
            context_reset = bool(params['context_reset'])
            params.pop('context_reset', None)
        else:
            context_reset = False

        if not set(params.keys()).issubset(CronHelper.PARAM_KEYS):
            raise Exception('delay: parameter가 잘못 입력되었습니다.')

        params['trigger'] = 'cron'
        for k, v in params.items():
            params[k] = VariableReplacer().dynamic(v)

        self._scheduler = Scheduler()
        self._dnd_timer = dnd_timer
        self._job_id = name
        self._params = params
        self._messages = messages
        self._context_reset = context_reset

    def run(self, assemble_utterance_func, context, responses, text):
        if not context.local['$reply_url']:
            return

        alarm_responses = [{"text": ""}]
        for result in self._messages:
            assemble_utterance_func(context, alarm_responses, result, text)

        params = dict()
        for k, v in self._params.items():
            params[k] = v(context)

        self._scheduler.post(user_id=context.system['user'],
                             job_id=self._job_id,
                             reply_url=context.local['$reply_url'],
                             utterances=alarm_responses,
                             params=params,
                             dnd_timer=self._dnd_timer,
                             context_reset=self._context_reset)
