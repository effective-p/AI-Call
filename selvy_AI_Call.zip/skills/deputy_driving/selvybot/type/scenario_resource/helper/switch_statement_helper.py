# -*- coding: utf-8-*-

from selvybot.core.condition_checker import ConditionChecker
from selvybot.type.scenario_resource.helper import Helper

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/29"


class SwitchStatementHelper(Helper):
    @staticmethod
    def check(attrib):
        return isinstance(attrib, dict) and 'switch' in attrib

    def __init__(self, parser, section_name, attrib):
        cond_then_list = []
        for sw in attrib['switch']:
            cond = parser.run(section_name, sw['cond'])
            then = [parser.run(section_name, t) for t in sw['then']]
            cond_then_list.append((cond, then))

        self._cond_then_list = cond_then_list

    def run(self, assemble_utterance_func, context, responses, text):
        for cond, then in self._cond_then_list:
            if ConditionChecker().run(context, cond, text):
                for t in then:
                    assemble_utterance_func(context, responses, t, text)
                return
