import inspect
import re

from selvybot.core.parameter_splitter import ParameterSplitter
from selvybot.error.function import FunctionError
from selvybot.error.scenario import ScenarioError
from selvybot.schema.type import PATTERN_FUNCTION

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/08"


class Statement(object):
    def __init__(self, file_path, node_name, section_name):
        self._node_name = node_name
        self._section_name = section_name
        self._file_path = file_path

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        return True

    def check(self, statement):
        return True


class FunctionStatement(Statement):
    def check(self, statement):
        if isinstance(statement, dict) and 'function' in statement:
            return True
        if not isinstance(statement, str):
            return False
        match = PATTERN_FUNCTION.search(statement)
        if not match:
            return False
        return True

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        if isinstance(statement, dict):
            func_name = statement['function']
            input_params = statement['params']
        elif isinstance(statement, str):
            match = PATTERN_FUNCTION.search(statement)
            func_name = match.group(1)
            input_params = match.group(2)
            input_params = ParameterSplitter().run(input_params)
        else:
            pass
        if func_name not in function_list:
            raise FunctionError(self._file_path, self._node_name, self._section_name, statement,
                                "함수가 리소스 파일에 정의되어 있지 않습니다.")
        func = getattr(function_list[func_name], 'build')
        params = inspect.signature(func).parameters
        if str(list(params.values())[-1])[0] == '*':
            return
        max_param = len(params) - 1
        min_param = len([v for v in params.values() if v.default == inspect._empty]) - 1
        if min_param > len(input_params) or max_param < len(input_params):
            # TODO jskim 필요한 인자정보도 저장하도록 수정
            raise FunctionError(self._file_path, self._node_name, self._section_name, statement,
                                "함수에 필요한 인자개수가 기술된 내용과 다릅니다.")


class IFStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'if' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        then_state = statement['then'] if isinstance(statement['then'], list) else [statement['then']]
        check_func(then_state, intent_list, function_list, node_names)
        if 'else' in statement:
            else_state = statement['else'] if isinstance(statement['else'], list) else [statement['else']]
            check_func(else_state, intent_list, function_list, node_names)

class EnvStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'env' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        value_state = statement['values'] if isinstance(statement['values'], list) else [statement['values']]
        check_func(value_state, intent_list, function_list, node_names)
        if 'default' in statement:
            default_state = statement['default'] if isinstance(statement['default'], list) else [statement['default']]
            check_func(default_state, intent_list, function_list, node_names)

class AssignStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'assign' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        value_state = statement['values'] if isinstance(statement['values'], list) else [statement['values']]
        check_func(value_state, intent_list, function_list, node_names)
        # TODO jskim value 하위에 if,switch,function 지원 하도록 수정


class UnAssignStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'unassign' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        pass


class SwitchStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'switch' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        for elem in statement['switch']:
            then_state = elem['then'] if isinstance(elem['then'], list) else [elem['then']]
            check_func(then_state, intent_list, function_list, node_names)


class CronStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'cron' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        then_state = statement['then'] if isinstance(statement['then'], list) else [statement['then']]
        check_func(then_state, intent_list, function_list, node_names)


class DelayStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'delay' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        then_state = statement['then'] if isinstance(statement['then'], list) else [statement['then']]
        check_func(then_state, intent_list, function_list, node_names)


class UnscheduleStatement(Statement):
    def check(self, statement):
        return isinstance(statement, dict) and 'unschedule' in statement

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        pass


class IntentStatement(Statement):
    def check(self, statement):
        return isinstance(statement, str)

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        if statement not in intent_list:
            raise ScenarioError(self._file_path, self._node_name, self._section_name, statement,
                                "의도가 리소스 파일에 정의되어 있지 않습니다.")


class ChatbotListStatement(Statement):
    def check(self, statement):
        return isinstance(statement, list)

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        for value in statement:
            if not isinstance(value, str):
                raise ScenarioError(self._file_path, self._node_name, self._section_name, statement,
                                    "챗봇 발화 리스트에 문자열이 아닌 값이 포함되어 있습니다.")


class JumpNodeStatement(Statement):
    def validate(self, statement, intent_list, function_list, node_names, check_func):
        if statement.node not in node_names:
            raise ScenarioError(self._file_path, self._node_name, self._section_name, statement, "노드가 정의되지 않았습니다.")


class NextNodeStatement(Statement):
    def validate(self, statement, intent_list, function_list, node_names, check_func):
        if statement.node not in node_names:
            raise ScenarioError(self._file_path, self._node_name, self._section_name, statement, "노드가 정의되지 않았습니다.")


class StringStatement(Statement):
    def check(self, statement):
        return isinstance(statement, str)


class RegexStatement(Statement):
    def __init__(self, file_path, node_name, section_name):
        super().__init__(file_path, node_name, section_name)
        self._variable_pattern = re.compile(r'([$|#]{1,2}\([가-힣\da-zA-Z-_]+\))')

    def check(self, statement):
        match = self._variable_pattern.search(statement)
        if match:
            return False

        try:
            re.compile(statement)
            valid = True
        except Exception:
            valid = False
        return valid

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        try:
            re.compile(statement)
        except Exception:
            raise ScenarioError(self._file_path, self._node_name, self._section_name, statement, "정규식은 형식에 맞지 않습니다.")


class ConditionStatement(Statement):
    def check(self, statement):
        # todo Rayna 조건문 체크 조건 작성
        return True

    def validate(self, statement, intent_list, function_list, node_names, check_func):
        # todo Rayna 조건문
        return True
