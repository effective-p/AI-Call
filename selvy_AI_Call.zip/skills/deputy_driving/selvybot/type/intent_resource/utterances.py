from selvybot.error.intent import UtteranceError

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/14"


class Tagger(object):
    pass


class IndexTagger(Tagger):
    @staticmethod
    def check(value):
        if isinstance(value, dict):
            return True
        return False

    @staticmethod
    def validate(utterance, slot_name_list, slot_tag_pattern, file_path, utterance_index):
        error_list = []
        text = utterance['text']
        slot_tags = utterance.get('slot_tags', [])

        for tags in slot_tags:
            if text[tags['start']:tags['end']] != tags['value']:
                error_list.append(
                    UtteranceError(file_path, utterance_index, tags, 'value 값이 text에 없습니다. start, end, value를 확인 해주세요'))

            if tags['slot'] not in slot_name_list:
                error_list.append(UtteranceError(file_path, utterance_index, tags, '슬롯이 정의되어 있지 않습니다.'))
        if error_list:
            raise Exception('\n'.join([str(e) for e in error_list]))


class NameTagger(Tagger):
    @staticmethod
    def check(value):
        if isinstance(value, str):
            return True
        return False

    @staticmethod
    def validate(utterance, slot_name_list, slot_tag_pattern, file_path, utterance_index):
        match = slot_tag_pattern.findall(utterance)
        if not match:
            return

        error_list = []
        for group in match:
            if group[1] not in slot_name_list:
                error_list.append(UtteranceError(file_path, utterance_index, group[1], '슬롯이 정의되어 있지 않습니다.'))

        if error_list:
            raise Exception('\n'.join([str(e) for e in error_list]))


def check_utterances(node, slot_name_list, slot_tag_pattern, file_path):
    error_list = []
    for index in range(len(node)):
        try:
            validate = get_tag_checker(node[index])
            if validate is None:
                raise UtteranceError(file_path, index, node[index], 'utterances 속성 값의 형태로 적절하지 않습니다.')
            validate(node[index], slot_name_list, slot_tag_pattern, file_path, index)
        except Exception as e:
            error_list.append(e)
    if error_list:
        raise Exception('\n'.join([str(e) for e in error_list]))


def get_tag_checker(value):
    if IndexTagger.check(value):
        return IndexTagger.validate
    elif NameTagger.check(value):
        return NameTagger.validate
    return None
