from selvybot.error.intent import SlotError

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/05/14"


class Slot():
    @staticmethod
    def validate(slot_dict, entity_list, file_path):
        error_list = []
        slot_index = 0
        for slot in slot_dict:
            if 'entity' in slot and slot['entity'] not in entity_list.keys():
                error_list.append(SlotError(file_path, slot_index, 'entity', slot['entity'], '가 entity 안에 존재하지 않습니다.'))
            slot_index += 1

        if error_list:
            raise Exception('\n'.join([str(e) for e in error_list]))


def check_slots(slot_dict, entity_list, file_path):
    Slot.validate(slot_dict, entity_list, file_path)
