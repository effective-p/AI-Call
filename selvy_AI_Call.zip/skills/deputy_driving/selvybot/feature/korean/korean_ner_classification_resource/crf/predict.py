# -*- coding: utf-8 -*-
import argparse
import pickle
import time
from pathlib import Path

import pycrfsuite

from . import crf_model
from . import dataset


def predict_batch(sentences, tagger):
    test_x = [crf_model.sent2features(sent) for sent in sentences]
    pred_y = [[tag.encode('utf-8').decode('unicode_escape')] for x in test_x for tag in tagger.tag(x)]
    return test_x, pred_y


def predict(sentence, tagger):
    x = crf_model.sent2features(sentence)
    y = [tag.encode('utf-8').decode('unicode_escape') for tag in tagger.tag(x)]
    return x, y


def get_tagger(model_path):
    tagger = pycrfsuite.Tagger()
    if Path(model_path).exists():
        tagger.open(model_path)
        return tagger
    else:
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, required=True)
    parser.add_argument("--dict", type=str, required=True)
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--output", type=str, required=True)
    args = parser.parse_args()

    pk = pickle.load(open(args.dict, "rb"))
    gazetteer = pk['dic']
    max_key_len = pk['max_key_len']
    sentences = dataset.conll2dataset([args.input], gazetteer, max_key_len)

    tagger = get_tagger(args.model)

    start = time.time()
    test_x, pred_y = predict_batch(sentences, tagger)
    test_y = [crf_model.sent2tags(sent) for sent in sentences]
    end = time.time()
    print("test sequence size: %i, test time : %.4fs" % (len(sentences), end - start))
    # crf_model.flush('pred.txt', test_x, pred_y)
    crf_model.report(test_y, pred_y)

    with open(args.output, "w", encoding="utf-8") as f:
        for sentence, pred in zip(sentences, pred_y):
            for word, tag in zip(sentence, pred):
                f.write("{} {} {}\n".format(word[0], word[-1], tag))
            f.write("\n")
