# -*- coding: utf-8 -*-
from __future__ import unicode_literals, print_function

import codecs
import string
from itertools import chain

from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelBinarizer


def offset_string(offset):
    if offset < 0:
        sign = ''
    else:
        sign = '+'
    return sign + str(offset)


def index2feature(sent, i, offset, pos):
    val = sent[i + offset][pos]
    return '{}:word{}={}'.format(offset_string(offset), pos, val)


def bigram2feature(sent, i, offset, pos):
    val0 = sent[i + offset][pos]
    val1 = sent[i + offset + 1][pos]
    return '{}:bigram={}/{}'.format(offset_string(offset), val0, val1)


def trigram2feature(sent, i, offset, pos):
    val0 = sent[i + offset][pos]
    val1 = sent[i + offset + 1][pos]
    val2 = sent[i + offset + 2][pos]
    return '{}:trigram={}/{}/{}'.format(offset_string(offset), val0, val1, val2)


def quadgram2feature(sent, i, offset, pos):
    val0 = sent[i + offset][pos]
    val1 = sent[i + offset + 1][pos]
    val2 = sent[i + offset + 2][pos]
    val3 = sent[i + offset + 3][pos]
    return '{}:quadragram={}/{}/{}/{}'.format(offset_string(offset), val0, val1, val2, val3)


def is_punc(sent, i, offset, pos):
    if sent[i + offset][pos] in set(string.punctuation):
        return '{}:punc=1'.format(offset_string(offset))
    else:
        return '{}:punc=0'.format(offset_string(offset))


def is_digit(sent, i, offset, pos):
    if sent[i + offset][pos].isdigit():
        return '{}:numb=1'.format(offset_string(offset))
    else:
        return '{}:numb=0'.format(offset_string(offset))


def prefixfeature(sent, i, offset, pos):
    val = sent[i + offset][pos]
    return '{}:prefix={}/{}/{}/{}'.format(offset, val[0],
                                          val[:min(2, len(val))],
                                          val[:min(3, len(val))],
                                          val[:min(4, len(val))])


def surfixfeature(sent, i, offset, pos):
    val = sent[i + offset][pos]
    return '{}:surfix={}/{}/{}/{}'.format(offset, val[-1],
                                          val[max(0, len(val) - 2):],
                                          val[max(0, len(val) - 3):],
                                          val[max(0, len(val) - 4):])


def word2features(sent, i):
    L = len(sent)
    features = ['bias']
    features.append(index2feature(sent, i, 0, 0))
    features.append(index2feature(sent, i, 0, 1))
    features.append(index2feature(sent, i, 0, 2))
    features.append(index2feature(sent, i, 0, 3))
    features.append(index2feature(sent, i, 0, 4))
    features.append(is_digit(sent, i, 0, 0))
    features.append(is_punc(sent, i, 0, 0))

    prefixfeature(sent, i, 0, 0)
    surfixfeature(sent, i, 0, 0)

    if i > 1:
        features.append(index2feature(sent, i, -2, 0))
        features.append(trigram2feature(sent, i, -2, 0))
        features.append(index2feature(sent, i, -2, 1))
        features.append(index2feature(sent, i, -2, 2))
        features.append(index2feature(sent, i, -2, 3))
        features.append(index2feature(sent, i, -2, 4))
        # features.append(is_digit(sent, i, -2, 0))
        features.append(is_punc(sent, i, -2, 0))
    if i > 0:
        features.append(index2feature(sent, i, -1, 0))
        features.append(bigram2feature(sent, i, -1, 0))
        features.append(index2feature(sent, i, -1, 1))
        features.append(index2feature(sent, i, -1, 2))
        features.append(index2feature(sent, i, -1, 3))
        features.append(index2feature(sent, i, -1, 4))
        # features.append(is_digit(sent, i, -1, 0))
        features.append(is_punc(sent, i, -1, 0))
    else:
        features.append('bos')
    if i < L - 2:
        features.append(index2feature(sent, i, 2, 0))
        features.append(trigram2feature(sent, i, 0, 0))
        features.append(index2feature(sent, i, 2, 1))
        features.append(index2feature(sent, i, 2, 2))
        features.append(index2feature(sent, i, 2, 3))
        features.append(index2feature(sent, i, 2, 4))
        # features.append(is_digit(sent, i, 2, 0))
        features.append(is_punc(sent, i, 2, 0))
    if i < L - 1:
        features.append(index2feature(sent, i, 1, 0))
        features.append(bigram2feature(sent, i, 0, 0))
        features.append(index2feature(sent, i, 1, 1))
        features.append(index2feature(sent, i, 1, 2))
        features.append(index2feature(sent, i, 1, 3))
        features.append(index2feature(sent, i, 1, 4))
        # features.append(is_digit(sent, i, 1, 0))
        features.append(is_punc(sent, i, 1, 0))
    else:
        features.append('eos')

    if i > 2:
        features.append(quadgram2feature(sent, i, -3, 0))
    if i < L - 3:
        features.append(quadgram2feature(sent, i, 0, 0))

    return features


def sent2words(sent):
    return [word[0] for word in sent]


def sent2tags(sent):
    return [word[-1] for word in sent]


def sent2features(sent):
    return [word2features(sent, i) for i in range(len(sent))]


def report(test_y, pred_y):
    lb = LabelBinarizer()
    test_y_combined = lb.fit_transform(list(chain.from_iterable(test_y)))
    pred_y_combined = lb.transform(list(chain.from_iterable(pred_y)))
    tagset = sorted(set(lb.classes_))
    class_indices = {cls: idx for idx, cls in enumerate(tagset)}
    print(classification_report(test_y_combined, pred_y_combined, labels=[class_indices[cls] for cls in tagset],
                                target_names=tagset))


def flush(path, X, Y):
    result = codecs.open(path, 'w', encoding='utf-8')
    for x, y in zip(X, Y):
        result.write(' '.join(['{}/{}'.format(feature[1].split('=')[1], tag) for feature, tag in zip(x, y)]))
        result.write('\n')
    result.close()