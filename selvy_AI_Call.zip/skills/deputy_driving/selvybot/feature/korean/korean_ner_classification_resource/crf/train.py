# -*- coding: utf-8 -*-
import argparse
import pickle

import pycrfsuite

from . import crf_model
from . import dataset


def train(train_algorithm, sentences, output):
    train_x = [crf_model.sent2features(sent) for sent in sentences]
    train_y = [crf_model.sent2tags(sent) for sent in sentences]
    trainer = pycrfsuite.Trainer(algorithm=train_algorithm)

    for x, y in zip(train_x, train_y):
        trainer.append(x, [item.encode('unicode-escape') for item in y])
    trainer.train(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, required=True)
    parser.add_argument("--dict", type=str, required=True)
    parser.add_argument("--learning", type=str, required=False, default='pa')
    parser.add_argument("--output", type=str, required=True)
    args = parser.parse_args()

    pk = pickle.load(open(args.dict, "rb"))
    gazetteer = pk['dic']
    max_key_len = pk['max_key_len']
    sentences = dataset.conll2dataset([args.input], gazetteer, max_key_len)
    train(args.learning, sentences, args.output)
