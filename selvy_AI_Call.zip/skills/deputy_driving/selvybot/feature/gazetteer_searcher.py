# -*- coding: utf-8-*-
import pygtrie
from svlog import logged

from selvybot.feature import Feature
from selvybot.util import white_space_remove, number_normalize, SingletonFactory

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/18"


@logged
class GazetteerSearcherGlobal(Feature):
    def __init__(self, resource_path):
        self._gazetteer = None

    def prefix_search(self, text, longest=True):
        # TODO jskim intent를 입력 받고 intent에 해당하는 사전만 검색하도록 수정
        if not self._gazetteer:
            return []
        entity_labels = []
        find_positions = []
        idx_table = {}
        idx = 0
        for i, char in enumerate(text):
            if char == ' ':
                continue
            if i == 0 or text[i - 1] == ' ':
                find_positions.append(idx)
            elif char.isdigit() and text[i - 1].isdigit() is True:
                continue
            idx_table[idx] = i
            idx += 1

        line = number_normalize(white_space_remove(text))
        idx = 0
        while True:
            if longest:
                possible_match = self._gazetteer.longest_prefix(line[idx:])
            else:
                possible_match = self._gazetteer.shortest_prefix(line[idx:])
            if possible_match:
                value = possible_match[0]
                entities = possible_match[1]
                start = idx_table[idx]
                end = idx_table[idx + len(value) - 1] + 1
                # TODO jskim n개의 entity 결과를 특징에 반영하도록 수정
                entity_labels.append({'StartToken': start, 'EndToken': end, 'EntityType': entities[0]})

                '''
                for entity in entities:
                    entity_labels.append({'StartToken': start, 'EndToken': end, 'EntityType': entity})
                '''

                idx += len(value)
            else:
                idx += 1
            next_list = [x for x in find_positions if x >= idx]
            if not next_list:
                break
            idx = min(next_list)
        return entity_labels

    def train(self, intent_list, entity_list):
        slots = [slot for intent_name, intent in intent_list.items() for slot in intent.slots]
        gazetteer = pygtrie.CharTrie()
        for entity in set([slot.entity for slot in slots]):
            if entity is None:
                continue

            for word in entity_list[entity]:
                # TODO jskim 사전 단어의 공백을 제거, 추후에 문제없는지 재검토 필요
                word = number_normalize(white_space_remove(word))
                if word in gazetteer:
                    gazetteer[word].append(entity)
                else:
                    gazetteer[word] = [entity]
        self._gazetteer = gazetteer
        return gazetteer

    def load(self, gazetteer):
        self._gazetteer = gazetteer


class GazetteerSearcher(metaclass=SingletonFactory):
    @staticmethod
    def factory(language, *args, **kwargs):
        return GazetteerSearcherGlobal(*args, **kwargs)
