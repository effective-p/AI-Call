# -*- coding: utf-8-*-
import os
import tempfile
import time
from collections import OrderedDict
from distutils import dir_util

from flask import url_for
from flask_restful import Api
from svlog import logged, FlaskWithLog, traced
from werkzeug.utils import redirect
from datetime import datetime

from selvybot import function
from selvybot.core.morph_analyzer import MorphAnalyzer
from selvybot.core.scheduler import Scheduler
from selvybot.db import DatabaseDriver
from selvybot.db import MysqlDriver, SqliteDriver
from selvybot.db.model.context_model import ContextManager
from selvybot.db.model.engine_model import EngineManager
from selvybot.db.model.session_model import SessionManager # for gateway
from selvybot.feature.gazetteer_searcher import GazetteerSearcher
from selvybot.feature.intent_classification import IntentClassification
from selvybot.feature.ner_classification import NerClassification
from selvybot.feature.sentence_embedding import SentenceEmbedding
from selvybot.postprocess.josa_selection import JosaSelection
from selvybot.preprocess.segmentation import Segmentation
from selvybot.preprocess.korean.korean_num_to_arabia import KoreanNumToArabia
from selvybot.search.base_search import BaseSearch
from selvybot.server.context import ContextResource
from selvybot.server.convert import ConvertResource
from selvybot.server.dnd import DndResource
from selvybot.server.download import ScenarioResource, ScriptResource
from selvybot.server.message import MessageResource
from selvybot.server.meta import MetaResource
from selvybot.server.static_file import StaticFile
from selvybot.type import intent, scenario, entity, meta
from selvybot.util import ResourcePath, SystemPath
from selvybot.util import config
from selvybot.util.common import class_name, last_element, generate_hash
from selvybot.util.zip import zip_dir

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/08/02"


@traced('__init__', 'build', '_load_resource', '_convert')
@logged
class App(object):
    def __init__(self, components_url, resource_root, db_driver, language='korean',
                 domain_url='http://localhost:8080', license_key=None, session_maintain_time=300,
                 model_store_to_db=False, model_store_to_local=True, access_token='selvybot',
                 intent_threshold=0.7, ignore_time=False, native_app=None):
        if not isinstance(db_driver, DatabaseDriver):
            raise TypeError('mysql_account 매개변수는 잘못된 클래스입니다. MysqlAccount 클래스를 확인해주세요.')

        self._license_key = license_key
        self._access_token = access_token
        self._resource_path = ResourcePath(components_url, domain_url, resource_root)
        self._language = language

        # pylint: disable=no-member
        self.pre_process_list = [Segmentation(language, self._resource_path), KoreanNumToArabia(language, self._resource_path)]
        self.post_process_list = [JosaSelection(language, self._resource_path)]
        self._feature_list = [SentenceEmbedding(language, self._resource_path),
                              GazetteerSearcher(language, self._resource_path),
                              IntentClassification(language, self._resource_path, intent_threshold),
                              NerClassification(language, self._resource_path)]
        # pylint: enable=no-member
        self._search_engine = BaseSearch
        self._search = None
        self._scenario = None
        self._meta = None
        self._system_function_list = None
        self._user_function_list = None
        self._session_maintain_time = session_maintain_time
        self._ignore_time = ignore_time
        self._native_app = native_app
        # serving
        self._app = FlaskWithLog(__name__, static_folder=SystemPath().static_path,
                                 template_folder=SystemPath().template_path)
        self._app.set_url_list_for_logging(['/', '/context', '/convert', '/scenario', '/script'])

        # flask_sqlalchemy
        self._db_driver = db_driver
        self._db_driver.lazy_init(self._app)
        self._context_manager = ContextManager(self._db_driver, maintain_time=self._session_maintain_time)
        self._engine_manager = EngineManager(self._db_driver, model_store_to_db, model_store_to_local)
        self._session_manager = SessionManager(self._db_driver, maintain_time=self._session_maintain_time) # for gateway

    def _load_resource(self, resource_path, meta_data, entity_list, synonym_list, force_rebuild=False):
        entity_hash = generate_hash([resource_path.entity_path], '.txt')
        intent_hash = generate_hash([SystemPath().intent_path, resource_path.intent_path], '.yml')
        hash = entity_hash + intent_hash

        # intent
        if force_rebuild or not self._engine_manager.exist('intent', meta_data['version'], intent_hash, self._language,
                                                           resource_path):
            intent_list = intent.load(resource_path.intent_path, entity_list, self.pre_process_list)
        else:
            try:
                intent_list = self._engine_manager.restore('intent', meta_data['version'], intent_hash, self._language,
                                                           resource_path)
            except Exception as e:
                intent_list = intent.load(resource_path.intent_path, entity_list, self.pre_process_list)

        self._engine_manager.save('intent', meta_data['version'], intent_hash, self._language, resource_path,
                                  intent_list)

        print(' === feature train === ')
        for feature in self._feature_list:
            feature_name = class_name(feature)
            feature.set_entity_list(entity_list)

            if force_rebuild or not self._engine_manager.exist(feature_name, meta_data['version'], hash, self._language,
                                                               resource_path):
                model = feature.train(intent_list, entity_list)
            else:
                try:
                    model = self._engine_manager.restore(feature_name, meta_data['version'], hash, self._language,
                                                         resource_path)
                    feature.load(model)
                except Exception as e:
                    model = feature.train(intent_list, entity_list)

            self._engine_manager.save(feature_name, meta_data['version'], hash, self._language, resource_path, model,
                                      force=force_rebuild)

        function_list = function.load([SystemPath().function_path, resource_path.function_path])
        out_scenario = scenario.load(resource_path.scenario_path, intent_list, function_list, resource_path)
        out_search = self._search_engine(out_scenario, intent_list, synonym_list, self._language)
        return out_scenario, out_search

    def build(self, force_rebuild=False):
        try:
            self._meta = meta.load(self._resource_path.root_path)
            entity_list, synonym_list = entity.load(self._resource_path.entity_path)
            # init
            Scheduler(self._meta['name'], self._resource_path, self._access_token)
            MorphAnalyzer(entity_list)
            self._scenario, self._search = \
                self._load_resource(self._resource_path, self._meta, entity_list, synonym_list, force_rebuild)
            self._config_flask()
        except Exception as e:
            self.__log.error(e)
            print("모델 빌드에 실패 했습니다")
            exit(1)

        def check():
            from selvybot.util.reader import check
            check(self._license_key, self._app)

        (lambda: check())()

    def _convert(self, file_path):
        self.__log.debug("리소스 변환 시작")
        tmp_dir = tempfile.mkdtemp()
        try:
            file_ext = os.path.splitext(file_path)[1]
            if file_ext == ".zip":
                resource_path = ResourcePath(self._resource_path.components_url, self._resource_path.domain_url,
                                             file_path)
            elif file_ext == ".xlsx":
                dir_util.copy_tree(self._resource_path.root, tmp_dir)
                resource_path = ResourcePath(self._resource_path.components_url, self._resource_path.domain_url,
                                             tmp_dir)
            else:
                self.__log.debug("파일 분석 실패")
                raise Exception("파일 포맷이 적합하지 않습니다.")

            meta_data = meta.load(resource_path.root_path)
            entity_list, synonym_list = entity.load(resource_path.entity_path)
            converted_scenario, _ = self._load_resource(resource_path, meta_data, entity_list, synonym_list)

            if file_ext == ".xlsx":
                converted_scenario.import_script(file_path)
                meta_data = meta.patch_update(resource_path.root)

            return meta.dump_json(meta_data), \
                   zip_dir(resource_path.root, except_list=['config.ini']), converted_scenario.export_script()
        finally:
            dir_util.remove_tree(tmp_dir)

    def _config_flask(self):
        # swagger
        self._app.add_url_rule('/apidocs', view_func=lambda: redirect(url_for('/apidocs/')), endpoint='/apidocs')
        self._app.add_url_rule('/apidocs/', view_func=lambda: self._app.send_static_file('apidocs/index.html'),
                               endpoint='/apidocs/')

        api = Api(self._app)
        api.add_resource(MessageResource, '/',
                         resource_class_kwargs={'message_func': self._message, 'upsert_user_id_func': self._upsert_user_id,
                                                'get_user_id_func': self._get_user_id, 'check_user_id_func': self._check_exist_user_id,
                                                'meta_data': self._meta})
        api.add_resource(ContextResource, '/context', resource_class_kwargs={'context_manager': self._context_manager,
                                                                             'access_token': self._access_token})
        api.add_resource(ConvertResource, '/convert', resource_class_kwargs={'convert_func': self._convert})
        api.add_resource(MetaResource, '/meta', resource_class_kwargs={'meta_data': self._meta})
        api.add_resource(DndResource, '/dnd', resource_class_kwargs={'context_manager': self._context_manager})
        # 시스템 static
        api.add_resource(StaticFile, '/<path:path>',
                         resource_class_kwargs={'static_path': SystemPath().static_path})
        # 챗봇리소스 static
        api.add_resource(StaticFile, '/resource/<path:path>',
                         resource_class_kwargs={'static_path': self._resource_path.static_path}, endpoint='endpoint')

        # TODO jskim 외부에서 다운로드 받을수 없게 수정 해야함, 대쉬보드 에이전트에서만 가능하도록.
        # 시나리오, 스크립트
        api.add_resource(ScenarioResource, '/scenario',
                         resource_class_kwargs={'export_scenario_func': lambda: zip_dir(self._resource_path.root,
                                                                                        except_list=['config.ini'])})
        api.add_resource(ScriptResource, '/script',
                         resource_class_kwargs={'export_script_func': lambda: self._scenario.export_script()})
        self._app.config['JSON_AS_ASCII'] = False

    def serve(self, **kwargs):
        self._app.run(**kwargs)

    def flask_app(self):
        return self._app

    def _upsert_user_id(self, user_id, session_id):
        self._session_manager.set_session(user_id, session_id)

    def _get_user_id(self, session_id):
        user_id = self._session_manager.get_id(session_id)
        return user_id

    def _check_exist_user_id(self, user_id):
        is_exist = self._session_manager.is_exist_id(user_id)
        return is_exist

    def _message(self, user_id, text, platform=None, reply_url=None, additional_info=None):
        platform = platform if platform else 'None'
        if not text:
            raise Exception("입력된 발화가 없습니다")

        context, new_user_created = self._context_manager.get(user_id, ignore_time=self._ignore_time)

        if new_user_created:
            self._new_user_created_log(user_id, self._meta['name'], self._meta['version'], platform)
        if isinstance(additional_info, dict):
            context.local.update(additional_info)
        # 시나리오를 통해서 입력받는 변수는 '$'를 입력할수 없다.
        # 시스템이 생성한 변수는 $를 붙임으로서 시나리오 변수와의 충돌을 피할수 있다.
        context.local['$reply_url'] = reply_url
        context.local['$platform'] = platform

        context.system['user'] = user_id
        context.system['originalinput'] = text
        text_lower = text.lower()

        pre_process_result = OrderedDict(first=text_lower)
        for pre in self.pre_process_list:
            pre_process_result[class_name(pre)] = pre.run(context, last_element(pre_process_result))

        context.system['input'] = last_element(pre_process_result)
        context.system['lastnode'] = context.system.get('cursor', 'root')
        raw_responses = self._search.run(context, pre_process_result, last_element(pre_process_result))

        responses = []
        for response in raw_responses:
            text = response['text']
            if not text and len(response) == 1:
                self.__log.warn("text가 비어있는 response가 생성되서 삭제함")
                continue
            for post in self.post_process_list:
                text = post.run(context, text)
            response['text'] = text
            responses.append(response)

        self._context_manager.set(context)
        return responses, {
            'context': {'session': context.session, 'global': context.glob, 'local': context.local,
                        'system': context.system},
            'scenario': self._scenario.serialize()
        }

    def _new_user_created_log(self, user_id, bot_name, version, platform):
        self.__log.info(
            {'log_type': 'new_user', 'user_id': user_id, 'botname': bot_name, 'version': version, 'platform': platform})


def create_bot_from_config(config_path, ignore_build=False):
    conf = config.load(config_path)
    if conf['db']['type'] == "mysql":
        Driver = MysqlDriver
    elif conf['db']['type'] == "sqlite":
        Driver = SqliteDriver
    else:
        raise Exception("지원하지 않는 database 타입입니다. : {}".format(conf['db']['type']))
    conf['db'].pop('type')
    db_driver = Driver(**conf['db'])

    bot = App(db_driver=db_driver, **conf['common'])
    if not ignore_build:
        bot.build(**conf['build'])
    return bot
