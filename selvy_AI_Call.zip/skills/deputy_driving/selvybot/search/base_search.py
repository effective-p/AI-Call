# -*- coding: utf-8-*-
import itertools
import random
import re
from collections import OrderedDict

from svlog import logged

from selvybot.core.condition_checker import ConditionChecker
from selvybot.core.variable_replacer import VariableReplacer
from selvybot.feature.gazetteer_searcher import GazetteerSearcher
from selvybot.feature.intent_classification import IntentClassification
from selvybot.feature.ner_classification import NerClassification
from selvybot.schema.type import MAX_HISTORY_SIZE
from selvybot.search import Search
from selvybot.type.scenario_resource.helper import Helper
from selvybot.util.common import first_element, white_space_remove, number_normalize

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


@logged
class BaseSearch(Search):
    """__init__(self, url)

    기본 시나리오 탐색 모듈

    .. warning::
       없음

    Args:
        function_list (list of Function): function 리스트
        scenario (Scenario): scenario 객체.
        synonym_list (dict of str): 동의어 사전

    .. seealso::
        없음

    """

    def __init__(self, scenario, intent_list, synonym_list, language):
        self._scenario = scenario
        self._intent_list = intent_list
        self._synonym_list = synonym_list
        self._gazetteer_searcher = GazetteerSearcher(language)
        self._ner_classification = NerClassification(language)
        self._intent_classification = IntentClassification(language)

    def run(self, context, pre_process_result, text):
        """
        context의 정보를 바탕으로 시나리오에서 다음 노드를 찾고
        해당 노드의 챗봇 발화를 반환한다.
        Args:
            context (Context):  context 객체.
            pre_process_result (list of str): 전처리 결과.
            text (str): 유저 발화.

        Returns:
            str, 챗봇 발화

        """
        cursor = context.system.get('cursor', 'root')
        path = []
        target_slot = context.system.get('slot', None)

        # slot filling 도중인 경우
        if target_slot:
            match_intent = context.system['match_intent']
            match_node = cursor
            is_list = False
            for slot in self._intent_list[match_intent].slots:
                if slot.name == target_slot:
                    is_list = slot.is_list
                    break
            context.glob[target_slot] = self._search_slot_value(match_intent, target_slot, context, pre_process_result,
                                                                text, is_list)
        # 일반 case
        else:

            cursor, next_list, next_cond_result_list = self._get_next_list(context, cursor, path, text)
            match_node, match_intent = self._check_intent(context, cursor, text, pre_process_result, next_list, next_cond_result_list)

            # function 중, intent 점수로 환산해서 넘겨주는 것들이 있는지 체크


        # 매칭된 intent가 없는 경우
        if not match_intent:
            if cursor == 'root':
                raise Exception("커서 위치가 root에서도 현재 발화와 매칭되는 노드가 없다.")
            else:
                context.system['cursor'] = 'root'
                context.system.pop('next_list', None)
            return self.run(context, pre_process_result, text)

        # 현재 intent에 할당된 slot을 모두 만족하는지 체크하고 만족하지 못하는 경우 slot filling 단계로 넘어간다
        intent = self._intent_list[match_intent]
        for slot in intent.slots:
            if slot.default is not None:
                continue
            is_none = slot.name not in context.glob
            is_list_none = slot.name in context.glob and context.glob[slot.name] == [] and slot.is_list is True
            if is_none or is_list_none:
                context.system['slot'] = slot.name
                path.append(match_node)
                self._update_context(context, match_node, path, slot.prompts, text)
                return [{"text": slot.prompts}]

        # slot filling 완료되서 slot 변수를 삭제함
        context.system.pop('slot', None)

        # 매칭된 노드의 챗봇 발화를 조립한다. jump 섹션이 존재하는 경우 재귀적으로 탐색해서 발화를 조립한다.
        cursor, responses = self._make_response(context, match_node, text, [{"text": ""}], path)
        lastoutput = "\n\n".join([resp['text'] for resp in responses])

        # context에 히스토리 및 다음 노드 리스트 갱신
        self._update_context(context, cursor, path, lastoutput, text)
        return responses

    def _update_context(self, context, cursor, path, lastoutput, text):
        # path 는 뒤집힌 스택 개념으로 0번째 index가 가장 마지막 커서
        path = [x[0] for x in itertools.groupby(path)][::-1]
        # 다음 커서
        context.system['cursor'] = cursor
        # 이전 노드 모든 발화
        context.system['lastoutput'] = lastoutput
        # 현재 cusor 이동 경로
        context.system['path'] = path
        # context 전체 이동경로 갱신
        history = context.system.get('history', [])
        history = path + history
        if len(history) > MAX_HISTORY_SIZE:
            context.system['history'] = history[:MAX_HISTORY_SIZE]
        else:
            context.system['history'] = history
        # next list 갱신
        self._set_next_list(context, context.system['cursor'], text)

    def _set_next_list(self, context, cursor, text):
        next_list = []
        if self._scenario[cursor].next:
            for next_section in self._scenario[cursor].next:
                if self._check_condition(context, next_section.cond, text):
                    next_list.append(next_section.node)
        context.system['next_list'] = next_list

    def _get_next_list(self, context, cursor, path, text):
        next_list = [next_node for next_node in context.system.get('next_list', []) if next_node in self._scenario]
        if not next_list:
            cursor = 'root'
            path.append('root')
            self._set_next_list(context, cursor, text)
            next_list = context.system.get('next_list')

        refined_next_list = []
        refined_cond_result_list = []
        for next_node_name in next_list:
            next_node = self._scenario[next_node_name]
            result = self._check_condition(context, next_node.cond, text)
            if result:
                refined_next_list.append(next_node_name)
                refined_cond_result_list.append(result)
        return cursor, refined_next_list, refined_cond_result_list

    def _make_response(self, context, match_node, text, responses, path):
        path.append(match_node)

        for e in self._scenario[match_node].chatbot:
            if issubclass(e.__class__, Helper):
                e.run(self._assemble_utterance, context, responses, text)
            else:
                self._assemble_utterance(context, responses, e, text)

        for jump in self._scenario[match_node].jump:
            if self._check_condition(context, jump.cond, text):
                return self._make_response(context, jump.node, text, responses, path)

        return match_node, responses

    def _get_slot_entity_type(self, intent_name, slot_name):
        intent = self._intent_list[intent_name]
        for slot in intent.slots:
            if slot.name == slot_name:
                return slot.entity
        raise Exception("이전 발화에서 선택된 slot과 매칭되는 slot이 사라짐")

    def _get_represent_word(self, text):
        wsr_text = number_normalize(white_space_remove(text))
        normalize_num = '0'
        re_num = '(\d+)'
        format_num = '{}'

        if wsr_text in self._synonym_list:
            if normalize_num in wsr_text and normalize_num in self._synonym_list[wsr_text]:
                normalized_text = number_normalize(text)
                pattern = normalized_text.replace(normalize_num, re_num)
                groups = re.search(pattern, text).groups()
                replace_text = self._synonym_list[wsr_text].replace(normalize_num, format_num)
                result = replace_text.format(*groups)
                return result
            else:
                return self._synonym_list[wsr_text]
        else:
            return text

    def _search_slot_value(self, intent_name, slot_name, context, pre_process_result, text, is_list):
        ner_result = self._gazetteer_searcher.prefix_search(text, longest=True)
        entity = self._get_slot_entity_type(intent_name, slot_name)
        results = []
        for ne in reversed(ner_result):
            if ne['EntityType'] == entity:
                results.append(self._get_represent_word(text[ne['StartToken']:ne['EndToken']]))

        if len(results) > 0 and is_list is False:
            return results[-1]
        elif len(results) > 0 and is_list is True:
            return results

        return first_element(pre_process_result)

    def _check_intent(self, context, cursor, text, pre_process_result, next_list, next_cond_list):
        # by classification
        intent_node_list = OrderedDict()
        for next_node_name in next_list:
            next_node = self._scenario[next_node_name]
            for intent_name in next_node.user:
                if intent_name in intent_node_list:
                    self.__log.warn(
                        "\"{}\" 노드와 연결된 \"{}\" 노드 와 \"{}\"가  \"{}\" intent를 중복해서 사용하고 있습니다."
                            .format(cursor, next_node_name, intent_node_list[intent_name], intent_name))
                else:
                    intent_node_list[intent_name] = next_node_name

        intent_result = self._intent_classification.run(text, intent_node_list.keys())

        # function 에서 intent 분류한 경우,
        # function score 가 intent score 보다 큰 경우, 출력해주도록 함
        # 단, 매치되는 regex 값이 있는 경우 이를 먼저 출력해주도록 함.
        function_classify_score = 0.0
        function_node_name = ''
        function_intent = 'any'
        for node, cond_result in zip(next_list, next_cond_list):
            if isinstance(cond_result, float):
                if cond_result > function_classify_score:
                    function_classify_score = cond_result
                    function_node_name = node
        if function_node_name:
            match_node, match_intent = self._check_intent_regex(context, [function_node_name], intent_node_list,
                                                                pre_process_result)
            if match_intent and match_node:
                return match_node, match_intent
            for intent_name in intent_result:
                score = intent_result[intent_name]
                if function_classify_score > score:
                    context.system['match_type'] = 'function_classification'
                    context.system['match_intent'] = 'any'
                    return function_node_name, function_intent
                else:
                    break

        if intent_result:
            match_node_list = set([intent_node_list[k] for k in intent_result.keys()])
            match_node, match_intent = self._check_intent_regex(context, match_node_list, intent_node_list,
                                                                pre_process_result)
            if match_intent and match_node:
                return match_node, match_intent

            match_intent = next(iter(intent_result))
            match_node = intent_node_list[match_intent]
            intent = self._intent_list[match_intent]
            if intent.slots:
                ner_result = self._ner_classification.run(match_intent, text)
            else:
                ner_result = []

            context.system['match_type'] = 'classification'
            context.system['match_intent'] = match_intent
            self._context_reusable_value_modification(context, intent)
            for slot in intent.slots:
                if slot.is_list:
                    if slot.name not in context.glob:
                        context.glob[slot.name] = []
                    elif isinstance(context.glob[slot.name], str) is True:
                        # context true, prev value 있을 때
                        temp_value = context.glob[slot.name]
                        context.glob[slot.name] = [temp_value]
                    elif not isinstance(context.glob[slot.name], list):
                        # context true, prev value 있을 때, 사용자가 임의로 setting 했을 때,
                        raise Exception("컨텍스트에 있는 {}({}) 값이 list 혹은 str이 아닙니다.".format(slot.name, context.glob[
                            slot.name].__class__.__name__))

                    for ne in reversed(ner_result):
                        if ne.slot == slot.name:
                            context.glob[slot.name].append(self._get_represent_word(ne.value))
                    pass
                else:
                    for ne in reversed(ner_result):
                        if ne.slot == slot.name:
                            context.glob[slot.name] = self._get_represent_word(ne.value)
                            break

            self._fill_default_slot_value(context, intent)
            return match_node, match_intent

        else:
            return self._check_intent_regex(context, [], intent_node_list, pre_process_result)

    def _check_intent_regex(self, context, break_node_list, intent_node_list, pre_process_result):
        for intent_name, next_node_name in intent_node_list.items():
            if next_node_name in break_node_list:
                return None, None
            intent = self._intent_list[intent_name]
            if not intent.regex:
                continue
            for t in pre_process_result.values():
                for r in intent.regex:
                    match_result = r.text.match(t)
                    if not bool(match_result):
                        continue

                    match_intent = intent_name
                    match_node = next_node_name

                    context.system['match_type'] = r.text.pattern
                    context.system['match_intent'] = match_intent

                    self._context_reusable_value_modification(context, intent)

                    for slot_name, value in zip(r.values, match_result.groups()):
                        context.glob[slot_name] = value

                    self._fill_default_slot_value(context, intent)
                    return match_node, match_intent
        return None, None

    @staticmethod
    def _fill_default_slot_value(context, intent):
        for slot in intent.slots:
            if slot.name not in context.glob and slot.default:
                if slot.is_list is True:
                    context.glob[slot.name] = [slot.default]
                else:
                    context.glob[slot.name] = slot.default

    @staticmethod
    def _context_reusable_value_modification(context, intent):
        for slot in intent.slots:
            if not slot.context:
                context.glob.pop(slot.name, None)

    def _assemble_utterance(self, context, responses, element, text):
        if isinstance(element, list):
            selected = random.choice(element)
        else:
            selected = element
        if selected.__class__.__name__ == "Separator":
            responses.append({"text": ""})
            return
        elif selected.__class__.__name__ == "Payload":
            func_result = selected.run(context, text)

            # text의 "payload" 값은 출력되길 기대하는 값이 아님
            if func_result:
                responses.append({"text": "payload", "payload": func_result})
            responses.append({"text": ""})
            return

        space = " " if responses[-1]['text'] else ""
        if isinstance(selected, str):
            responses[-1]['text'] += space + VariableReplacer().run(context, selected)
        else:
            func_result = selected.run(context, text)
            if isinstance(func_result, str):
                responses[-1]['text'] += space + func_result
            elif isinstance(func_result, dict) or isinstance(func_result, list):
                if isinstance(func_result, dict):
                    func_result = [func_result]
                for idx, result in enumerate(func_result):
                    responses[-1]['text'] += space + result['text'] if 'text' in result else ""
                    result.pop('text', None)

                    for key, value in result.items():
                        # ui로 정의된 태그들은 배열형태로 여러개 정의 가능
                        if key in ['button', 'image']:
                            if not isinstance(value, list):
                                value = [value]
                            if key in responses[-1]:
                                responses[-1][key].extend(value)
                            else:
                                responses[-1][key] = value
                        elif key in ['tts_string']:
                            if key in responses[-1]:
                                responses[-1][key] += (" " + value)
                            else:
                                responses[-1][key] = value
                        else:
                            if key in responses[-1]:
                                self.__log.warn("response 항목에 이미 \"{}\" 필드를 가지고 있습니다.".format(key))
                            responses[-1][key] = value
                    if idx != len(func_result) - 1:
                        responses.append({"text": ""})
            else:
                raise Exception("함수 반환 객체가 처리할수 없는 타입입니다. -> {}".format(type(func_result)))

    @staticmethod
    def _check_condition(context, cond, text):
        if cond is None:
            return True
        if not isinstance(cond, list):
            cond = [cond]

        cond_score = 0.0
        for c in cond:
            cond_result = ConditionChecker().run(context, c, text)
            if not cond_result:
                return False
            if isinstance(cond_result, float) and cond_result > cond_score:
                cond_score = cond_result

        if cond_score == 0.0:
            return True
        else:
            return cond_score
