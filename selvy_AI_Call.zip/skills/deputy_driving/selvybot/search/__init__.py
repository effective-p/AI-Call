# -*- coding: utf-8-*-
from abc import ABCMeta, abstractmethod

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


class Search(metaclass=ABCMeta):
    """
    시나리오 탐색 모듈
    """

    @abstractmethod
    def run(self, context, pre_process_result, text):
        """
        context의 정보를 바탕으로 시나리오에서 다음 노드를 찾고
        해당 노드의 챗봇 발화를 반환한다.
        Args:
            context (Context):  context 객체.
            pre_process_result (list of str): 전처리 결과.
            text (str): 유저 발화.

        Returns:
            str, 챗봇 발화

        """
        pass