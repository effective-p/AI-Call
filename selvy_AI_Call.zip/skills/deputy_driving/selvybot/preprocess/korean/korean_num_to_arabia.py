# -*- coding: utf-8-*-
import math
import re

from svlog import logged

from selvybot.preprocess import PreProcess

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/07/05"


@logged
class KoreanNumToArabia(PreProcess):
    NATIVE_ORDINAL_MAP = {
        "한": "일", "두": "이", "세": "삼", "네": "사",
        "다섯": "오", "여섯": "육", "일곱": "칠", "여덟": "팔",
        "아홉": "구", "열": "십",
        "스무": "이십", "스물": "이십", "서른": "삼십", "마흔": "사십",
        "쉰": "오십", "예순": "육십", "일흔": "칠십", "여든": "팔십", "아흔": "구십"
    }
    """__init__(self)

    한글 숫자를 아라비아 숫자로 변환하는 모듈

    .. warning::
       없음

    Args:

    .. seealso::
        없음

    """

    def __init__(self, *args):
        self._number = ['영', '일', '이', '삼', '사', '오', '육', '칠', '팔', '구']
        self._unit = ['십', '백', '천', '만', '억', '조']
        self._unit_num = [10, 100, 1000, 10000, math.pow(10, 8), math.pow(10, 12)]

        self._regex_dic = {
            "kor_num_building_regex": re.compile(r"((?:[일이삼사오육칠팔구십백천]+))\s?(?=단지|차)"),
            "kor_num_year_regex": re.compile(r"((?:[일이삼사오육칠팔구십백천]+))\s?(?=년)"),
            "kor_num_month_regex": re.compile(r"((?:[일이삼사오유육칠팔구십시])+)\s?(?=월)"),
            "kor_num_hour_regex": re.compile(r"(((열)*\s?(한|두|세|네|다섯|여섯|일곱|여덟|아홉|열))|(?:[일이삼사오육칠팔구십])+)\s?(?=시)"),
            "kor_num_minute_regex": re.compile(r"((?:[일이삼사오육칠팔구십])+)\s?(?=분)"),
            "kor_num_age_regex": re.compile(
                r"(((열|스무|스물|서른|마흔|쉰|예순|일흔|여든|아흔|백)*\s?(한|두|세|네|다섯|여섯|일곱|여덟|아홉|열|스무|스물|서른|마흔|쉰|예순|일흔|여든|아흔|백))|(?:[일이삼사오육칠팔구십])+)\s?(?=살)")
        }

        self._regex_dic['kor_num_day_regex'] = self._make_regex_pattern(type='day', units=args[0])
        if args[0]:
            self._regex_dic['kor_num_unit_regex'] = self._make_regex_pattern(type='unit', units=args[0])

    def _make_regex_pattern(self, type, units):
        result = ""
        unit_len = len(units)
        if unit_len > 0:
            i = 0
            for unit in units:
                if i == 0:
                    result += unit
                else:
                    result = result + "|" + unit
                i += 1

        if type == 'day':
            base_regex = r"((?:(?:[이삼사오육칠팔구십])+(?:일(?=일))?)|일)"
            unit_regex_prefix = "(?=\s?일(?!\s?(?:"
            unit_regex_postfix = ")))"
            default_unit_regex = "|년|월|시|분"
            unit_total_regex = unit_regex_prefix + result + default_unit_regex + unit_regex_postfix
        elif type == 'unit':
            base_regex = r"((?:[일이삼사오육칠팔구십백천만억조])+)"
            unit_regex_prefix = "(?=\s?(?:"
            unit_regex_postfix = "))"
            unit_total_regex = unit_regex_prefix + result + unit_regex_postfix

        return re.compile(base_regex + unit_total_regex)

    def _convert_native_ordinal_num(self, ordinal):
        groups = ordinal.groups()
        converted_text = []
        result = ''
        for group in reversed(groups):
            is_intersect = False
            if group is None:
                continue
            for text in converted_text:
                if text in group:
                    is_intersect = True
                    break
            if is_intersect == False and group in self.NATIVE_ORDINAL_MAP:
                result = self.NATIVE_ORDINAL_MAP[group] + result
                converted_text.append(group)

        if result == '':
            result = groups[0]
        return result

    def _convert_hangul(self, kor_num):
        result = 0
        num = 0
        temp = 0
        tokens = self._convert_native_ordinal_num(kor_num)
        for token in tokens:
            if token == '시':
                token = '십'
            if token == '유':
                token = '육'

            if token in self._number:
                num = self._number.index(token)
            else:
                if token not in ['만', '억', '조']:
                    temp += (num if num != 0 else 1) * self._unit_num[self._unit.index(token)]
                else:
                    temp += num
                    result += (temp if temp != 0 else 1) * self._unit_num[self._unit.index(token)]
                    temp = 0
                num = 0

        return str(result + temp + num)

    def run(self, context, text):
        """
            문장의 한글 숫자를 아라비아 숫자로 변환한다.
            Args:
                context (Context):  context 객체.
                text (str): 챗봇 발화.

            Returns:
                result_text (str): 정제된 챗봇 발화
        """
        result_text = text
        for key, regex_pattern in self._regex_dic.items():
            result_text = re.sub(regex_pattern, self._convert_hangul, result_text)
        return result_text
