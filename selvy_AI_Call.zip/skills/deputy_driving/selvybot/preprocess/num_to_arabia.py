# -*- coding: utf-8-*-
from svlog import getLogger

from selvybot.util import SingletonFactory
from selvybot.preprocess import PreProcess
from selvybot.preprocess.korean.korean_num_to_arabia import KoreanNumToArabia

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/07/05"


class DummyNumToArabia(PreProcess):
    def run(self, context, text):
        return text


class NumToArabia(metaclass=SingletonFactory):
    @staticmethod
    def factory(language, *args, **kwargs):
        if language == "korean":
            return KoreanNumToArabia(*args, **kwargs)
        else:
            getLogger().warn("{}, 해당언어를 지원하지 않습니다.")
            return DummyNumToArabia()