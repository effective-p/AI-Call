# -*- coding: utf-8-*-
from svlog import getLogger

from selvybot.preprocess import PreProcess
from selvybot.preprocess.korean.korean_segmentation import KoreanSegmentation
from selvybot.util import SingletonFactory

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/10"


class DummySegmentation(PreProcess):
    def run(self, context, text):
        return text


class Segmentation(metaclass=SingletonFactory):
    @staticmethod
    def factory(language, *args, **kwargs):
        if language == "korean":
            return KoreanSegmentation(*args, **kwargs)
        else:
            getLogger().warn("{}, 해당언어를 지원하지 않습니다.")
            return DummySegmentation()
