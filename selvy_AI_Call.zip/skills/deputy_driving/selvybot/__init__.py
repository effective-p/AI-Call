# -*- coding: utf-8-*-

from selvybot.app import App

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"

App = App
