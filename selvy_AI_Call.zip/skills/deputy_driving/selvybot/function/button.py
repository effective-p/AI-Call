# -*- coding: utf-8-*-
from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "Alan Kwanhong Lee"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "alan.k.lee@selvas.com"
__date__ = "2018/07/09"


class Button(Function):
    """
    메신저 플랫폼의 버튼 출력을 위한 발화 래핑 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::button(example_text)> # 버튼으로 출력할 텍스트를 인자로 넘겨줌

    """

    def build(self, label, url=None):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            label (str): 레이블
            url (str): http 주소

        Returns:
            bool, 빌드 성공/실패 여부

        """
        dynamic_label = VariableReplacer().dynamic(label)
        if url:
            dynamic_url = VariableReplacer().dynamic(url)
            self._core = lambda context: {"button": {"label": dynamic_label(context), 'url': dynamic_url(context)}}
        else:
            self._core = lambda context: {"button": {"label": dynamic_label(context)}}
        return True

    def run(self, context, text):
        """
        메신저의 버튼 출력 포맷으로 래핑한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 버튼 출력 래핑.

        """
        return self._core(context)
