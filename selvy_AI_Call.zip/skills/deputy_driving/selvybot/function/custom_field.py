# -*- coding: utf-8-*-
from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/16"


class CustomField(Function):
    """
    Rest API Response 에 추가할 필드를 정의하는 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::custom_field(key, value)>

    """

    def build(self, key, value):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            key (str): field 이름
            value (str): field 값

        Returns:
            bool, 빌드 성공/실패 여부

        """
        if VariableReplacer().check(value):
            def core(context):
                return {key: VariableReplacer().run(context, value)}

        else:
            output = {key: value}

            def core(context):
                return output
        self._core = core
        return True

    def run(self, context, text):
        """
        custom field 객체(dict)를 반환

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            dict, custom field 객체.

        """
        return self._core(context)
