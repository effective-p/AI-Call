# -*- coding: utf-8 -*-
import concurrent
import os
import random
from collections import OrderedDict, namedtuple

import numpy as np
import xlrd
from sklearn.metrics.pairwise import normalize
from sklearn.utils.extmath import safe_sparse_dot
from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.error.warn import ResourceNotFoundWarnings
from selvybot.feature.sentence_embedding import SentenceEmbedding
from selvybot.function import Function

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/07/06"

QaType = namedtuple("QaType", "utterances responses")

# TODO jskim 전역관리하지 않도록 추후 수정
QA_MODEL = {}


@logged
class Qa(Function):
    """__init__(self, param)

    질문/답변 셋에서 답변을 검색하는 함수

    .. warning::
       없음

    .. seealso::
        없음

     Example:
         yml 파일 내에서 cond 항목에 아래와 같이 사용

         etc:
            user:
              -.+
            cond:
              - <function::qa(~(originalinput), file_name.xlsx)>
            chatbot:
              - $$(qa_response)

    """

    def build(self, qa_file_name, utter, threshold=0.8, category_name='qa_category', utterance_name='qa_utterance', score_name='qa_score', response_name='qa_response'):
        file_path = os.path.join(self._resource_path.static_path, qa_file_name)
        if file_path not in QA_MODEL:
            qa_set = self.load(file_path)
            matrix, utterance_intent_list, utterance_list = self.load_matrix(qa_set)
            QA_MODEL[file_path] = (matrix, utterance_intent_list, utterance_list)
        matrix, utterance_category_list, utterance_list = QA_MODEL[file_path]
        dynamic_utter = VariableReplacer().dynamic(utter)
        normalized_matrix = normalize(np.asarray(matrix), copy=False).T

        def core(context):
            utter_vector = SentenceEmbedding().run([dynamic_utter(context)])[0]
            normalized_utter_vector = normalize(np.array(utter_vector).reshape(1, -1), copy=False)

            # cosine similarity
            score_matrix = safe_sparse_dot(normalized_utter_vector, normalized_matrix, dense_output=True)
            sorted_list = np.argsort(-score_matrix)[0]

            for idx in sorted_list:
                score = score_matrix[0][idx]
                if score < float(threshold):
                    break
                category = utterance_category_list[idx]
                if category in qa_set.keys():
                    matched = qa_set[category]
                    choiced_response = random.choice(matched.responses)
                    choiced_response = VariableReplacer().run(context, choiced_response)
                    context.local[response_name] = choiced_response
                    context.local[category_name] = category
                    context.local[utterance_name] = utterance_list[idx]
                    context.local[score_name] = score
                    return choiced_response
            return ""

        self._core = core

        return True

    @staticmethod
    def load(file_path):
        if not os.path.exists(file_path):
            ResourceNotFoundWarnings("QA 파일을 찾을 수 없습니다.", file_path)
        qa_set = OrderedDict()
        workbook = xlrd.open_workbook(file_path)
        for sheet_index in range(workbook.nsheets):
            worksheet = workbook.sheet_by_index(sheet_index)
            headers = [column.value for column in worksheet.row_slice(0, start_colx=0, end_colx=worksheet.ncols)]

            try:
                division_index = headers.index('구분')
                utter_index = headers.index('유저')
                response_index = headers.index('챗봇')
            except Exception as e:
                raise Exception("column 이름에 '구분', '유저', '챗봇' 이 없습니다.")

            category = ''
            for row in range(worksheet.nrows)[1:]:
                temp_category = worksheet.cell_value(row, division_index).strip()
                if temp_category:
                    category = temp_category
                if category != '' and category not in qa_set:
                    qa_set[category] = QaType([], [])

                utter = worksheet.cell_value(row, utter_index).strip()
                if utter:
                    qa_set[category].utterances.append(utter)
                response = worksheet.cell_value(row, response_index).strip()
                if response:
                    qa_set[category].responses.append(response)

        return qa_set

    @staticmethod
    def load_matrix(qa_set):
        sentence_embedding = SentenceEmbedding()
        utterance_category_list = []
        utterance_list = []
        for intent_name, intent in qa_set.items():
            for utterance in intent.utterances:
                utterance_list.append(utterance)
                utterance_category_list.append(intent_name)

        utterance_vector_list = sentence_embedding.run(utterance_list)
        return np.matrix(utterance_vector_list), utterance_category_list, utterance_list

    def run(self, context, text):
        """
        발화 문장을 생성하여 변수에 값을 할당한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 발화 문장

        """

        return self._core(context)
