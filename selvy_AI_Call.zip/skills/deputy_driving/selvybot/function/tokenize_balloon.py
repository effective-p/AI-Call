# -*- coding: utf-8-*-
import json

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/27"


# -*- coding: utf-8-*-


class TokenizeBalloon(Function):
    """
    입력 인자를 delimiter로 분리해서 말풍선을 나눠주는 함수

    .. warning::
       없음

    .. seealso::
        없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::tokenize_ballon(example_text, delimiter)>

    """

    def build(self, text, delimiter="\\n\\n"):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            line (str): 입력 텍스트
            delimiter (str): delimiter

        Returns:
            bool, 빌드 성공/실패 여부

        """
        self._dynamic_param = VariableReplacer().dynamic(text)
        self._delimiter = json.loads('"' + delimiter + '"')
        return True

    def run(self, context, text):
        """
        입력 인자를 delimiter로 분리해서 말풍선을 나눠주는 함수

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 분리된 텍스트

        """
        param = self._dynamic_param(context)
        tokens = param.split(self._delimiter)
        return tokens[0] if len(tokens) == 1 else [{'text': token} for token in tokens]
