# -*- coding: utf-8-*-
from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.error.resource import ResourceGetFailedError
from selvybot.function import Function
from selvybot.util.common import requests_retry_session

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


@logged
class Smalltalk(Function):
    """
    잡담, 일반대화 함수

    .. warning::
       없음

    .. seealso::
        없음

     Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::smalltalk(만나서 반가워)>

    """

    def build(self, message, threshold=0.8, category_name='st_category', utterance_name='st_utterance', score_name='st_score', response_name='st_response'):
        url = self._resource_path.components_url + "/smalltalk"
        dynamic_message = VariableReplacer().dynamic(message)

        def core(context):
            try:
                resp = requests_retry_session().post(url, json={"text": dynamic_message(context),
                                                                      "threshold": float(threshold)})
                if resp.status_code != 200 and resp:
                    raise ResourceGetFailedError("smalltalk", resp.text)
                res_data = resp.json()
                if res_data['result'] != "success":
                    raise Exception('smalltalk 매칭되는 문장이 없음')
                context.local[response_name] = res_data['response']
                context.local[category_name] = res_data['topic']
                context.local[utterance_name] = res_data['utter']
                context.local[score_name] = res_data['score']
                return res_data['response']

            except:
                return ""

        self._core = core

        return True

    def run(self, context, text):
        """
        발화 문장을 생성한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.
            param (Str): optional 인자

        Returns:
            str, 발화 문장.

        """

        return self._core(context)
