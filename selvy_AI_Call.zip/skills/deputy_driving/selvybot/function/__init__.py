# -*- coding: utf-8-*-
from abc import ABCMeta, abstractmethod

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/10"


class Function(metaclass=ABCMeta):
    """__init__(self, param)

    시나리오의 챗봇 발화에 사용할수 있는 함수 정의
    프레임워크 하단에 정의된 함수는 시스템 함수,
    시나리오 폴더에 사용자가 정의한 함수는 유저 함수로 구분됨

    .. warning::
       없음

    Args:
        file (Str): 파일 정보
        node (Str): 노드 정보
        section (Str): 섹션 정보
        statement (Str): 스크립트 정보
        resource_path (object): Resource Path 객체

    .. seealso::
        없음

    """

    def __init__(self, file, node, section, statement, resource_path):
        self._file = file
        self._node = node
        self._section = section
        self._statement = statement
        self._resource_path = resource_path

    def build(self, *args):
        """
        스크립트에서 입력된 인자로 빌드하는 단계


        Args:
            *args (list): 함수별로 필요한 인자를 각각 정의

        Returns:
            bool, 빌드 성공/실패 여부

        """
        assert len(args) == 0
        return True

    @abstractmethod
    def run(self, context, text):
        """
        발화 문장을 생성하거나 변수에 값을 할당할 목적으로 사용한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 발화 문장

        """
        pass


def load(dir_path_list):
    import glob
    import stringcase
    import os
    from importlib.machinery import SourceFileLoader
    function_list = {}
    for dir_path in dir_path_list:
        for path in glob.glob(os.path.join(dir_path, "*.py")):
            if os.path.basename(path) == "__init__.py": continue
            snakecase_module_name = os.path.splitext(os.path.basename(path))[0]
            camelcase_module_name = stringcase.capitalcase(stringcase.camelcase(snakecase_module_name))
            mod = SourceFileLoader(camelcase_module_name, path).load_module()
            func = getattr(mod, camelcase_module_name)
            assert issubclass(func, Function)
            assert snakecase_module_name not in function_list
            function_list[snakecase_module_name] = func
    return function_list
