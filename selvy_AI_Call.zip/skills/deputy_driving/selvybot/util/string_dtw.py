# -*- coding: utf-8-*-

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/10/17"


def get_match_result(src, dst):
    len_src = len(src)
    len_dst = len(dst)
    size_row = len_src + 1
    size_col = len_dst + 1

    src_result = []
    for _ in range(len_src):
        src_result.append([False, -1, ""])
    dst_result = []
    for _ in range(len_dst):
        dst_result.append([False, -1, ""])
    matrix = []
    for i in range(size_row):
        matrix.append([0] * size_col)

    for i in range(1, len_src):
        for j in range(1, len_dst):
            if src[i - 1] == dst[j - 1]:
                matrix[i][j] = matrix[i - 1][j - 1] + 1
            elif matrix[i - 1][j] > matrix[i][j - 1]:
                matrix[i][j] = matrix[i - 1][j]
            else:
                matrix[i][j] = matrix[i][j - 1]

    i = len_src
    j = len_dst

    while i > 0 and j > 0:
        if src[i - 1] == dst[j - 1]:
            i -= 1
            j -= 1
            src_result[i] = [True, j, src[i] + src_result[i][2]]
            dst_result[j] = [True, i, dst[j] + dst_result[j][2]]
        elif matrix[i][j - 1] > matrix[i - 1][j]:
            j -= 1
            dst_result[j][2] = dst[j] + dst_result[j][2]
        else:
            i -= 1
            src_result[i][2] = src[i] + src_result[i][2]

    return src_result, dst_result
