# -*- coding: utf-8 -*-
from collections import OrderedDict

import ruamel.yaml as yaml
from jsonschema import validate
from ruamel.yaml import CLoader
from yaml.constructor import ConstructorError
from ruamel.yaml.constructor import Constructor

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/04/12"


def _no_duplicates_constructor(loader, node, deep=False):
    """Check for duplicate keys."""

    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        value = loader.construct_object(value_node, deep=deep)
        if key in mapping:
            raise ConstructorError("while constructing a mapping", node.start_mark,
                                   "found duplicate  key (%s)" % key, key_node.start_mark)
        mapping[key] = value

    return loader.construct_mapping(node, deep)


yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _no_duplicates_constructor)

'''
def construct_mapping(loader, node):
    loader.flatten_mapping(node)
    return OrderedDict(loader.construct_pairs(node))


yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, construct_mapping)
'''

def _represent_ordereddict(dumper, data):
    value = []

    for item_key, item_value in data.items():
        node_key = dumper.represent_data(item_key)
        node_value = dumper.represent_data(item_value)

        value.append((node_key, node_value))

    return yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', value)


yaml.add_representer(OrderedDict, _represent_ordereddict)


def add_bool(self, node):
    if node.value in ['yes', 'Yes', 'no', 'No']:
        return self.construct_scalar(node)
    else:
        return self.construct_yaml_bool(node)


Constructor.add_constructor(u'tag:yaml.org,2002:bool', add_bool)


def load(path, schema):
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.load(f, Loader=CLoader)
        validate(data, schema)
        return data


def dump(data):
    class IncreaseDumper(yaml.Dumper):

        def increase_indent(self, flow=False, sequence=None, indentless=False):
            return super(IncreaseDumper, self).increase_indent(flow, sequence, False)

    return yaml.dump(data, Dumper=IncreaseDumper, allow_unicode=True, default_flow_style=False)
