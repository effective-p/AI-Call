# -*- coding: utf-8-*-
import argparse
import glob
import os
import sys

from Cython.Build.Cythonize import cython_compile, parse_args

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/17"


def cythonize(file_list):
    options, _ = parse_args(["", "-i", "test.py"])

    if options.lenient:
        # increase Python compatibility by ignoring compile time errors
        options.error_on_unknown_names = False
        options.error_on_uninitialized = False

    if options.annotate:
        options.annotate = True

    for file_name in file_list:
        c_file = os.path.splitext(file_name)[0] + ".c"
        cython_compile(file_name, options)
        os.remove(file_name)
        os.remove(c_file)


def extract_dir_path(path):
    parent_list = []
    while True:
        parent_list.append(path)
        parent = os.path.dirname(path)
        if not parent:
            break
        path = parent
    return parent_list


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--path', type=str, required=True)
    parser.add_argument('--remove_original_file', type=bool, default=True)
    parser.add_argument('--except_list', type=str, default='')
    conf = parser.parse_args()
    except_list = conf.except_list.split(",") if conf.except_list else []
    except_list = [os.path.normpath(e) for e in except_list]

    file_list = []
    for file_name in glob.iglob(conf.path + '/**/*.py', recursive=True):
        if os.path.basename(file_name) == '__init__.py':
            continue
        rel_path = os.path.normpath(os.path.relpath(file_name, conf.path))
        path_list = extract_dir_path(rel_path)
        is_except = False
        for element in except_list:
            if element in path_list:
                is_except = True
                break
        if is_except:
            continue
        file_list.append(file_name)

    cythonize(file_list)


if __name__ == '__main__':
    main()
