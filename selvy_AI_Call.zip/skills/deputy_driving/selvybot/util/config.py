# -*- coding: utf-8-*-
import configparser
import copy
import os

from selvybot.util import str2bool, SystemPath

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/07/16"

_default_parser = configparser.ConfigParser(allow_no_value=True)
_default_parser.read(os.path.join(SystemPath().resource_path, 'default.ini'))
DEFAULT = {s: dict(_default_parser[s].items()) for s in _default_parser.sections()}


def load(path):
    parser = configparser.ConfigParser(allow_no_value=True)
    if not os.path.exists(path):
        raise Exception('파일이 없습니다. : {}'.format(path))
    path = os.path.abspath(path)
    parser.read(path, encoding='utf-8')
    raw_config = {}
    for section in parser.sections():
        if section in ['db']:
            raw_config[section] = dict(parser[section].items())
            continue
        if section not in DEFAULT:
            raise Exception('정의되지 않은 section입니다. : {}'.format(section))

        raw_config[section] = DEFAULT[section]
        for k, v in parser[section].items():
            if k not in DEFAULT[section]:
                raise Exception('정의되지 않은 key입니다. : {}'.format(k))
            if k in ['force_rebuild', 'debug', 'threaded', 'ignore_time']:
                v = str2bool(v)
            if k in ['session_maintain_time']:
                v = int(v)
            raw_config[section][k] = v

        # 환경변수에 값이 있다면 우선적으로 적용
        for k, v in DEFAULT[section].items():
            env_key = "SELVY_CHATBOT_" + k.upper()
            if env_key in os.environ:
                raw_config[section][k] = os.environ[env_key]

    if 'db' not in raw_config:
        raise Exception('db section이 누락되었습니다.')

    if not os.path.exists(raw_config['common']['resource_root']):
        if os.path.exists("." + raw_config['common']['resource_root']):
            raw_config['common']['resource_root'] = "." + raw_config['common']['resource_root']

    config = copy.deepcopy(raw_config)
    for section, sub in raw_config.items():
        for k, v in sub.items():
            if v is None:
                config[section].pop(k, None)

    return config
