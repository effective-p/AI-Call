# -*- coding: utf-8-*-
import glob
import os
from distutils.core import setup
from distutils.extension import Extension

from Cython.Distutils import build_ext

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/08/02"

except_list = ["function", "util/common.py", "variable.py", "compile.py", "wsgi.py", "type/intent.py"]
except_list = [os.path.normpath(e) for e in except_list]

target_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
file_list = []


def extract_dir_path(path):
    parent_list = []
    while True:
        parent_list.append(path)
        parent = os.path.dirname(path)
        if not parent:
            break
        path = parent
    return parent_list


ext_modules = []
remove_list = []

for file_name in glob.iglob(target_path + '/**/*.py', recursive=True):
    file_name = os.path.normpath(file_name)
    if os.path.basename(file_name) == '__init__.py':
        continue
    rel_path = os.path.normpath(os.path.relpath(file_name, target_path))
    path_list = extract_dir_path(rel_path)
    is_except = False
    for element in except_list:
        if element in path_list:
            is_except = True
            break
    if is_except:
        continue
    module_name = rel_path.split('.')[0].replace("\\", ".").replace("/", ".")
    c_file = os.path.splitext(file_name)[0] + ".c"
    remove_list.append(c_file)
    remove_list.append(file_name)
    ext_modules.append(Extension(module_name, [file_name]))

setup(
    name='Selvy Chatbot',
    cmdclass={'build_ext': build_ext},
    ext_modules=ext_modules
)

for path in remove_list:
    os.remove(path)