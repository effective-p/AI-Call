# -*- coding: utf-8-*-
import re

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/02"

PATTERN_STR_VAR = r'(~|\${1,2})\((\${0,1}[a-zA-Z\d\s가-힣\-_\.]+)\)'
PATTERN_STR_VAR_LOC = r'(~|\${1,2})'
PATTERN_STR_VAR_NAME = r'\(([a-zA-Z\d\s가-힣\-_\.]+)\)'
PATTERN_VAR = re.compile('^' + PATTERN_STR_VAR + '$')
PATTERN_VAR_LOC = re.compile('^' + PATTERN_STR_VAR_LOC + '$')
PATTERN_VAR_NAME = re.compile('^' + PATTERN_STR_VAR_NAME + '$')

PATTERN_STR_FUNCTION = r'<function::([^>()]+)(?:(?:\(\))|(?:\(([\s\S]+)\)))?>'
PATTERN_FUNCTION = re.compile('^' + PATTERN_STR_FUNCTION + '$')

MAX_HISTORY_SIZE = 20