# -*- coding: utf-8-*-
from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function
from selvybot.schema.type import PATTERN_VAR

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/05/02"


@logged
class Assign(Function):
    """
    변수를 할당하기 위한 함수

    .. warning::
       없음

    Example:
        yml 파일 내에서 chatbot 발화 부분에서 아래와 같이 사용

        etc:
          user:
            - .*
          chatbot:
            - <function::assign($(to),$$(1))> # $(to) 에 $$(1) 값을 할당
            - <function::assign($(출발지),서울)>
    """

    def build(self, target, source):
        """
        스크립트에서 입력된 인자로 빌드하는 단계

        Args:
            target (str): 저장할 변수명
            source (str): 내용

        Returns:
            bool, 빌드 성공/실패 여부

        """
        match_result = PATTERN_VAR.match(target)
        if not bool(match_result):
            raise SyntaxError('assign 함수의 첫번째 인자는 variable 형태를 취해야 합니다.')
        loc, var_name = match_result.groups()
        if loc == '~':
            self.__log.warn('system \"{}\"변수를 수정하고 있습니다.'.format(var_name))

        if VariableReplacer().check(source):
            def assign_variable(context):
                if loc == '$$':
                    storage = context.local
                elif loc == '$':
                    storage = context.glob
                else:
                    storage = context.system
                storage[var_name] = VariableReplacer().run(context, source)
        else:
            def assign_variable(context):
                if loc == '$$':
                    storage = context.local
                elif loc == '$':
                    storage = context.glob
                else:
                    storage = context.system
                storage[var_name] = source

        self._core = assign_variable
        return True

    def run(self, context, text):
        """
        변수를 할당한다.

        Args:
            context (Context):  context 객체.
            text (str): 전처리된 사용자 발화.

        Returns:
            str, 발화 문장.

        """
        self._core(context)
        return ""
