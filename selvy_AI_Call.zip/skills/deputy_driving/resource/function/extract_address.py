# -*- coding: utf-8-*-
import json
import re

from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function

__author__ = "Andrew Jeonguk Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/09/18"

AREA_PATTERN = re.compile(r"(^.+[시군구])\s")
BUNJI_PATTERN = re.compile(r"\d+\s*(-\s*\d+)?(\s*번지)?")
DONG_PATTERN = re.compile(r"(^.*[동리]\s)")


@logged
class ExtractAddress(Function):
    def build(self, source):
        def extract(context):
            try:
                address = VariableReplacer().run(context, source)
                address = json.loads(address.replace("\'", "\""))
                for key, value in address.items():
                    context.glob["starting_point_{}".format(key)] = value

                if "jibun_address_name" in address.keys():
                    jibun_address_name = address["jibun_address_name"]
                    #TODO(ANDREW) 동과 POI를 붙여서 지번주소로 보내는 경우에 대한 처리를 위해 작성
                    if ("starting_point_poi" not in context.glob.keys()) and (BUNJI_PATTERN.search(jibun_address_name) is None):
                        match_result = DONG_PATTERN.match(jibun_address_name)
                        if match_result:
                            poi = jibun_address_name[len(match_result.group(1)):]
                            context.glob["starting_point_poi"] = poi
                            address["poi"] = poi

                    match_result = AREA_PATTERN.match(jibun_address_name)
                    if match_result:
                        area = match_result.group(1)
                        if "poi" in address.keys():
                            area += ", "
                            area += address["poi"]
                        context.glob["starting_point"] = area

            except Exception as e:
                return None

        self._core = extract
        return True

    def run(self, context, text):
        self._core(context)
        return ""
