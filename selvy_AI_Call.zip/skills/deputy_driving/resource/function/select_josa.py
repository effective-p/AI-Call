# -*- coding: utf-8-*-
from svlog import logged

from selvybot.core.variable_replacer import VariableReplacer
from selvybot.function import Function
from selvybot.schema.type import PATTERN_VAR


@logged
class SelectJosa(Function):

    def run(self, context, text):
        last = context.glob["destination_address"][-1]
        syllable = (ord(last) - 44032) % 28
        if syllable == 0 or syllable == 8:
            context.local["josa"] = "로"
        else:
            context.local["josa"] = "으로"
        return ""