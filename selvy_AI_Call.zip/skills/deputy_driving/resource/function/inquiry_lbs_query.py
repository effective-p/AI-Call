# -*- coding: utf-8-*-
import certifi
import json
import os
import urllib3

from svlog import logged

from selvybot.function import Function

__author__ = "Zoey Jeonga Han"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "zoey.j.han@selvas.com"
__date__ = "2020/12/16"

SEJONG_PROTOCOL = os.environ.get("SEJONG_PROTOCOL", "http")
SEJONG_HOST = os.environ.get("SEJONG_HOST", "202.30.249.19")
SEJONG_PORT = os.environ.get("SEJONG_PORT", "7001")

URL = "{}://{}:{}/inquiry/lbsQuery".format(SEJONG_PROTOCOL, SEJONG_HOST, SEJONG_PORT)
HEADER = {"Content-Type": "application/json"}


@logged
class InquiryLbsQuery(Function):
    def build(self):
        return True

    @staticmethod
    def __make_query(user,caller):
        query = dict()
        query["ftkey"] = user
        query["telnum"] = caller
        return json.dumps(query)

    def run(self, context, text):
        # 사내 전화 데모사이트에서도 동작하도록 설정
        user, caller = None, None
        if "DemoIvrDriver_" in context.system["user"]:
            user = "Gl8oBqyKgEaJIqry6657Q3/I8X2P3lcqTUzXfQb6BdujwCsPB81HPoB64X05Q+JC3IfBS3hIkmcIbUK8QPLK2A=="
            caller = "01091518542"
        else:
            user = context.glob["transaction_id"]
            caller = context.system["user"]

        # # TODO(ZOEY) 디버깅을 위한 코드로 릴리즈시 삭제
        # user = "Gl8oBqyKgEaJIqry6657Q3/I8X2P3lcqTUzXfQb6BdujwCsPB81HPoB64X05Q+JC3IfBS3hIkmcIbUK8QPLK2A=="
        # caller = "01091518542"

        query = InquiryLbsQuery.__make_query(user,caller)
        response = None
        pool_manager = urllib3.PoolManager(cert_reqs="CERT_NONE", ca_certs=certifi.where())
        try:
            response = pool_manager.request("POST", URL, body=query, headers=HEADER)
        except Exception as e:
            return "False"

        if response.status != 200:
            return "False"

        result = json.loads(response.data.decode("utf-8"))
        try:
            if int(result["resultCode"]) != 200:
                return "False"
        except Exception as e:
            return "False"

        return "True"