from selvybot.function import Function

class AssignFailCount(Function):
    def run(self, context, text):
        fail_count = str(int(context.glob.get('fail_count', '')) + 1)
        context.glob['fail_count'] = fail_count
        return ''