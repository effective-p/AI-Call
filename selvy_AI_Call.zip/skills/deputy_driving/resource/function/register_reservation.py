# -*- coding: utf-8-*-
import certifi
import json
import os
import urllib3

from svlog import logged

from selvybot.function import Function

__author__ = "Andrew Jeonguk Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/09/21"


SEJONG_PROTOCOL = os.environ.get("SEJONG_PROTOCOL", "http")
SEJONG_HOST = os.environ.get("SEJONG_HOST", "202.30.249.19")
SEJONG_PORT = os.environ.get("SEJONG_PORT", "7001")

URL = "{}://{}:{}/register/reservation".format(SEJONG_PROTOCOL, SEJONG_HOST, SEJONG_PORT)
HEADER = {"Content-Type": "application/json"}


@logged
class RegisterReservation(Function):
    def build(self, payment):
        if payment not in ["card", "cash", "법인"]:
            return False
        self._payment = payment
        return True

    @staticmethod
    def __make_address(jibun, road, place, poi, x, y):
        address = dict()
        address["jibun_address_name"] = jibun
        for key, value in [("road_address_name", road), ("place_name", place), ("poi", poi), ("x", x), ("y", y)]:
            if (value is None) or (value.strip() == ""):
                continue
            address[key] = value

        return address

    @staticmethod
    def __make_query(user, payment, price, staring, destination):
        query = dict()
        query["ftKey"] = user
        query["payment"] = payment
        query["price"] = int(price)
        if staring is None:
            query["startingPoint"] = {"jibun_address_name": ''}
        else:
            query["startingPoint"] = staring
        query["destination"] = destination
        return json.dumps(query).encode("utf-8")

    @staticmethod
    def __exist(context, key):
        if key not in context.glob.keys():
            return False
        if context.glob[key].strip() == "":
            return False
        return True

    def run(self, context, text):
        if context.glob['lbs'] == 'True':
            for key in ["destination_jibun_address_name"]:
                if not RegisterReservation.__exist(context, key):
                    return "False"
        else:
            for key in ["starting_point_jibun_address_name", "destination_jibun_address_name"]:
                if not RegisterReservation.__exist(context, key):
                    return "False"

        user = None
        if "DemoIvrDriver_" in context.system["user"]:
            user = "Gl8oBqyKgEaJIqry6657Q3/I8X2P3lcqTUzXfQb6BdujwCsPB81HPoB64X05Q+JC3IfBS3hIkmcIbUK8QPLK2A=="
        else:
            user = context.glob["transaction_id"]

        # # TODO(ANDREW) 디버깅을 위한 코드로 릴리즈시 삭제
        # user = "Gl8oBqyKgEaJIqry6657Q3/I8X2P3lcqTUzXfQb6BdujwCsPB81HPoB64X05Q+JC3IfBS3hIkmcIbUK8QPLK2A=="

        response = None
        try:
            # starting
            if context.glob['lbs'] == 'False':
                jibun = context.glob["starting_point_jibun_address_name"]
                poi = context.glob["starting_point_poi"] if "starting_point_poi" in context.glob.keys() else None
                x = context.glob["starting_point_x"] if self._payment != "법인" else ""
                y = context.glob["starting_point_y"] if self._payment != "법인" else ""
                staring = RegisterReservation.__make_address(jibun, None, None, poi, x, y)
            # destination
            jibun = context.glob["destination_jibun_address_name"]
            poi = context.glob["destination_poi"] if "destination_poi" in context.glob.keys() else None
            x = context.glob["destination_x"] if self._payment != "법인" else ""
            y = context.glob["destination_y"] if self._payment != "법인" else ""
            destination = RegisterReservation.__make_address(jibun, None, None, poi, x, y)

            pool_manager = urllib3.PoolManager(cert_reqs="CERT_NONE", ca_certs=certifi.where())

            price = context.glob["price"] if self._payment != "법인" else 0
            if context.glob['lbs'] == 'False':
                query = RegisterReservation.__make_query(user, self._payment, price, staring, destination)
            else:
                query = RegisterReservation.__make_query(user, self._payment, price, None, destination)
            response = pool_manager.request("POST", URL, body=query, headers=HEADER)
        except Exception as e:
            return "False"

        if response.status != 200:
            return "False"

        result = json.loads(response.data.decode("utf-8"))
        try:
            if int(result["resultCode"]) != 200:
                return "False"
        except Exception as e:
            return "False"

        return "True"
