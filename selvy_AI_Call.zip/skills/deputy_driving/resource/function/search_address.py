# -*- coding: utf-8-*-
import json
import os
import re
import requests

from svlog import logged

from selvybot.function import Function

__author__ = "Andrew Jeonguk Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/11/12"

SEARCH_KEYWORD_URL = "https://dapi.kakao.com/v2/local/search/keyword.json?query={}&y=37.56682420267543&x=126.978652258823"
#TODO(ANDREW) tylor.h.kwon 개인 API KEY이므로 추후 회사 계정 KEY로 변경 필요
KAKAO_AK = os.environ.get("KAKAO_AK", "a50f5dcd2e76822bdb11389ab83ae7df")
SEARCH_KEYWORD_HEADER = {
    "Authorization": "KakaoAK " + KAKAO_AK
}

AREA_PATTERN = re.compile("(^.+[시군구])\s")

ADDRESS_NER_URL = "http://neraddress.mllab.cc/recognition"
ADDRESS_NER_HEADER = {"Content-Type": "application/json"}

@logged
class SearchAddress(Function):
    def build(self):
        return True

    def run(self, context, text):
        original_input = context.system["originalinput"]

        address_ner_query = {}
        address_ner_query["text"] = original_input
        address_ner_query = json.dumps(address_ner_query)
        try:
            response = requests.post(ADDRESS_NER_URL, headers=ADDRESS_NER_HEADER, data=address_ner_query)
            original_input = response.json()["convert"]
            original_input = re.sub('(?<=\\d) (?=\\d)', '', original_input)
        except Exception as e:
            pass

        if SearchAddress.search_keyword(context, original_input):
            return "True"
        return "False"

    @staticmethod
    def search_keyword(context, original_input):
        try:
            response = requests.get(SEARCH_KEYWORD_URL.format(original_input), headers=SEARCH_KEYWORD_HEADER)
            if response.status_code is not 200:
                return False
            documents = json.loads(response.text)["documents"]
            if len(documents) == 0:
                return False

            context.local["finded_place_name"] = documents[0]["place_name"]

            if json.loads(response.text)["meta"]["same_name"]["keyword"] == '':
                context.local["finded_place_name_talk"] = json.loads(response.text)["meta"]["same_name"]["selected_region"].split()[-1]
            else:
                context.local["finded_place_name_talk"] = documents[0]["place_name"]
            jibun_address = documents[0]["address_name"]
            match_result = AREA_PATTERN.match(jibun_address)
            if match_result:
                context.local["finded_area"] = match_result.group(1)
                context.local["finded_area_talk"] = match_result.group(1)
            else:
                context.local["finded_area"] = jibun_address
                context.local["finded_area_talk"] = jibun_address

            if json.loads(response.text)["meta"]["same_name"]["keyword"] == '':
                context.local["finded_area_talk"] = ' '.join(json.loads(response.text)["meta"]["same_name"]["selected_region"].split()[:-1])
            context.local["finded_address"] = jibun_address

            context.local["finded_x"] = documents[0]["x"]
            context.local["finded_y"] = documents[0]["y"]
        except Exception as e:
            return False
        return True
