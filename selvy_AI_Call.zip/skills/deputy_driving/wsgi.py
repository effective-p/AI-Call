# -*- coding: utf-8-*-
from flask_restful import Api
from selvybot.app import create_bot_from_config
from selvybot.util import config
from selvybot.util import ResourcePath
import sys, os

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/06/09"

conf = config.load('/resource/config.ini')
resource_path = ResourcePath(conf['common']['components_url'], conf['common']['domain_url'],
                             conf['common']['resource_root']).root_path
resource_root = os.path.abspath(os.path.join(resource_path, os.pardir))
sys.path.insert(0, resource_root)

bot = create_bot_from_config('/resource/config.ini')

api = Api(bot.flask_app())

app = bot.flask_app()
app.template_folder = resource_path + '/templates'
