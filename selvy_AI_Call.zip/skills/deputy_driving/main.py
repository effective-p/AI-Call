# -*- coding: utf-8-*-
import argparse
from flask_restful import Api
from selvybot.app import create_bot_from_config
from selvybot.util import config
from selvybot.util import ResourcePath
import sys, os

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/06/09"

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--conf', type=str, default='resource/config.ini')
    parser.add_argument('--port', type=int, default=8089)
    param = parser.parse_args()

    conf = config.load(param.conf)
    resource_path = ResourcePath(conf['common']['components_url'], conf['common']['domain_url'],
                                 conf['common']['resource_root']).root_path
    resource_root = os.path.abspath(os.path.join(resource_path, os.pardir))
    sys.path.insert(0, resource_root)

    bot = create_bot_from_config(param.conf)
    app = bot.flask_app()
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.template_folder = resource_path + '/templates'

    api = Api(app)

    bot.serve(host='0.0.0.0', debug=False, port=param.port, threaded=True)
