# -*- coding: utf-8-*-
import requests

from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/07/03"


def requests_retry_session(retries=3, backoff_factor=0.3, status_forcelist=(500, 502, 504), session=None):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


def get_service_response(url, request_json):
    response = requests_retry_session().post(url, json=request_json)
    res_data = response.json()
    return res_data
