# -*- coding: utf-8-*-
import json
import logging
import sys
import time
import traceback

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/07/02"


class JsonEncoder(json.JSONEncoder):
    def default(self, o):
        results = {}
        for name in dir(o):
            if not name.startswith('__'):
                v = getattr(o, name)
                if callable(v):
                    pass
                elif not isinstance(v, type):
                    if isinstance(v, int) or isinstance(v, float) or isinstance(v, bool) or v == None:
                        results[name] = v
                    else:
                        results[name] = str(v)
                else:
                    pass
        if len(results.keys()) > 0:
            return results
        else:
            return repr(o)


class BaseLogFormatter(logging.Formatter):
    default_time_format = '%Y-%m-%dT%H:%M:%S'
    default_msec_format = '%s.%03d'

    def __init__(self):
        fmt = '[%(asctime)s] [%(levelname)s] [%(filename)s::%(lineno)d] [%(name)s::%(funcName)s] %(message)s'
        super(BaseLogFormatter, self).__init__(fmt=fmt)
        self.converter = time.gmtime

    def format(self, record):
        origin_record_msg = record.msg

        if isinstance(record.msg, dict):
            record.msg = json.dumps(record.msg, ensure_ascii=False, cls=JsonEncoder)
        elif isinstance(record.msg, Exception):
            record.exc_info = sys.exc_info()
            traceback_msg = dict()
            traceback_msg['log_type'] = 'errorlog'
            traceback_msg['error'] = record.msg.__class__.__name__
            traceback_msg['cause'] = record.msg.args[0]
            for i, msg in enumerate(traceback.format_tb(record.msg.__traceback__)):
                traceback_msg['line' + str(i + 1)] = msg
            record.msg = json.dumps(traceback_msg, ensure_ascii=False, cls=JsonEncoder)

        result = super().format(record)
        record.msg = origin_record_msg
        return result
