# -*- coding: utf-8-*-
import argparse
import json
import os
import sys
import yaml

from flask_restful import Api
from svlog import FlaskWithLog

from urls.request import Request
from urls.info import Info

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/07/02"


def get_root_path():
    file_path = None
    if getattr(sys, 'frozen', False):
        file_path = sys._MEIPASS
    else:
        file_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(file_path)


def create_app(root_path):
    app = FlaskWithLog(__name__)
    api = Api(app)
    app.config['JSON_AS_ASCII'] = False
    app.config['JSON_SORT_KEYS'] = False
    service_info = yaml.load(open(os.path.join(os.path.join(root_path, 'info'), 'service.yml')), Loader=yaml.FullLoader)
    user_data_mapping = yaml.load(open(os.path.join(os.path.join(root_path, 'info'), 'user_data.yml')), Loader=yaml.FullLoader)
    api.add_resource(Request, '/',
                     resource_class_kwargs={
                         "schema": load_schema(os.path.join(os.path.join(root_path, 'schema'), 'request.json')),
                         "service_info": service_info,
                         "user_data_mapping": user_data_mapping
                     })
    api.add_resource(Info, '/list',
                     resource_class_kwargs={
                         "service_info": service_info
                     })
    return app


def load_schema(schema_file):
    with open(schema_file, "r", encoding="utf-8") as file:
        return json.load(file)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=str, default=3000)
    conf = parser.parse_args()

    root_path = get_root_path()
    app = create_app(root_path)
    app.run(host='0.0.0.0', port=conf.port)
