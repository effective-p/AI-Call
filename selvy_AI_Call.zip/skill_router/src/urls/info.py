# -*- coding: utf-8-*-
from flask import jsonify
from flask_restful import Resource
from svlog import logged

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/07/03"


@logged
class Info(Resource):
    def __init__(self, **kwargs):
        self._service_info = kwargs.get("service_info", None)

    def get(self):
        response_data = dict()
        error_code = 200
        try:
            response_data = list(map(lambda x: {'name': x[1]['Name'], 'type_code': str(x[0])}, self._service_info.items()))
        except Exception as e:
            response_data["error_message"] = str(e)
            self.__log.error(response_data)
            error_code = 500

        response = jsonify(response_data)
        response.status_code = error_code
        return response
