# -*- coding: utf-8-*-
import jsonschema

from flask import request, jsonify
from flask_restful import Resource
from svlog import logged

from utils.util import get_service_response

__author__ = "Andrew Jeong Park"
__copyright__ = "Copyright 2020, Selvas AI Co.,LTD. All rights reserved."
__email__ = "andrew.j.park@selvas.com"
__date__ = "2020/07/02"


@logged
class Request(Resource):
    def __init__(self, **kwargs):
        self._schema = kwargs.get("schema", None)
        self._service_info = kwargs.get("service_info", None)
        self._user_data_mapping = kwargs.get("user_data_mapping", None)

    def get_info(self, bot_type):
        return self._service_info[int(bot_type)]

    @staticmethod
    def add_for_call(info, request_json):
        if info.get('Call', False) is True:
            request_json["for_call"] = True
        return request_json

    @staticmethod
    def delete_verify_order(info, request_json):
        if info.get('UseOrder', False) is False:
            request_json.pop('verify_order', None)
        return request_json

    @staticmethod
    def delete_address(info, request_json):
        if info.get('UseSelvyAddress', False) is False:
            request_json.pop('additional_info', None)
        return request_json

    @staticmethod
    def delete_not_used_key(info, request_json):
        if info.get('UseSelvyAddress', False) is True:
            for key in ['user_id', 'license_key', 'verify_order', 'user_data']:
                request_json.pop(key, None)
        return request_json

    def redefine_user_data(self, request_json):
        user_data = request_json.pop("user_data", None)
        if user_data is None:
            return request_json
        user_data = dict(map(lambda x: (self._user_data_mapping[x['id']], x['data']), user_data))
        if 'additional_info' in request_json.keys():
            request_json['additional_info'].update(user_data)
        else:
            request_json['additional_info'] = user_data
        return request_json

    def refine_request_data(self, info, request_json):
        request_json = Request.add_for_call(info, request_json)
        # verify_order key 는 본인인증만 사용
        request_json = Request.delete_verify_order(info, request_json)
        # additional_info key 는 주소완성만 사용
        request_json = Request.delete_address(info, request_json)

        #TODO(ANDREW) 주소완성 콜 봇 요청시 필요없는 인자 임시 제거
        #주소완성 콜봇을 챗봇 프레임워크로 옮기기 전까지만 유지하기
        request_json = Request.delete_not_used_key(info, request_json)

        request_json = self.redefine_user_data(request_json)
        return request_json

    @staticmethod
    def make_url(info):
        url = "{}{}{}".format(info['Host'], (lambda x: ':' + str(x) if x is not None else '')(info['Port']), info['Endpoint'])
        return url

    # TODO(ANDREW) framwork 와 nlp_api 통합 후 response 양식 수정
    # TODO(ANDREW) epd_margine 은 밀리세컨드, start_timeout 은 초 단위
    @staticmethod
    def refine_response_data(request_data, response_data):
        response_data['start_timeout'] = 60
        response_data['epd_margine'] = 600
        if 'analysis_result' not in response_data:
            utternace = request_data['user_response'][0]
            response_data['analysis_result'] = (lambda x:x if x != '시작' else '')(utternace)

        return response_data

    def post(self):
        response_data = dict()
        error_code = 200
        try:
            data = request.get_json(force=True, silent=True)
            jsonschema.validate(data, self._schema)
            info = self.get_info(data['bot_type_code'])
            request_json = self.refine_request_data(info, data['request_json'])

            url = Request.make_url(info)
            response_data = get_service_response(url, request_json)
            response_data = Request.refine_response_data(request_json, response_data)

            error_code = 200
        except jsonschema.ValidationError as jsve:
            response_data["error_message"] = jsve.message
            self.__log.error(response_data)
            error_code = 400
        except Exception as e:
            response_data["error_message"] = str(e)
            self.__log.error(response_data)
            error_code = 500

        response = jsonify(response_data)
        response.status_code = error_code
        return response
