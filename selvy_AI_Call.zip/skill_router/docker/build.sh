docker build -t $TAG .
