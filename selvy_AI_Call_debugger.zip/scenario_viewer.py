# -*- coding: utf-8-*-

import tkinter as tk
import tkinter.ttk as ttk
from io import BytesIO

import PIL.Image
import networkx as nx
from networkx.readwrite import json_graph

import tilewindow

__author__ = "John Junseok Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "jskim@selvas.com"
__date__ = "2018/06/05"


def create_image_widget(raw_root, image):
    window_width = 1024
    window_height = 768
    root = tk.Toplevel(raw_root)
    root.title("Scenario Viewer")

    tilewindow.util.stretch(root, rows=[1], columns=[0])

    image_frame = ttk.Frame(root, width=window_width, height=window_height)
    tilewindow.util.stretch(image_frame, [0], [0])
    image_frame.grid(sticky=tk.NSEW, row=1)

    image_widget = tilewindow.Image(image_frame, width=1024, height=768)
    image_widget.grid(row=0, column=0, sticky=tk.NSEW)
    xscroll, yscroll = image_widget.make_scroll_bars(image_frame)
    yscroll.grid(row=0, column=1, sticky=tk.NS)
    xscroll.grid(row=1, column=0, sticky=tk.EW)
    image_widget.set_image(image, allow_zoom=True)

    xscroll.set_to_hide()
    yscroll.set_to_hide()

    button_frame = ttk.Frame(root)
    button_frame.grid(sticky=tk.NSEW, row=0)

    def off_zoom():
        ttk.Button(button_frame, text="Reset Zoom", command=no_zoom).grid(row=1, column=0)

    def no_zoom():
        image_widget.zoom = 1.0

    ttk.Button(button_frame, text="Restore zoom", command=no_zoom).grid(row=0, column=0)

    def zoom():
        w, h = image_widget.size
        zw = w / image.width
        zh = h / image.height
        image_widget.zoom = min(zw, zh)

    ttk.Button(button_frame, text="Fit to window", command=zoom).grid(row=0, column=1)

    def zoom_wheel(event):
        if event.delta >= 120:
            if image_widget.zoom < 2.5:
                image_widget.zoom = image_widget.zoom * 1.2
        elif event.delta <= -120:
            if image_widget.zoom > 0.01:
                image_widget.zoom = image_widget.zoom * 0.9

    root.bind('<Control-MouseWheel>', zoom_wheel)

    image_widget.zoom = 1.0
    zw = window_width / image.width
    zh = window_height / image.height
    image_widget.zoom = min(zw, zh)

    def resize_image(event):
        w, h = event.width, event.height
        zw = w / image.width
        zh = h / image.height
        image_widget.zoom = min(zw, zh)

    image_frame.bind('<Configure>', resize_image)

    root.mainloop()


