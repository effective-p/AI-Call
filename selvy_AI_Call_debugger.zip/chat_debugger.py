# -*- coding: utf-8-*-

import datetime
import threading
import tkinter
import tkinter.ttk as ttk
import winreg
from functools import partial
from io import BytesIO
from tkinter import *
from tkinter import messagebox
import uuid

import PIL.Image
import networkx as nx
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry

import pydot
import tilewindow
from scenario_viewer import create_image_widget
from unicode_util import with_surrogates, without_surrogates

__author__ = "Rayna G. Kim"
__copyright__ = "Copyright 2018, Selvas AI Co.,LTD. All rights reserved."
__email__ = "kyoungjoo@selvas.com"
__date__ = "2018/06/01"
__version__ = '0.1.1'

MAIN_SID = r'Software\SelvasAI\SelvyBotDebugger'


def requests_retry_session(retries=3, backoff_factor=0.3, status_forcelist=(500, 502, 504), session=None):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


def read_memory(key):
    try:
        reg_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, MAIN_SID, 0, winreg.KEY_ALL_ACCESS)
        result = winreg.QueryValueEx(reg_key, key)
        return result[0]
    except Exception as e:
        return ""


def write_memory(key, value):
    try:
        reg_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, MAIN_SID, 0, winreg.KEY_ALL_ACCESS)
    except Exception:
        reg_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, MAIN_SID)

    winreg.SetValueEx(reg_key, key, 0, winreg.REG_SZ, value)


class ServerConnector(threading.Thread):
    def __init__(self, host, user_id, message, platform, sender, context, display_scenario):
        threading.Thread.__init__(self)
        self.host = host
        self.user_id = user_id
        self.message = message
        self.platform = platform
        self.sender = sender
        self.context = context
        self.display_scenario = display_scenario

    def run(self):
        try:
            request_data = {
                "user_id": self.user_id,
                "license_key": "testkey1234",
                "session_id": str(uuid.uuid4()),
                "for_call": False,
                "user_response" : [without_surrogates(self.message)],
                "debugger": "on"
            }

            if self.platform:
                request_data["platform"] = self.platform

            response = requests_retry_session().post(self.host, json=request_data)
            if response.status_code == 200:
                data = response.json()
                if 'chatbot_info' in response:
                    for response in data['chatbot_info']:
                        if 'button' in response:
                            self.sender(with_surrogates(response['text']), buttons=response['button'])
                        else:
                            self.sender(with_surrogates(response['text']))
                else:
                    self.sender(with_surrogates(data['result_text']))

                self.context(data['context'])
                # draw_scenario(root, data['scenario'])
                self.display_scenario(data['scenario'], data['context']['system']['cursor'])
            else:
                self.sender(str(response.text))

        except Exception as e:
            self.sender(str(e))


class Application():
    def __init__(self, root):
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)

        # main frame
        main_frame = ttk.Frame(root)
        main_frame.grid(row=0, column=0, columnspan=3, sticky='ewns')
        main_frame.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.columnconfigure(2, weight=2)

        ## 1. chat frame
        chat_frame = LabelFrame(main_frame, text="채팅창", padx=5, pady=5)
        chat_frame.grid(row=0, column=0, padx=5, pady=5, sticky='ewns')
        chat_frame.rowconfigure(0, weight=1)
        chat_frame.columnconfigure(0, weight=1)
        self.chat_text = tkinter.Text(chat_frame, width=50, height=40, spacing3=12)
        self.chat_text.grid(row=0, column=0, sticky='ewns')
        chat_scroll_bar = tkinter.Scrollbar(chat_frame, command=self.chat_text.yview)
        chat_scroll_bar.grid(row=0, column=1, sticky='nsew')
        self.chat_text['yscrollcommand'] = chat_scroll_bar.set
        self.chat_text.tag_config("datetime", foreground="#008800")
        self.chat_text.tag_config("user", font=("고딕", 11, "bold"), foreground='#001f3f')
        self.chat_text.tag_config("chatbot", font=("고딕", 11, "bold"), foreground='#FF4136')
        self.chat_text.tag_config("contents", font=("고딕", 10, ))
        self.chat_text.tag_config("button", font=("고딕", 10, "bold"), spacing3="12")
        self.chat_text.tag_bind("button", "<Button-1>", self._button_click)
        self.chat_text.tag_bind("button", "<Enter>", self._button_enter)
        self.chat_text.tag_bind("button", "<Leave>", self._button_leave)


        ## 2. context frame
        context_frame = LabelFrame(main_frame, text="변수", padx=5, pady=5)
        context_frame.grid(row=0, column=1, padx=5, pady=5, sticky='ewns')
        context_frame.rowconfigure(0, weight=1)
        context_frame.columnconfigure(0, weight=1)

        self.variable_table = ttk.Treeview(context_frame, columns=["scope", "key", "value"], show='headings', height=25)
        self.variable_table.bind("<<TreeviewSelect>>", self.on_tree_select)

        self.variable_table.column('scope', width=50, anchor='w')
        self.variable_table.column('key', width=100, anchor='w')
        self.variable_table.column('value', width=200, anchor='w')

        self.variable_table.heading('scope', text='scope', anchor='w')
        self.variable_table.heading('key', text='key', anchor='w')
        self.variable_table.heading('value', text='value', anchor='w')

        self.variable_table.grid(row=0, column=0, sticky='ewns')

        variable_vscroll_bar = tkinter.Scrollbar(context_frame, command=self.variable_table.yview)
        variable_vscroll_bar.grid(row=0, column=1, sticky='nsew')

        variable_hscroll_bar = tkinter.Scrollbar(context_frame, orient=tkinter.HORIZONTAL,
                                                 command=self.variable_table.xview)
        variable_hscroll_bar.grid(row=1, column=0, sticky='nsew')
        self.variable_table['yscrollcommand'] = variable_vscroll_bar.set
        self.variable_table['xscrollcommand'] = variable_hscroll_bar.set

        ## 3. scenario frame

        scenario_frame = LabelFrame(main_frame, text="scenario", padx=5, pady=5)
        tilewindow.util.stretch(scenario_frame, [0], [0])
        scenario_frame.grid(sticky='nsew', row=0, column=2, padx=5, pady=5)
        scenario_frame.rowconfigure(0, weight=1)
        scenario_frame.columnconfigure(0, weight=1)

        self.image_widget = tilewindow.Image(scenario_frame, width=500)
        self.image_widget.grid(row=0, column=0, sticky='nsew')
        '''
        xscroll, yscroll = self.image_widget.make_scroll_bars(scenario_frame)
        yscroll.grid(row=0, column=1, sticky='ns')
        xscroll.grid(row=1, column=0, sticky='ew')

        xscroll.set_to_hide()
        yscroll.set_to_hide()
        '''
        self.image = None

        ## 1. send_frame
        send_frame = ttk.Frame(main_frame)
        send_frame.grid(row=1, column=0, padx=5, pady=5, sticky='ewns')
        send_frame.rowconfigure(0, weight=1)
        send_frame.columnconfigure(0, weight=1)

        self.chat_message = tkinter.Text(send_frame, height=2, width=40)
        self.chat_message.bind('<Return>', self.show_contents)
        self.chat_message.grid(row=0, column=0, sticky='ewns')
        tkinter.Button(send_frame, text='Send', width=10, command=partial(self.on_send)).grid(row=0, column=1)

        ## 2. conn_info_frame
        conn_info_frame = ttk.Frame(main_frame)
        conn_info_frame.grid(row=1, column=1, padx=5, pady=5, sticky='ewns')
        conn_info_frame.rowconfigure(0, weight=1)
        conn_info_frame.rowconfigure(1, weight=1)
        conn_info_frame.columnconfigure(1, weight=1)

        ttk.Label(conn_info_frame, text='주소').grid(row=0, column=0)
        self.address_text = tkinter.Text(conn_info_frame, height=1, width=40)
        self.address_text.grid(row=0, column=1, sticky='ewns')
        self.address_text.bind("<Tab>", self.focus_next_window)
        self.address_text.bind("<Return>", self.focus_next_window)
        address_reg = read_memory("address")
        address_reg = address_reg if address_reg else "http://localhost:8080"
        self.address_text.insert('end', address_reg)

        ttk.Label(conn_info_frame, text='ID').grid(row=1, column=0)
        self.id_text = tkinter.Text(conn_info_frame, height=1, width=40)
        self.id_text.grid(row=1, column=1, sticky='ewns')
        self.id_text.bind("<Tab>", self.focus_next_window)
        self.id_text.bind("<Return>", self.focus_next_window)
        id_reg = read_memory("user_id")
        id_reg = id_reg if id_reg else "admin"
        self.id_text.insert('end', id_reg)

        ttk.Label(conn_info_frame, text='platform').grid(row=2, column=0)
        self.platform_text = tkinter.Text(conn_info_frame, height=1, width=40)
        self.platform_text.grid(row=2, column=1, sticky='ewns')
        self.platform_text.bind("<Tab>", self.focus_next_window)
        self.platform_text.bind("<Return>", self.focus_next_window)
        platform_reg = read_memory("platform")
        platform_reg = platform_reg if platform_reg else ""
        self.platform_text.insert('end', platform_reg)

        ## 3. new window
        scenario_control_frame = ttk.Frame(main_frame)
        scenario_control_frame.grid(row=1, column=2)

        ttk.Label(scenario_control_frame, text='깊이').grid(row=0, column=0)
        self.depth_size = tkinter.Text(scenario_control_frame, height=1, width=10)
        self.depth_size.grid(row=0, column=1, sticky='ewns')
        depth_size = read_memory("depth_size")
        depth_size = depth_size if depth_size else "0"
        self.depth_size.insert('end', depth_size)

        self.depth_size.bind("<Return>", self.redraw_scenario)

        tkinter.Button(scenario_control_frame, text='새창으로', width=10, command=partial(self.new_window)).grid(row=0,
                                                                                                             column=4)

        scenario_frame.bind('<Configure>', self.resize_image)

        self.variables = dict()
        self.scenario_json = None
        self.cursor = None

    def resize_image(self, event):
        if not self.image:
            return
        w, h = event.width, event.height
        zw = w / self.image.width
        zh = h / self.image.height
        self.image_widget.zoom = min(zw, zh)

    def focus_next_window(self, event):
        event.widget.tk_focusNext().focus()
        return 'break'

    def send_message(self):
        address = self.address_text.get('1.0', 'end').strip()
        if address == '':
            messagebox.showerror("실패", '주소 항목에 값이 없습니다.')
            return
        user_id = self.id_text.get('1.0', 'end').strip()
        if user_id == '':
            messagebox.showerror("실패", 'ID 항목에 값이 없습니다.')
            return

        platform = self.platform_text.get('1.0', 'end').strip()

        write_memory('address', address)
        write_memory('user_id', user_id)
        write_memory('platform', platform)

        message = self.chat_message.get('1.0', 'end').strip()

        date = "[" + datetime.datetime.now().strftime("%H:%M:%S") + "] "
        date = "[" + datetime.datetime.now().strftime("%H:%M:%S") + "] "
        self.chat_text.insert(tkinter.END, date, ("datetime",))
        self.chat_text.insert(tkinter.END, user_id + ": ", ("user",))
        self.chat_text.insert(tkinter.END, message + "\n")
        self.chat_text.see(tkinter.END)
        self.chat_message.delete('1.0', tkinter.END)
        sender = ServerConnector(address, user_id, message, platform, self.display_message, self.display_variable,
                                 self.display_scenario)
        sender.start()

    def on_send(self):
        self.send_message()

    def new_window(self):
        if not self.image:
            return
        create_image_widget(root, self.image)

    def show_contents(self, event):
        self.send_message()

    def display_message(self, message, buttons = None):
        date = "[" + datetime.datetime.now().strftime("%H:%M:%S") + "] "
        self.chat_text.insert(tkinter.END, date, ("datetime",))
        self.chat_text.insert(tkinter.END, "bot : ", ("chatbot",))
        self.chat_text.insert(tkinter.END, message + "\n", ("contents",))
        if buttons:
            for button in buttons:
                self.chat_text.insert(tkinter.END, "[ " + with_surrogates(button['label']) + " ]", ("button",))
                self.chat_text.insert(tkinter.END, ' ')
            self.chat_text.insert(tkinter.END, "\n")
        self.chat_text.see(tkinter.END)

    def display_variable(self, variables):
        self.variable_table.delete(*self.variable_table.get_children())
        max_len = 0
        self.variables.clear()
        for scope, context in variables.items():
            for key, value in context.items():
                value = with_surrogates(str(value).replace("\n", "\\n"))
                item_id = self.variable_table.insert('', 'end', values=[scope, key, value])
                self.variables[item_id] = ", ".join([scope, key, value])
                if len(value) > max_len:
                    max_len = len(value)
        self.variable_table.column('value', width=max_len * 16, anchor='w')

    def redraw_scenario(self, event):
        depth_size = self.get_depth_size()
        if self.scenario_json and self.cursor:
            self.display_scenario(self.scenario_json, self.cursor)
        return 'break'

    def get_depth_size(self):
        try:
            depth_size = int(self.depth_size.get('1.0', 'end').strip())
        except:
            depth_size = 0

        self.depth_size.delete('1.0', tkinter.END)
        self.depth_size.insert('end', str(depth_size))
        write_memory('depth_size', str(depth_size))
        return depth_size

    def display_scenario(self, scenario_json, cursor):
        depth_size = self.get_depth_size()
        self.scenario_json = scenario_json
        self.cursor = cursor
        pydot_graph = pydot.Dot(graph_type='digraph')
        graph = nx.DiGraph()
        for node in scenario_json['nodes']:
            graph.add_node(node)
        for edge in scenario_json['edges']:
            graph.add_edge(*edge)
        for edge in scenario_json['dashed_edges']:
            graph.add_edge(*edge)

        except_list = []
        if depth_size > 0:
            for node in scenario_json['nodes']:
                try:
                    rlength = nx.shortest_path_length(graph, node, cursor)
                except:
                    rlength = 9999999
                try:
                    llength = nx.shortest_path_length(graph, cursor, node)
                except:
                    llength = 9999999
                length = min(rlength, llength)
                if length > depth_size:
                    except_list.append(node)

        for node in scenario_json['nodes']:
            if node in except_list:
                continue
            if node == cursor:
                pydot_graph.add_node(pydot.Node(node, label=node, fontname='고딕', color='red'))
            else:
                pydot_graph.add_node(pydot.Node(node, label=node, fontname='고딕'))

        for edge in scenario_json['edges']:
            if any([n in except_list for n in edge]):
                continue
            pydot_graph.add_edge(pydot.Edge(*edge))
        for edge in scenario_json['dashed_edges']:
            if any([n in except_list for n in edge]):
                continue
            pydot_graph.add_edge(pydot.Edge(*edge, style='dashed'))
        png_str = pydot_graph.create_png(prog='dot', encoding='utf-8')
        sio = BytesIO(png_str)
        self.image = PIL.Image.open(sio)

        self.image_widget.set_image(self.image, allow_zoom=True)
        w, h = self.image_widget.size
        zw = w / self.image.width
        zh = h / self.image.height
        self.image_widget.zoom = min(zw, zh)

    def on_tree_select(self, event):
        for item in self.variable_table.selection():
            item_text = self.variables[item]
            # print(item_text)
            root.clipboard_clear()
            root.clipboard_append(item_text)
            root.update()  # now it stays on the clipboard after the window is closed

    def _button_enter(self, event):
        self.chat_text.config(cursor='hand2')

    def _button_leave(self, event):
        self.chat_text.config(cursor='')

    def _button_click(self, event):
        index = event.widget.index("@%s,%s" % (event.x, event.y))
        tag_indices = list(event.widget.tag_ranges('button'))

        for start, end in zip(tag_indices[0::2], tag_indices[1::2]):
            if event.widget.compare(start, '<=', index) and event.widget.compare(index, '<', end):
                text = event.widget.get(start, end)
                parsed_text = text.strip('[] ')
                self.chat_message.delete(1.0, tkinter.END)
                self.chat_message.insert(tkinter.END, parsed_text)
                self.on_send()

if __name__ == '__main__':
    root = Tk()
    root.title("Chat Debugger")
    app = Application(root)
    root.mainloop()
